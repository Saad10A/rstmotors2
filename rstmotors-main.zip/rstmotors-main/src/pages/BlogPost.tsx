import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Calendar, ArrowLeft, User, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const blogPosts = [
  {
    id: 1,
    title: "The Future of Electric Performance Tuning",
    excerpt: "As electric vehicles become more prevalent, we explore the exciting new frontiers of EV performance modification and what it means for enthusiasts.",
    image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800&q=80",
    date: "2024-12-10",
    category: "Technology",
    author: "Marcus Weber",
    readTime: "8 min read",
    content: `
      <p>The automotive world is undergoing a seismic shift. As electric vehicles become more prevalent on our roads, a new frontier of performance tuning is emerging—one that challenges everything we thought we knew about making cars faster.</p>

      <h2>The New Performance Paradigm</h2>
      <p>Traditional performance tuning has always been about extracting more power from internal combustion engines—remapping ECUs, upgrading turbos, installing performance exhaust systems. But electric vehicles present an entirely different challenge and opportunity.</p>
      
      <p>EVs are inherently simpler in some ways—fewer moving parts, instant torque delivery, and regenerative braking. Yet they're also more complex, with sophisticated battery management systems, thermal management, and power electronics that require a deep understanding of electrical engineering.</p>

      <h2>Software is the New Hardware</h2>
      <p>In the world of EV tuning, software is king. Unlike traditional vehicles where mechanical modifications are essential, most EV performance gains come from software optimization. This includes:</p>
      
      <ul>
        <li><strong>Power Limit Removal:</strong> Many EVs have software-imposed power limits that can be safely increased.</li>
        <li><strong>Torque Curve Optimization:</strong> Adjusting the power delivery curve for more aggressive acceleration.</li>
        <li><strong>Regenerative Braking Tuning:</strong> Customizing regen levels for track or street use.</li>
        <li><strong>Thermal Management:</strong> Optimizing cooling strategies for sustained high performance.</li>
      </ul>

      <h2>The Role of RST Performance</h2>
      <p>At RST Performance, we're at the forefront of this revolution. Our team of engineers includes specialists in electrical systems, battery technology, and software development. We're developing proprietary solutions that push the boundaries of what's possible with electric performance vehicles.</p>

      <h2>What's Next?</h2>
      <p>The future of EV tuning is incredibly exciting. As battery technology improves and manufacturers continue to push the envelope, the potential for performance enhancement will only grow. We're already working on projects that will redefine what enthusiasts expect from their electric vehicles.</p>

      <p>Stay tuned to our blog for more updates on our EV tuning developments, and don't hesitate to reach out if you're interested in exploring what's possible with your electric performance vehicle.</p>
    `,
  },
  {
    id: 2,
    title: "5 Essential Upgrades for Your Audi RS",
    excerpt: "Discover the top modifications that will transform your Audi RS into an even more formidable machine on both road and track.",
    image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80",
    date: "2024-12-05",
    category: "Guides",
    author: "Thomas Richter",
    readTime: "6 min read",
    content: `
      <p>Audi's RS models are already incredible machines straight from the factory. But for those who want more—more power, better handling, and a more visceral driving experience—there are several key upgrades that can take your RS to the next level.</p>

      <h2>1. ECU Tuning</h2>
      <p>The foundation of any performance build, a quality ECU tune can unlock substantial power gains. On turbocharged RS models, gains of 50-100+ horsepower are common. Our RST Stage 1 and Stage 2 tunes are developed in-house and tested extensively on the dyno and road.</p>

      <h2>2. Downpipe and Exhaust System</h2>
      <p>A less restrictive exhaust system not only frees up power but also delivers that aggressive soundtrack that RS owners crave. Our titanium exhaust systems are designed to reduce backpressure while maintaining a refined tone that won't drone on highway cruises.</p>

      <h2>3. Upgraded Intercooler</h2>
      <p>Heat is the enemy of performance. An upgraded intercooler ensures your engine receives the coolest possible air charge, maintaining consistent power even during spirited driving. This is especially important for track use or in warmer climates.</p>

      <h2>4. Performance Suspension</h2>
      <p>Factory RS suspension is excellent, but adjustable coilovers or performance lowering springs can further sharpen the handling. We recommend setups that maintain daily drivability while improving turn-in response and reducing body roll.</p>

      <h2>5. Lightweight Wheels</h2>
      <p>Reducing unsprung weight improves acceleration, braking, and handling. Our forged wheel options can save significant weight over factory wheels while looking absolutely stunning. Check out our RST Forged Alloy Wheels for the ultimate upgrade.</p>

      <h2>The Complete Package</h2>
      <p>While each upgrade offers benefits on its own, the magic happens when they're combined thoughtfully. Our team at RST Performance can help you develop a build plan that matches your goals and budget.</p>
    `,
  },
  {
    id: 3,
    title: "Behind the Scenes: Our Latest RS7 Build",
    excerpt: "Take an exclusive look at our recent RS7 project, featuring custom bodywork, performance upgrades, and bespoke interior refinements.",
    image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80",
    date: "2024-11-28",
    category: "Builds",
    author: "Sarah Klein",
    readTime: "10 min read",
    content: `
      <p>Every now and then, a project comes along that allows us to showcase everything we're capable of at RST Performance. Our latest RS7 build is exactly that kind of project—a no-holds-barred transformation that pushes boundaries in every way.</p>

      <h2>The Vision</h2>
      <p>Our client came to us with a clear vision: create the ultimate grand touring machine. Something that could cross continents in supreme comfort while delivering supercar-rivaling performance. The RS7 was the perfect starting point.</p>

      <h2>Power Enhancement</h2>
      <p>The 4.0-liter twin-turbo V8 received our full Stage 3 treatment. New turbochargers, upgraded fuel system, and a custom tune brought output to an incredible 780 horsepower and 720 lb-ft of torque. The transmission was strengthened to handle the additional power.</p>

      <h2>Exterior Transformation</h2>
      <p>Our bespoke carbon fiber widebody kit adds an aggressive stance while improving aerodynamics. Every panel was designed in-house and crafted from dry carbon for the ultimate weight savings. A custom paint scheme in Nardo Grey with carbon accents completes the look.</p>

      <h2>Interior Refinements</h2>
      <p>The interior received a full retrim in quilted leather with contrast stitching matching our signature blue. A custom steering wheel, upgraded audio system, and bespoke touches throughout ensure the cabin matches the exterior's drama.</p>

      <h2>The Result</h2>
      <p>The finished RS7 represents months of work from our dedicated team. It's a car that can sprint to 60 mph in under 3 seconds, reach over 200 mph, and still be comfortable enough for cross-country road trips. That's the RST Performance promise.</p>
    `,
  },
  {
    id: 4,
    title: "Carbon Fiber: Why Weight Matters",
    excerpt: "An in-depth look at how carbon fiber components can improve your vehicle's performance, handling, and efficiency.",
    image: "https://images.unsplash.com/photo-1547038577-da80abbc4f19?w=800&q=80",
    date: "2024-11-20",
    category: "Technology",
    author: "Marcus Weber",
    readTime: "7 min read",
    content: `
      <p>In the world of performance vehicles, weight is the enemy. Every kilogram saved translates to better acceleration, sharper handling, improved braking, and even better fuel efficiency. That's why carbon fiber has become the material of choice for serious performance enthusiasts.</p>

      <h2>Understanding Carbon Fiber</h2>
      <p>Carbon fiber reinforced polymer (CFRP) offers an exceptional strength-to-weight ratio. It's approximately five times stronger than steel while being significantly lighter. This makes it ideal for automotive applications where every gram counts.</p>

      <h2>Types of Carbon Fiber</h2>
      <p>Not all carbon fiber is created equal. At RST Performance, we use three main types:</p>
      
      <ul>
        <li><strong>Wet Carbon:</strong> The most common type, suitable for cosmetic components.</li>
        <li><strong>Dry Carbon:</strong> Pre-impregnated with resin for superior strength and lighter weight.</li>
        <li><strong>Forged Carbon:</strong> A unique aesthetic with excellent structural properties.</li>
      </ul>

      <h2>Where Weight Savings Matter Most</h2>
      <p>Strategic weight reduction is key. Saving weight in rotating components (wheels, brake rotors) has a multiplied effect on performance. Reducing unsprung mass improves suspension response and grip. Lowering the center of gravity by using carbon roofs or hoods improves handling.</p>

      <h2>Our Carbon Fiber Line</h2>
      <p>RST Performance offers a comprehensive range of carbon fiber components, from exterior aero pieces to interior trim and even structural components. Each piece is designed in-house and manufactured to the highest standards.</p>
    `,
  },
  {
    id: 5,
    title: "Track Day Preparation Guide",
    excerpt: "Everything you need to know before taking your tuned vehicle to the track, from safety checks to performance optimization.",
    image: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800&q=80",
    date: "2024-11-15",
    category: "Guides",
    author: "Thomas Richter",
    readTime: "9 min read",
    content: `
      <p>Track days are the ultimate test of your vehicle's capabilities—and your driving skills. Whether you're a track day veteran or preparing for your first session, proper preparation is essential for a safe and enjoyable experience.</p>

      <h2>Vehicle Inspection</h2>
      <p>Before heading to the track, perform a thorough inspection:</p>
      
      <ul>
        <li><strong>Brakes:</strong> Check pad thickness, rotor condition, and brake fluid level. Consider track-specific brake pads and fresh high-temperature fluid.</li>
        <li><strong>Tires:</strong> Inspect for wear and damage. Check pressures (they'll increase with heat).</li>
        <li><strong>Fluids:</strong> Ensure all fluids are at proper levels. Fresh oil is recommended.</li>
        <li><strong>Suspension:</strong> Check for leaks, worn bushings, or loose components.</li>
      </ul>

      <h2>Safety Equipment</h2>
      <p>At minimum, you'll need a quality helmet rated for motorsport use. Many tracks require SNELL or FIA certification. A fire extinguisher is also recommended, and a racing harness adds significant safety.</p>

      <h2>What to Bring</h2>
      <p>Pack essential supplies: tools for minor adjustments, spare fluids, a tire pressure gauge, painter's tape for numbering, and plenty of water. Don't forget your license, registration, and proof of insurance.</p>

      <h2>Driving Tips for Beginners</h2>
      <p>Start slow and gradually increase pace as you learn the track. Focus on your line before adding speed. Use the entire track. Look ahead, not at the car in front. Most importantly, leave your ego at home.</p>

      <h2>Post-Track Care</h2>
      <p>After the track day, inspect your vehicle thoroughly. Check all fluids, inspect brake components, and look for any signs of stress or wear. Address any issues before your next session.</p>
    `,
  },
  {
    id: 6,
    title: "The Art of Exhaust Tuning",
    excerpt: "How a properly designed exhaust system can unlock hidden power while delivering the perfect acoustic experience.",
    image: "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800&q=80",
    date: "2024-11-08",
    category: "Technology",
    author: "Sarah Klein",
    readTime: "6 min read",
    content: `
      <p>An exhaust system does more than just expel gases—it's a carefully engineered component that affects power output, torque delivery, fuel efficiency, and of course, sound. At RST Performance, we consider exhaust tuning both a science and an art.</p>

      <h2>The Science</h2>
      <p>Exhaust system design involves complex fluid dynamics. Key factors include:</p>
      
      <ul>
        <li><strong>Pipe Diameter:</strong> Too small restricts flow; too large can reduce velocity and hurt low-end torque.</li>
        <li><strong>Header Design:</strong> Primary tube length and collector design affect power delivery characteristics.</li>
        <li><strong>Catalytic Converters:</strong> High-flow cats minimize restriction while maintaining emissions compliance.</li>
        <li><strong>Muffler Design:</strong> Internal architecture affects both flow and sound character.</li>
      </ul>

      <h2>The Art</h2>
      <p>Sound is subjective, but great exhaust notes share common traits: they're aggressive under acceleration, subdued at cruise, and free from drone at highway speeds. Achieving this balance requires expertise and extensive testing.</p>

      <h2>Materials Matter</h2>
      <p>We use 304 stainless steel for durability and corrosion resistance. For weight savings, we offer titanium systems that can shed 10-15 kilograms compared to factory exhausts while delivering an even more exotic sound character.</p>

      <h2>Custom vs. Off-the-Shelf</h2>
      <p>While quality off-the-shelf systems work well for most applications, some builds require custom solutions. Our fabrication team can design and build one-off systems tailored to specific performance and sound goals.</p>
    `,
  },
];

const BlogPost = () => {
  const { id } = useParams();
  const scrollRef = useScrollAnimation();
  
  const post = blogPosts.find(p => p.id === Number(id));
  
  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-20">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <h1 className="font-heading text-4xl font-bold text-foreground mb-4">
              Post Not Found
            </h1>
            <p className="text-muted-foreground mb-8">
              The blog post you're looking for doesn't exist.
            </p>
            <Link to="/blog">
              <Button variant="default">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Blog
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const relatedPosts = blogPosts
    .filter(p => p.id !== post.id && p.category === post.category)
    .slice(0, 2);

  return (
    <div className="min-h-screen bg-background" ref={scrollRef}>
      <Header />
      
      <main className="pt-24 pb-20">
        {/* Hero Image */}
        <div className="relative h-[50vh] md:h-[60vh] mb-12">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        </div>

        <article className="max-w-4xl mx-auto px-6 -mt-32 relative z-10">
          {/* Back Link */}
          <Link 
            to="/blog" 
            className="inline-flex items-center text-primary hover:text-primary/80 transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Blog
          </Link>

          {/* Header */}
          <header className="mb-12 animate-fade-in">
            <span className="text-primary text-sm font-medium mb-4 block">
              {post.category}
            </span>
            <h1 className="font-heading text-3xl md:text-5xl font-bold text-foreground mb-6">
              {post.title}
            </h1>
            <div className="flex flex-wrap items-center gap-6 text-muted-foreground text-sm">
              <span className="flex items-center">
                <User className="w-4 h-4 mr-2" />
                {post.author}
              </span>
              <span className="flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                {new Date(post.date).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </span>
              <span className="flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                {post.readTime}
              </span>
            </div>
          </header>

          {/* Content */}
          <div 
            className="prose prose-invert prose-lg max-w-none mb-16
              prose-headings:font-heading prose-headings:text-foreground
              prose-p:text-muted-foreground prose-p:leading-relaxed
              prose-a:text-primary prose-a:no-underline hover:prose-a:underline
              prose-strong:text-foreground
              prose-li:text-muted-foreground
              prose-ul:list-disc prose-ul:pl-6"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />

          {/* Divider */}
          <div className="border-t border-border my-16" />

          {/* Related Posts */}
          {relatedPosts.length > 0 && (
            <section className="animate-on-scroll">
              <h2 className="font-heading text-2xl font-bold text-foreground mb-8">
                Related Articles
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {relatedPosts.map((relatedPost) => (
                  <Link
                    key={relatedPost.id}
                    to={`/blog/${relatedPost.id}`}
                    className="group"
                  >
                    <div className="aspect-[16/10] overflow-hidden rounded-lg mb-4">
                      <img
                        src={relatedPost.image}
                        alt={relatedPost.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    </div>
                    <span className="text-primary text-sm font-medium mb-2 block">
                      {relatedPost.category}
                    </span>
                    <h3 className="font-heading text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                      {relatedPost.title}
                    </h3>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </article>
      </main>

      <Footer />
    </div>
  );
};

export default BlogPost;
