import { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useAdmin } from '@/hooks/useAdmin';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { sanitizeCarError } from '@/lib/errorHandler';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ArrowLeft, Loader2, Plus, X, ShieldAlert } from 'lucide-react';
import { toast } from 'sonner';

const bodyTypes = ['Saloon', 'SUV', 'Coupe', 'Estate', 'Hatchback', 'Convertible'];
const fuelTypes = ['Petrol', 'Diesel', 'Hybrid', 'Electric'];
const gearboxTypes = ['Automatic', 'Manual', 'Semi-Automatic'];

const AdminCarForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = !!id;
  
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: adminLoading } = useAdmin();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageUrls, setImageUrls] = useState<string[]>(['']);
  
  const [formData, setFormData] = useState({
    title: '',
    subtitle: '',
    price: '',
    mileage: '',
    registration_year: '',
    body_type: '',
    fuel_type: '',
    gearbox: '',
    engine: '',
    power: '',
    acceleration: '',
    doors: '',
    seats: '',
    body_colour: '',
    registration_plate: '',
    owners: '1',
    keys: '2',
    mot_valid_until: '',
    emission_class: '',
    service_history: '',
    description: '',
    seller_name: '',
    seller_location: '',
    seller_phone: '',
    is_featured: false,
    is_sold: false,
  });

  const { data: car, isLoading } = useQuery({
    queryKey: ['admin-car', id],
    queryFn: async () => {
      if (!id) return null;
      const { data, error } = await supabase
        .from('cars')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    enabled: isEditing && isAdmin,
  });

  useEffect(() => {
    if (car) {
      setFormData({
        title: car.title || '',
        subtitle: car.subtitle || '',
        price: car.price?.toString() || '',
        mileage: car.mileage?.toString() || '',
        registration_year: car.registration_year?.toString() || '',
        body_type: car.body_type || '',
        fuel_type: car.fuel_type || '',
        gearbox: car.gearbox || '',
        engine: car.engine || '',
        power: car.power || '',
        acceleration: car.acceleration || '',
        doors: car.doors?.toString() || '',
        seats: car.seats?.toString() || '',
        body_colour: car.body_colour || '',
        registration_plate: car.registration_plate || '',
        owners: car.owners?.toString() || '1',
        keys: car.keys?.toString() || '2',
        mot_valid_until: car.mot_valid_until || '',
        emission_class: car.emission_class || '',
        service_history: car.service_history || '',
        description: car.description || '',
        seller_name: car.seller_name || '',
        seller_location: car.seller_location || '',
        seller_phone: car.seller_phone || '',
        is_featured: car.is_featured || false,
        is_sold: car.is_sold || false,
      });
      setImageUrls(car.images && car.images.length > 0 ? car.images : ['']);
    }
  }, [car]);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  const handleChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUrlChange = (index: number, value: string) => {
    const newUrls = [...imageUrls];
    newUrls[index] = value;
    setImageUrls(newUrls);
  };

  const addImageUrl = () => {
    setImageUrls([...imageUrls, '']);
  };

  const removeImageUrl = (index: number) => {
    if (imageUrls.length > 1) {
      setImageUrls(imageUrls.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const carData = {
        title: formData.title,
        subtitle: formData.subtitle || null,
        price: parseFloat(formData.price),
        mileage: formData.mileage ? parseInt(formData.mileage) : null,
        registration_year: formData.registration_year ? parseInt(formData.registration_year) : null,
        body_type: formData.body_type || null,
        fuel_type: formData.fuel_type || null,
        gearbox: formData.gearbox || null,
        engine: formData.engine || null,
        power: formData.power || null,
        acceleration: formData.acceleration || null,
        doors: formData.doors ? parseInt(formData.doors) : null,
        seats: formData.seats ? parseInt(formData.seats) : null,
        body_colour: formData.body_colour || null,
        registration_plate: formData.registration_plate || null,
        owners: formData.owners ? parseInt(formData.owners) : 1,
        keys: formData.keys ? parseInt(formData.keys) : 2,
        mot_valid_until: formData.mot_valid_until || null,
        emission_class: formData.emission_class || null,
        service_history: formData.service_history || null,
        description: formData.description || null,
        seller_name: formData.seller_name || null,
        seller_location: formData.seller_location || null,
        seller_phone: formData.seller_phone || null,
        is_featured: formData.is_featured,
        is_sold: formData.is_sold,
        images: imageUrls.filter(url => url.trim() !== ''),
      };

      if (isEditing) {
        const { error } = await supabase
          .from('cars')
          .update(carData)
          .eq('id', id);
        
        if (error) throw error;
        toast.success('Car updated successfully');
      } else {
        const { error } = await supabase
          .from('cars')
          .insert([carData]);
        
        if (error) throw error;
        toast.success('Car added successfully');
      }

      navigate('/admin');
    } catch (error: any) {
      // Use sanitized error message to prevent information disclosure
      toast.error(sanitizeCarError(error, isEditing ? 'update' : 'create'));
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading || adminLoading || (isEditing && isLoading)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4">
            <ShieldAlert className="w-16 h-16 mx-auto text-destructive" />
            <h1 className="text-2xl font-heading font-bold">Access Denied</h1>
            <p className="text-muted-foreground">You don't have permission to access this page.</p>
            <Button onClick={() => navigate('/')} variant="outline">
              Go Home
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1 pt-24">
        <div className="container mx-auto px-4 py-12">
          {/* Header */}
          <div className="mb-8">
            <Link 
              to="/admin" 
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Admin
            </Link>
            <h1 className="text-3xl font-heading font-bold">
              {isEditing ? 'Edit Car Listing' : 'Add New Car'}
            </h1>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Information */}
            <div className="bg-card border border-border p-6">
              <h2 className="font-heading font-bold text-lg mb-4">Basic Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => handleChange('title', e.target.value)}
                    placeholder="e.g. BMW M4 Competition"
                    required
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subtitle">Subtitle</Label>
                  <Input
                    id="subtitle"
                    value={formData.subtitle}
                    onChange={(e) => handleChange('subtitle', e.target.value)}
                    placeholder="e.g. xDrive Package"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price">Price (£) *</Label>
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => handleChange('price', e.target.value)}
                    placeholder="45000"
                    required
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mileage">Mileage</Label>
                  <Input
                    id="mileage"
                    type="number"
                    value={formData.mileage}
                    onChange={(e) => handleChange('mileage', e.target.value)}
                    placeholder="25000"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="registration_year">Registration Year</Label>
                  <Input
                    id="registration_year"
                    type="number"
                    value={formData.registration_year}
                    onChange={(e) => handleChange('registration_year', e.target.value)}
                    placeholder="2023"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="registration_plate">Registration Plate</Label>
                  <Input
                    id="registration_plate"
                    value={formData.registration_plate}
                    onChange={(e) => handleChange('registration_plate', e.target.value)}
                    placeholder="AB12 CDE"
                    className="bg-secondary border-border"
                  />
                </div>
              </div>
            </div>

            {/* Vehicle Details */}
            <div className="bg-card border border-border p-6">
              <h2 className="font-heading font-bold text-lg mb-4">Vehicle Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Body Type</Label>
                  <Select value={formData.body_type} onValueChange={(v) => handleChange('body_type', v)}>
                    <SelectTrigger className="bg-secondary border-border">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {bodyTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Fuel Type</Label>
                  <Select value={formData.fuel_type} onValueChange={(v) => handleChange('fuel_type', v)}>
                    <SelectTrigger className="bg-secondary border-border">
                      <SelectValue placeholder="Select fuel" />
                    </SelectTrigger>
                    <SelectContent>
                      {fuelTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Gearbox</Label>
                  <Select value={formData.gearbox} onValueChange={(v) => handleChange('gearbox', v)}>
                    <SelectTrigger className="bg-secondary border-border">
                      <SelectValue placeholder="Select gearbox" />
                    </SelectTrigger>
                    <SelectContent>
                      {gearboxTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="engine">Engine</Label>
                  <Input
                    id="engine"
                    value={formData.engine}
                    onChange={(e) => handleChange('engine', e.target.value)}
                    placeholder="3.0L Twin Turbo"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="power">Power</Label>
                  <Input
                    id="power"
                    value={formData.power}
                    onChange={(e) => handleChange('power', e.target.value)}
                    placeholder="503 bhp"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="acceleration">Acceleration (0-60)</Label>
                  <Input
                    id="acceleration"
                    value={formData.acceleration}
                    onChange={(e) => handleChange('acceleration', e.target.value)}
                    placeholder="3.9 seconds"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="doors">Doors</Label>
                  <Input
                    id="doors"
                    type="number"
                    value={formData.doors}
                    onChange={(e) => handleChange('doors', e.target.value)}
                    placeholder="4"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seats">Seats</Label>
                  <Input
                    id="seats"
                    type="number"
                    value={formData.seats}
                    onChange={(e) => handleChange('seats', e.target.value)}
                    placeholder="5"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="body_colour">Body Colour</Label>
                  <Input
                    id="body_colour"
                    value={formData.body_colour}
                    onChange={(e) => handleChange('body_colour', e.target.value)}
                    placeholder="Black Sapphire Metallic"
                    className="bg-secondary border-border"
                  />
                </div>
              </div>
            </div>

            {/* History & Documentation */}
            <div className="bg-card border border-border p-6">
              <h2 className="font-heading font-bold text-lg mb-4">History & Documentation</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="owners">Previous Owners</Label>
                  <Input
                    id="owners"
                    type="number"
                    value={formData.owners}
                    onChange={(e) => handleChange('owners', e.target.value)}
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="keys">Number of Keys</Label>
                  <Input
                    id="keys"
                    type="number"
                    value={formData.keys}
                    onChange={(e) => handleChange('keys', e.target.value)}
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mot_valid_until">MOT Valid Until</Label>
                  <Input
                    id="mot_valid_until"
                    value={formData.mot_valid_until}
                    onChange={(e) => handleChange('mot_valid_until', e.target.value)}
                    placeholder="December 2025"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emission_class">Emission Class</Label>
                  <Input
                    id="emission_class"
                    value={formData.emission_class}
                    onChange={(e) => handleChange('emission_class', e.target.value)}
                    placeholder="Euro 6"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="service_history">Service History</Label>
                  <Input
                    id="service_history"
                    value={formData.service_history}
                    onChange={(e) => handleChange('service_history', e.target.value)}
                    placeholder="Full BMW Service History"
                    className="bg-secondary border-border"
                  />
                </div>
              </div>
            </div>

            {/* Seller Information */}
            <div className="bg-card border border-border p-6">
              <h2 className="font-heading font-bold text-lg mb-4">Seller Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="seller_name">Seller Name</Label>
                  <Input
                    id="seller_name"
                    value={formData.seller_name}
                    onChange={(e) => handleChange('seller_name', e.target.value)}
                    placeholder="RST Performance"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seller_location">Location</Label>
                  <Input
                    id="seller_location"
                    value={formData.seller_location}
                    onChange={(e) => handleChange('seller_location', e.target.value)}
                    placeholder="London, UK"
                    className="bg-secondary border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seller_phone">Phone</Label>
                  <Input
                    id="seller_phone"
                    value={formData.seller_phone}
                    onChange={(e) => handleChange('seller_phone', e.target.value)}
                    placeholder="+44 123 456 7890"
                    className="bg-secondary border-border"
                  />
                </div>
              </div>
            </div>

            {/* Images */}
            <div className="bg-card border border-border p-6">
              <h2 className="font-heading font-bold text-lg mb-4">Images</h2>
              <div className="space-y-3">
                {imageUrls.map((url, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={url}
                      onChange={(e) => handleImageUrlChange(index, e.target.value)}
                      placeholder="https://example.com/image.jpg"
                      className="bg-secondary border-border flex-1"
                    />
                    {imageUrls.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeImageUrl(index)}
                        className="text-destructive hover:text-destructive"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={addImageUrl}
                  className="w-full"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Another Image
                </Button>
              </div>
            </div>

            {/* Description */}
            <div className="bg-card border border-border p-6">
              <h2 className="font-heading font-bold text-lg mb-4">Description</h2>
              <Textarea
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Enter a detailed description of the vehicle..."
                rows={6}
                className="bg-secondary border-border"
              />
            </div>

            {/* Status */}
            <div className="bg-card border border-border p-6">
              <h2 className="font-heading font-bold text-lg mb-4">Status</h2>
              <div className="flex flex-wrap gap-6">
                <div className="flex items-center gap-3">
                  <Switch
                    id="is_featured"
                    checked={formData.is_featured}
                    onCheckedChange={(v) => handleChange('is_featured', v)}
                  />
                  <Label htmlFor="is_featured">Featured Listing</Label>
                </div>
                <div className="flex items-center gap-3">
                  <Switch
                    id="is_sold"
                    checked={formData.is_sold}
                    onCheckedChange={(v) => handleChange('is_sold', v)}
                  />
                  <Label htmlFor="is_sold">Mark as Sold</Label>
                </div>
              </div>
            </div>

            {/* Submit */}
            <div className="flex gap-4">
              <Button
                type="submit"
                className="bg-primary hover:bg-primary/90"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  isEditing ? 'Update Car' : 'Add Car'
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/admin')}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default AdminCarForm;
