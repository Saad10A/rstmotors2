import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useLanguage } from "@/i18n/LanguageContext";
import SEO from "@/components/SEO";

const About = () => {
  const scrollRef = useScrollAnimation();
  const { t } = useLanguage();

  const values = [
    { title: t.about.valuePrecision, description: t.about.valuePrecisionDesc },
    { title: t.about.valueInnovation, description: t.about.valueInnovationDesc },
    { title: t.about.valuePassion, description: t.about.valuePassionDesc },
  ];

  const team = [
    { name: "Marcus Weber", role: t.about.roleFounder, image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&q=80" },
    { name: "Elena Schmidt", role: t.about.roleDesign, image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&q=80" },
    { name: "Thomas Müller", role: t.about.roleEngineer, image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=80" },
  ];

  return (
    <div className="min-h-screen bg-background" ref={scrollRef}>
      <SEO 
        title="About Us"
        description="Learn about RST Motors - our story, values, and the passionate team behind premium automotive tuning and customization services."
        keywords="about RST Motors, car tuning experts, automotive customization team, performance specialists"
        url="/about"
      />
      <Header />
      
      <main className="pt-24 pb-20">
        {/* Hero Section */}
        <section className="relative h-[50vh] overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=1920&q=80"
            alt="RST Performance Workshop"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/60 to-transparent" />
          <div className="absolute inset-0 flex items-center">
            <div className="max-w-7xl mx-auto px-6 w-full">
              <h1 className="font-heading text-4xl md:text-6xl font-bold text-foreground animate-fade-in">
                {t.about.title}
              </h1>
              <p className="text-xl text-primary mt-4 animate-slide-left">
                {t.about.subtitle}
              </p>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="max-w-7xl mx-auto px-6 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="animate-on-scroll">
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
                {t.about.storyTitle}
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                {t.about.storyP1}
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                {t.about.storyP2}
              </p>
              <p className="text-muted-foreground leading-relaxed">
                {t.about.storyP3}
              </p>
            </div>
            <div className="animate-on-scroll">
              <img
                src="https://images.unsplash.com/photo-1487754180451-c456f719a1fc?w=800&q=80"
                alt="RST Workshop"
                className="w-full rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="bg-card py-20">
          <div className="max-w-7xl mx-auto px-6">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground text-center mb-12 animate-on-scroll">
              {t.about.valuesTitle}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <div 
                  key={value.title} 
                  className="text-center p-8 border border-border rounded-lg animate-on-scroll"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <h3 className="font-heading text-xl font-bold text-primary mb-4">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="max-w-7xl mx-auto px-6 py-20">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground text-center mb-12 animate-on-scroll">
            {t.about.teamTitle}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div 
                key={member.name} 
                className="text-center animate-on-scroll"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-48 h-48 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="font-heading text-xl font-bold text-foreground">{member.name}</h3>
                <p className="text-primary">{member.role}</p>
              </div>
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;