import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useLanguage } from "@/i18n/LanguageContext";
import SEO from "@/components/SEO";

const PrivacyPolicy = () => {
  const scrollRef = useScrollAnimation();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background" ref={scrollRef}>
      <SEO 
        title={t.privacy.title}
        description={t.privacy.metaDescription}
        keywords="privacy policy, cookie policy, data protection, GDPR"
        url="/privacy-policy"
      />
      <Header />
      
      <main className="pt-24 pb-20">
        <div className="max-w-4xl mx-auto px-6 py-12">
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-8 animate-fade-in">
            {t.privacy.title}
          </h1>
          <p className="text-muted-foreground mb-12">
            {t.privacy.lastUpdated}: {t.privacy.lastUpdatedDate}
          </p>

          {/* Introduction */}
          <section className="mb-12 animate-on-scroll">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
              {t.privacy.introTitle}
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              {t.privacy.introText}
            </p>
          </section>

          {/* Data Collection */}
          <section className="mb-12 animate-on-scroll">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
              {t.privacy.dataCollectionTitle}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              {t.privacy.dataCollectionText}
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>{t.privacy.dataItem1}</li>
              <li>{t.privacy.dataItem2}</li>
              <li>{t.privacy.dataItem3}</li>
              <li>{t.privacy.dataItem4}</li>
            </ul>
          </section>

          {/* Cookie Policy */}
          <section className="mb-12 animate-on-scroll bg-card border border-border rounded-lg p-6">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
              {t.privacy.cookieTitle}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              {t.privacy.cookieText}
            </p>

            {/* Essential Cookies */}
            <div className="mb-6">
              <h3 className="font-heading text-lg font-semibold text-primary mb-2">
                {t.privacy.essentialCookiesTitle}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {t.privacy.essentialCookiesText}
              </p>
            </div>

            {/* Analytics Cookies */}
            <div className="mb-6">
              <h3 className="font-heading text-lg font-semibold text-primary mb-2">
                {t.privacy.analyticsCookiesTitle}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {t.privacy.analyticsCookiesText}
              </p>
            </div>

            {/* Marketing Cookies */}
            <div className="mb-6">
              <h3 className="font-heading text-lg font-semibold text-primary mb-2">
                {t.privacy.marketingCookiesTitle}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {t.privacy.marketingCookiesText}
              </p>
            </div>

            {/* Cookie Management */}
            <div>
              <h3 className="font-heading text-lg font-semibold text-primary mb-2">
                {t.privacy.cookieManagementTitle}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {t.privacy.cookieManagementText}
              </p>
            </div>
          </section>

          {/* Data Usage */}
          <section className="mb-12 animate-on-scroll">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
              {t.privacy.dataUsageTitle}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              {t.privacy.dataUsageText}
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>{t.privacy.usageItem1}</li>
              <li>{t.privacy.usageItem2}</li>
              <li>{t.privacy.usageItem3}</li>
              <li>{t.privacy.usageItem4}</li>
            </ul>
          </section>

          {/* Data Protection */}
          <section className="mb-12 animate-on-scroll">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
              {t.privacy.dataProtectionTitle}
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              {t.privacy.dataProtectionText}
            </p>
          </section>

          {/* Your Rights */}
          <section className="mb-12 animate-on-scroll">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
              {t.privacy.yourRightsTitle}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              {t.privacy.yourRightsText}
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>{t.privacy.rightItem1}</li>
              <li>{t.privacy.rightItem2}</li>
              <li>{t.privacy.rightItem3}</li>
              <li>{t.privacy.rightItem4}</li>
              <li>{t.privacy.rightItem5}</li>
            </ul>
          </section>

          {/* Contact */}
          <section className="animate-on-scroll">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
              {t.privacy.contactTitle}
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              {t.privacy.contactText}
            </p>
            <p className="text-primary mt-4">
              {t.contact.email}
            </p>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PrivacyPolicy;
