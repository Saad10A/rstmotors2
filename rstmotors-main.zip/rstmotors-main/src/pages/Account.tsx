import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/i18n/LanguageContext';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { 
  User, 
  Package, 
  Heart, 
  MapPin, 
  CreditCard, 
  Settings, 
  LogOut,
  ChevronRight,
  ArrowLeft,
  Loader2
} from 'lucide-react';
import logo from '@/assets/logo.png';

const Account = () => {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const handleSignOut = async () => {
    setIsLoggingOut(true);
    try {
      await signOut();
      toast.success(t.account.logoutSuccess);
      navigate('/');
    } catch (error) {
      toast.error(t.account.logoutError);
    } finally {
      setIsLoggingOut(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const menuItems = [
    {
      icon: User,
      label: t.account.profile,
      description: t.account.profileDesc,
      href: '/account/profile',
    },
    {
      icon: Package,
      label: t.account.orders,
      description: t.account.ordersDesc,
      href: '/account/orders',
    },
    {
      icon: Heart,
      label: t.account.wishlist,
      description: t.account.wishlistDesc,
      href: '/wishlist',
    },
    {
      icon: MapPin,
      label: t.account.addresses,
      description: t.account.addressesDesc,
      href: '/account/addresses',
    },
    {
      icon: CreditCard,
      label: t.account.paymentMethods,
      description: t.account.paymentMethodsDesc,
      href: '/account/payment',
    },
    {
      icon: Settings,
      label: t.account.settings,
      description: t.account.settingsDesc,
      href: '/account/settings',
    },
  ];

  const firstName = user.user_metadata?.first_name || '';
  const lastName = user.user_metadata?.last_name || '';
  const displayName = firstName && lastName 
    ? `${firstName} ${lastName}` 
    : user.email?.split('@')[0] || t.account.customer;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>{t.account.backToStore}</span>
          </Link>
          <Link to="/">
            <img src={logo} alt="RST" className="h-8" />
          </Link>
          <div className="w-24" /> {/* Spacer for centering */}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-heading font-bold mb-2">
              {t.account.welcome}, {displayName}
            </h1>
            <p className="text-muted-foreground">
              {user.email}
            </p>
          </div>

          {/* Menu Items */}
          <div className="bg-card border border-border divide-y divide-border">
            {menuItems.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className="flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-secondary flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <div>
                    <p className="font-medium">{item.label}</p>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground transition-colors" />
              </Link>
            ))}
          </div>

          <Separator className="my-8" />

          {/* Logout Button */}
          <Button
            variant="outline"
            onClick={handleSignOut}
            disabled={isLoggingOut}
            className="w-full border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
          >
            {isLoggingOut ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {t.account.loggingOut}
              </>
            ) : (
              <>
                <LogOut className="w-4 h-4 mr-2" />
                {t.account.logout}
              </>
            )}
          </Button>

          {/* Quick Links */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link
              to="/shop"
              className="bg-primary p-6 hover:bg-primary/90 transition-colors group"
            >
              <h3 className="font-heading font-bold text-lg text-primary-foreground mb-1">
                {t.account.continueShoppingTitle}
              </h3>
              <p className="text-primary-foreground/80 text-sm">
                {t.account.continueShoppingDesc}
              </p>
            </Link>
            <Link
              to="/contact"
              className="bg-secondary p-6 hover:bg-secondary/80 transition-colors group border border-border"
            >
              <h3 className="font-heading font-bold text-lg mb-1">
                {t.account.needHelpTitle}
              </h3>
              <p className="text-muted-foreground text-sm">
                {t.account.needHelpDesc}
              </p>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Account;
