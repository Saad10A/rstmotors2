import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send, 
  Instagram, 
  Facebook, 
  Youtube,
  ChevronDown,
  Wrench,
  Car,
  Settings,
  HelpCircle
} from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import SEO from "@/components/SEO";

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent",
      description: "We'll get back to you as soon as possible.",
    });
    setFormData({ name: "", email: "", phone: "", service: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const faqs = [
    {
      question: "What types of vehicles do you tune?",
      answer: "We specialize in European performance vehicles including Audi, BMW, Mercedes-Benz, and Porsche. Our expertise covers both naturally aspirated and turbocharged engines."
    },
    {
      question: "How long does a performance tune take?",
      answer: "Most ECU remaps can be completed within 2-4 hours. More comprehensive builds including hardware upgrades may take 1-5 business days depending on the scope of work."
    },
    {
      question: "Do you offer warranties on your work?",
      answer: "Yes, all our tuning services come with a comprehensive warranty. ECU tunes include a lifetime software warranty, and hardware installations are covered for 2 years."
    },
    {
      question: "Can I schedule a consultation before committing?",
      answer: "Absolutely! We offer free consultations to discuss your goals, budget, and the best options for your vehicle. Use the form above or call us directly."
    },
  ];

  const services = [
    { value: "ecu-tuning", label: "ECU Tuning" },
    { value: "exhaust", label: "Exhaust Systems" },
    { value: "suspension", label: "Suspension & Handling" },
    { value: "wheels", label: "Wheels & Tires" },
    { value: "bodykit", label: "Body Kits & Aero" },
    { value: "interior", label: "Interior Upgrades" },
    { value: "other", label: "Other Inquiry" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEO 
        title="Contact Us"
        description="Get in touch with RST Motors for automotive tuning consultations, service inquiries, and performance upgrades. Expert advice for your vehicle."
        keywords="contact RST Motors, car tuning consultation, automotive service inquiry, performance upgrade quote"
        url="/contact"
      />
      <Header />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 px-4 md:px-6 bg-secondary overflow-hidden">
        {/* Diagonal accent */}
        <div className="absolute top-0 right-0 w-1/3 h-full bg-primary/5 -skew-x-12 translate-x-20" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary/10 -skew-x-12 -translate-x-20 translate-y-20" />
        
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <div className="inline-block -skew-x-12 bg-primary px-6 py-2 mb-6">
            <span className="block skew-x-12 text-primary-foreground font-bold uppercase tracking-wider text-sm">
              Get in Touch
            </span>
          </div>
          <h1 className="font-heading text-5xl md:text-7xl font-bold text-foreground uppercase tracking-tight">
            Contact Us
          </h1>
          <p className="text-muted-foreground mt-6 max-w-2xl mx-auto text-lg">
            Ready to unleash your vehicle's true potential? Our team of experts is here to help you achieve peak performance.
          </p>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-16 md:py-24 px-4 md:px-6">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-5 gap-12">
          {/* Contact Form */}
          <div className="lg:col-span-3 bg-secondary -skew-x-3 p-1 shadow-[0_0_30px_hsl(var(--primary)/0.1)]">
            <div className="skew-x-3 p-6 md:p-10">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-12 h-12 bg-primary -skew-x-12 flex items-center justify-center">
                  <Send className="w-5 h-5 text-primary-foreground skew-x-12" />
                </div>
                <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground uppercase">
                  Send a Message
                </h2>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm text-muted-foreground uppercase tracking-wider mb-2 block font-bold">
                      Name *
                    </label>
                    <Input
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="bg-background border-border h-12"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground uppercase tracking-wider mb-2 block font-bold">
                      Email *
                    </label>
                    <Input
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="bg-background border-border h-12"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>
                
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm text-muted-foreground uppercase tracking-wider mb-2 block font-bold">
                      Phone
                    </label>
                    <Input
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="bg-background border-border h-12"
                      placeholder="+1 (555) 000-0000"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground uppercase tracking-wider mb-2 block font-bold">
                      Service Interest *
                    </label>
                    <Select
                      value={formData.service}
                      onValueChange={(value) => setFormData({ ...formData, service: value })}
                    >
                      <SelectTrigger className="bg-background border-border h-12">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent>
                        {services.map((service) => (
                          <SelectItem key={service.value} value={service.value}>
                            {service.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm text-muted-foreground uppercase tracking-wider mb-2 block font-bold">
                    Message *
                  </label>
                  <Textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    className="bg-background border-border min-h-[150px]"
                    placeholder="Tell us about your vehicle and goals..."
                  />
                </div>
                
                <Button type="submit" size="lg" className="w-full sm:w-auto">
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </Button>
              </form>
            </div>
          </div>

          {/* Contact Info Sidebar */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground uppercase mb-4">
                Contact Info
              </h2>
              <p className="text-muted-foreground">
                Visit our showroom or reach out directly. We're here to help transform your driving experience.
              </p>
            </div>

            <div className="space-y-4">
              {[
                { icon: MapPin, title: "Address", content: "123 Performance Drive\nMunich, Germany 80331" },
                { icon: Phone, title: "Phone", content: "+49 89 123 4567" },
                { icon: Mail, title: "Email", content: "info@rstperformance.com" },
                { icon: Clock, title: "Hours", content: "Mon - Fri: 9:00 AM - 6:00 PM\nSat: 10:00 AM - 4:00 PM" },
              ].map((item, index) => (
                <div 
                  key={index} 
                  className="flex items-start gap-4 p-4 bg-secondary -skew-x-3 transition-all hover:shadow-[0_0_20px_hsl(var(--primary)/0.2)] group"
                >
                  <div className="skew-x-3 flex items-start gap-4 w-full">
                    <div className="w-10 h-10 bg-primary/10 -skew-x-12 flex items-center justify-center flex-shrink-0 group-hover:bg-primary transition-colors">
                      <item.icon className="w-5 h-5 text-primary skew-x-12 group-hover:text-primary-foreground transition-colors" />
                    </div>
                    <div>
                      <h3 className="font-heading font-bold text-foreground uppercase text-sm">{item.title}</h3>
                      <p className="text-muted-foreground text-sm mt-1 whitespace-pre-line">
                        {item.content}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Social Links */}
            <div className="pt-4">
              <h3 className="font-heading font-bold text-foreground uppercase text-sm mb-4">Follow Us</h3>
              <div className="flex gap-3">
                {[
                  { icon: Instagram, href: "#" },
                  { icon: Facebook, href: "#" },
                  { icon: Youtube, href: "#" },
                ].map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    className="w-12 h-12 bg-secondary -skew-x-12 flex items-center justify-center hover:bg-primary transition-colors group"
                  >
                    <social.icon className="w-5 h-5 text-foreground skew-x-12 group-hover:text-primary-foreground transition-colors" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Quick Links */}
      <section className="py-16 md:py-20 px-4 md:px-6 bg-secondary">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground uppercase">
              Our Services
            </h2>
            <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
              Explore our range of performance upgrades and customization options
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Settings, title: "ECU Tuning", desc: "Unlock hidden power" },
              { icon: Wrench, title: "Performance Parts", desc: "Quality upgrades" },
              { icon: Car, title: "Full Builds", desc: "Complete transformations" },
              { icon: HelpCircle, title: "Consultation", desc: "Expert advice" },
            ].map((service, index) => (
              <div 
                key={index}
                className="bg-background -skew-x-3 p-6 text-center hover:shadow-[0_0_30px_hsl(var(--primary)/0.2)] transition-all group cursor-pointer"
              >
                <div className="skew-x-3">
                  <div className="w-14 h-14 bg-primary/10 -skew-x-12 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary transition-colors">
                    <service.icon className="w-6 h-6 text-primary skew-x-12 group-hover:text-primary-foreground transition-colors" />
                  </div>
                  <h3 className="font-heading font-bold text-foreground uppercase">{service.title}</h3>
                  <p className="text-muted-foreground text-sm mt-2">{service.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-block -skew-x-12 bg-primary px-6 py-2 mb-6">
              <span className="block skew-x-12 text-primary-foreground font-bold uppercase tracking-wider text-sm">
                FAQ
              </span>
            </div>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground uppercase">
              Frequently Asked Questions
            </h2>
          </div>
          
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-secondary -skew-x-3 border-none px-1"
              >
                <div className="skew-x-3">
                  <AccordionTrigger className="px-6 py-4 hover:no-underline">
                    <span className="font-heading font-bold text-foreground uppercase text-left text-sm md:text-base">
                      {faq.question}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-4 text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </div>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-20 px-4 md:px-6 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/placeholder.svg')] opacity-5" />
        <div className="absolute top-0 left-0 w-1/2 h-full bg-background/5 -skew-x-12 -translate-x-40" />
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 className="font-heading text-3xl md:text-5xl font-bold text-primary-foreground uppercase">
            Ready to Transform Your Ride?
          </h2>
          <p className="text-primary-foreground/80 mt-4 mb-8 text-lg">
            Book a consultation today and let's discuss your performance goals.
          </p>
          <Button variant="outline" size="lg" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
            Schedule Consultation
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;
