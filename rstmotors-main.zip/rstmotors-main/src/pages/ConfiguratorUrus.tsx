import { useState } from "react";
import { Link } from "react-router-dom";
import { 
  ArrowLeft, 
  Gauge, 
  Timer, 
  Zap, 
  Check, 
  Share2, 
  Heart,
  RotateCcw,
} from "lucide-react";
import urusCar from "@/assets/urus-front.jpg";
import logo from "@/assets/logo.png";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useLanguage } from "@/i18n/LanguageContext";

const ConfiguratorUrus = () => {
  const { t } = useLanguage();
  const [selectedColor, setSelectedColor] = useState("black");
  const [selectedPackage, setSelectedPackage] = useState("performance");
  const [selectedWheel, setSelectedWheel] = useState("sport");
  const [selectedInterior, setSelectedInterior] = useState("black-leather");
  const [features, setFeatures] = useState({
    carbonPackage: false,
    sportExhaust: true,
    ceramicBrakes: false,
    adaptiveSuspension: true,
  });

  const colors = [
    { id: "black", name: "Nero Noctis", hex: "#0a0a0a" },
    { id: "white", name: "Bianco Monocerus", hex: "#f5f5f5" },
    { id: "yellow", name: "Giallo Auge", hex: "#f5c400" },
    { id: "green", name: "Verde Mantis", hex: "#00cc66" },
    { id: "grey", name: "Grigio Titans", hex: "#5a5a5a" },
  ];

  const packages = [
    { id: "performance", name: "RST Performance", price: "4,999", hp: "700", torque: "880" },
    { id: "sport", name: "RST Sport+", price: "7,999", hp: "740", torque: "920" },
    { id: "ultimate", name: "RST Ultimate", price: "12,999", hp: "800", torque: "1000" },
  ];

  const wheels = [
    { id: "sport", name: '23" RST Forged Sport', price: "0" },
    { id: "performance", name: '24" RST Performance', price: "2,500" },
    { id: "carbon", name: '24" RST Carbon Ceramic', price: "5,500" },
  ];

  const interiors = [
    { id: "black-leather", name: "Nero Ade Full Leather", price: "0" },
    { id: "red-leather", name: "Rosso Alala Leather", price: "2,500" },
    { id: "alcantara", name: "Alcantara Sport Package", price: "3,800" },
  ];

  const optionalFeatures = [
    { id: "carbonPackage", name: "Full Carbon Widebody Kit", price: "18,500", desc: "Complete aero package with extended fenders" },
    { id: "sportExhaust", name: "Titanium Sport Exhaust", price: "4,800", desc: "Race-spec titanium exhaust system" },
    { id: "ceramicBrakes", name: "Carbon Ceramic Brakes", price: "12,500", desc: "Track-ready ceramic brake system" },
    { id: "adaptiveSuspension", name: "Air Suspension Pro", price: "3,500", desc: "Adjustable ride height system" },
  ];

  const selectedPkg = packages.find((p) => p.id === selectedPackage);

  const calculateTotal = () => {
    let total = 129900;
    const pkg = packages.find(p => p.id === selectedPackage);
    if (pkg) total += parseInt(pkg.price.replace(",", ""));
    
    const wheel = wheels.find(w => w.id === selectedWheel);
    if (wheel) total += parseInt(wheel.price.replace(",", ""));
    
    const interior = interiors.find(i => i.id === selectedInterior);
    if (interior) total += parseInt(interior.price.replace(",", ""));
    
    if (features.carbonPackage) total += 18500;
    if (features.sportExhaust) total += 4800;
    if (features.ceramicBrakes) total += 12500;
    if (features.adaptiveSuspension) total += 3500;
    
    return total.toLocaleString();
  };

  return (
    <TooltipProvider>
      <div className="h-screen bg-background flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex-shrink-0 flex items-center justify-between px-6 md:px-12 py-3 bg-background border-b border-border/20">
          <Link to="/models" className="flex items-center gap-3 text-foreground hover:text-primary transition-colors group">
            <div className="w-8 h-8 bg-secondary -skew-x-12 flex items-center justify-center group-hover:bg-primary transition-colors">
              <ArrowLeft className="w-4 h-4 skew-x-12" />
            </div>
            <span className="font-heading text-xs tracking-wider hidden md:inline">{t.configuratorPage.back}</span>
          </Link>
          <Link to="/">
            <img src={logo} alt="RST Performance" className="h-5 md:h-6" />
          </Link>
          <div className="flex gap-2">
            <button className="w-8 h-8 bg-secondary -skew-x-12 flex items-center justify-center hover:bg-primary transition-colors group">
              <Heart className="w-4 h-4 skew-x-12 group-hover:text-primary-foreground" />
            </button>
            <button className="w-8 h-8 bg-secondary -skew-x-12 flex items-center justify-center hover:bg-primary transition-colors group">
              <Share2 className="w-4 h-4 skew-x-12 group-hover:text-primary-foreground" />
            </button>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Car Display - Left Side */}
          <div className="lg:w-[65%] xl:w-[70%] relative flex items-center justify-center p-6 lg:p-12 flex-shrink-0 h-[40vh] lg:h-full bg-gradient-to-br from-background via-background to-secondary/20">
            {/* Diagonal accent */}
            <div className="absolute top-0 right-0 w-32 h-full bg-primary/5 -skew-x-12 translate-x-16 hidden lg:block" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary/5 -skew-x-12 -translate-x-32 translate-y-32" />
            
            {/* Car Image */}
            <div className="relative w-full max-w-4xl">
              <div className="absolute -inset-8 bg-primary/5 blur-3xl rounded-full" />
              <img
                src={urusCar}
                alt="URUS RST"
                className="relative w-full h-auto object-contain drop-shadow-2xl"
              />
              
              {/* Color indicator */}
              <div className="absolute top-4 right-4 bg-background/80 backdrop-blur-sm -skew-x-12 px-4 py-2">
                <div className="skew-x-12 flex items-center gap-2">
                  <div 
                    className="w-4 h-4 rounded-full border border-border"
                    style={{ backgroundColor: colors.find(c => c.id === selectedColor)?.hex }}
                  />
                  <span className="text-xs text-foreground font-medium">
                    {colors.find(c => c.id === selectedColor)?.name}
                  </span>
                </div>
              </div>
            </div>

            {/* Specs Bar */}
            <div className="absolute bottom-4 lg:bottom-8 left-4 lg:left-16 right-4 lg:right-auto">
              <div className="flex gap-4 md:gap-8">
                {[
                  { icon: Zap, value: selectedPkg?.hp || "700", label: t.configuratorPage.hp },
                  { icon: Timer, value: "3.1", label: "0-100 KM/H" },
                  { icon: Gauge, value: "310", label: t.configuratorPage.topSpeed },
                ].map((stat, index) => (
                  <div 
                    key={index}
                    className="bg-background/80 backdrop-blur-sm -skew-x-12 px-4 py-3 border-l-2 border-primary"
                  >
                    <div className="skew-x-12 flex items-center gap-3">
                      <stat.icon className="w-5 h-5 text-primary hidden md:block" />
                      <div>
                        <p className="font-heading text-xl md:text-2xl font-bold text-foreground">{stat.value}</p>
                        <p className="text-[10px] text-muted-foreground tracking-wider">{stat.label}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Reset button */}
            <button className="absolute top-4 left-4 lg:top-8 lg:left-16 bg-background/80 backdrop-blur-sm -skew-x-12 px-4 py-2 hover:bg-primary transition-colors group">
              <div className="skew-x-12 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 group-hover:text-primary-foreground" />
                <span className="text-xs font-medium group-hover:text-primary-foreground hidden md:inline">{t.configuratorPage.reset}</span>
              </div>
            </button>
          </div>

          {/* Configuration Panel - Right Side */}
          <div className="lg:w-[35%] xl:w-[30%] bg-card/50 backdrop-blur-sm flex flex-col overflow-hidden flex-1 lg:flex-none lg:h-full">
            <div className="flex-1 overflow-y-auto p-6 lg:p-8">
              {/* Model Title */}
              <div className="mb-6">
                <div className="inline-block -skew-x-12 bg-primary px-4 py-1 mb-3">
                  <span className="block skew-x-12 text-primary-foreground font-bold uppercase tracking-wider text-xs">
                    {t.configuratorPage.configureYour}
                  </span>
                </div>
                <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground uppercase">
                  URUS RST
                </h2>
                <p className="text-muted-foreground mt-2 text-sm leading-relaxed">
                  The ultimate super SUV with RST Performance engineering. Unleash 800HP of pure power.
                </p>
              </div>

              {/* Tabs */}
              <Tabs defaultValue="package" className="w-full">
                <TabsList className="w-full grid grid-cols-4 bg-secondary/50 p-1 mb-6">
                  <TabsTrigger value="package" className="text-xs">{t.configuratorPage.tabPackage}</TabsTrigger>
                  <TabsTrigger value="exterior" className="text-xs">{t.configuratorPage.tabExterior}</TabsTrigger>
                  <TabsTrigger value="interior" className="text-xs">{t.configuratorPage.tabInterior}</TabsTrigger>
                  <TabsTrigger value="options" className="text-xs">{t.configuratorPage.tabOptions}</TabsTrigger>
                </TabsList>

                {/* Package Tab */}
                <TabsContent value="package" className="space-y-4 mt-0">
                  <label className="text-xs text-muted-foreground tracking-wider font-bold block">
                    {t.configuratorPage.performancePackage}
                  </label>
                  <div className="space-y-3">
                    {packages.map((pkg) => (
                      <button
                        key={pkg.id}
                        onClick={() => setSelectedPackage(pkg.id)}
                        className={`w-full -skew-x-3 p-1 transition-all ${
                          selectedPackage === pkg.id
                            ? "bg-primary shadow-[0_0_20px_hsl(var(--primary)/0.4)]"
                            : "bg-secondary hover:bg-secondary/80"
                        }`}
                      >
                        <div className="skew-x-3 flex items-center justify-between px-4 py-3">
                          <div className="text-left">
                            <span className={`font-heading font-bold block ${
                              selectedPackage === pkg.id ? "text-primary-foreground" : "text-foreground"
                            }`}>
                              {pkg.name}
                            </span>
                            <span className={`text-xs ${
                              selectedPackage === pkg.id ? "text-primary-foreground/70" : "text-muted-foreground"
                            }`}>
                              {pkg.hp} {t.configuratorPage.hp} • {pkg.torque} Nm
                            </span>
                          </div>
                          <div className="text-right">
                            <span className={`font-bold ${
                              selectedPackage === pkg.id ? "text-primary-foreground" : "text-primary"
                            }`}>
                              €{pkg.price}
                            </span>
                            {selectedPackage === pkg.id && (
                              <Check className="w-4 h-4 text-primary-foreground ml-2 inline" />
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </TabsContent>

                {/* Exterior Tab */}
                <TabsContent value="exterior" className="space-y-6 mt-0">
                  {/* Color Selection */}
                  <div>
                    <label className="text-xs text-muted-foreground tracking-wider font-bold mb-3 block">
                      {t.configuratorPage.exteriorColor}
                    </label>
                    <div className="flex gap-3 mb-2">
                      {colors.map((color) => (
                        <button
                          key={color.id}
                          onClick={() => setSelectedColor(color.id)}
                          className={`w-10 h-10 -skew-x-12 transition-all ${
                            selectedColor === color.id
                              ? "ring-2 ring-primary ring-offset-2 ring-offset-background scale-110"
                              : "hover:scale-105"
                          }`}
                          style={{ backgroundColor: color.hex }}
                          title={color.name}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-foreground font-medium">
                      {colors.find((c) => c.id === selectedColor)?.name}
                    </p>
                  </div>

                  {/* Wheel Selection */}
                  <div>
                    <label className="text-xs text-muted-foreground tracking-wider font-bold mb-3 block">
                      {t.configuratorPage.wheels}
                    </label>
                    <div className="space-y-2">
                      {wheels.map((wheel) => (
                        <button
                          key={wheel.id}
                          onClick={() => setSelectedWheel(wheel.id)}
                          className={`w-full -skew-x-3 p-1 transition-all ${
                            selectedWheel === wheel.id
                              ? "bg-primary"
                              : "bg-secondary hover:bg-secondary/80"
                          }`}
                        >
                          <div className="skew-x-3 flex items-center justify-between px-4 py-3">
                            <span className={`font-medium ${
                              selectedWheel === wheel.id ? "text-primary-foreground" : "text-foreground"
                            }`}>
                              {wheel.name}
                            </span>
                            <span className={`text-sm ${
                              selectedWheel === wheel.id ? "text-primary-foreground" : "text-primary"
                            }`}>
                              {wheel.price === "0" ? t.configuratorPage.included : `+€${wheel.price}`}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                {/* Interior Tab */}
                <TabsContent value="interior" className="space-y-4 mt-0">
                  <label className="text-xs text-muted-foreground tracking-wider font-bold block">
                    {t.configuratorPage.interiorTrim}
                  </label>
                  <div className="space-y-2">
                    {interiors.map((interior) => (
                      <button
                        key={interior.id}
                        onClick={() => setSelectedInterior(interior.id)}
                        className={`w-full -skew-x-3 p-1 transition-all ${
                          selectedInterior === interior.id
                            ? "bg-primary"
                            : "bg-secondary hover:bg-secondary/80"
                        }`}
                      >
                        <div className="skew-x-3 flex items-center justify-between px-4 py-3">
                          <span className={`font-medium ${
                            selectedInterior === interior.id ? "text-primary-foreground" : "text-foreground"
                          }`}>
                            {interior.name}
                          </span>
                          <span className={`text-sm ${
                            selectedInterior === interior.id ? "text-primary-foreground" : "text-primary"
                          }`}>
                            {interior.price === "0" ? t.configuratorPage.included : `+€${interior.price}`}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </TabsContent>

                {/* Options Tab */}
                <TabsContent value="options" className="space-y-4 mt-0">
                  <label className="text-xs text-muted-foreground tracking-wider font-bold block">
                    {t.configuratorPage.optionalFeatures}
                  </label>
                  <div className="space-y-3">
                    {optionalFeatures.map((feature) => (
                      <div
                        key={feature.id}
                        className={`-skew-x-3 p-1 transition-all ${
                          features[feature.id as keyof typeof features]
                            ? "bg-primary/20 border border-primary"
                            : "bg-secondary"
                        }`}
                      >
                        <div className="skew-x-3 flex items-center justify-between px-4 py-3">
                          <div className="flex items-center gap-3">
                            <Switch
                              checked={features[feature.id as keyof typeof features]}
                              onCheckedChange={(checked) =>
                                setFeatures({ ...features, [feature.id]: checked })
                              }
                            />
                            <div>
                              <span className="font-medium text-foreground text-sm block">
                                {feature.name}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {feature.desc}
                              </span>
                            </div>
                          </div>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="text-sm text-primary font-bold">
                                +€{feature.price}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{feature.desc}</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Price & CTA - Fixed at bottom */}
            <div className="flex-shrink-0 border-t border-border p-6 lg:p-8 bg-card/80 backdrop-blur-sm">
              <div className="flex items-end justify-between mb-4">
                <div>
                  <p className="text-xs text-muted-foreground tracking-wider">{t.configuratorPage.totalPrice}</p>
                  <p className="font-heading text-3xl font-bold text-foreground">
                    €{calculateTotal()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">{t.configuratorPage.orFrom}</p>
                  <p className="text-lg font-bold text-primary">
                    €{Math.round(parseInt(calculateTotal().replace(",", "")) / 48).toLocaleString()}{t.configuratorPage.perMonth}
                  </p>
                </div>
              </div>
              <Button className="w-full mb-3" size="lg">
                {t.configuratorPage.requestQuote}
              </Button>
              <Button variant="outline" className="w-full" size="lg">
                {t.configuratorPage.scheduleTestDrive}
              </Button>
            </div>
          </div>
        </main>
      </div>
    </TooltipProvider>
  );
};

export default ConfiguratorUrus;
