import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, SlidersHorizontal, X, Gauge, Fuel, Calendar, MapPin, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useLanguage } from "@/i18n/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

interface Car {
  id: string;
  title: string;
  subtitle: string | null;
  price: number;
  mileage: number | null;
  registration_year: number | null;
  fuel_type: string | null;
  body_type: string | null;
  engine: string | null;
  gearbox: string | null;
  power: string | null;
  images: string[];
  seller_location: string | null;
  is_featured: boolean | null;
  is_sold: boolean | null;
  // Note: seller_phone, seller_name, registration_plate are excluded from cars_public view for privacy
}

const bodyTypes = ["All", "Coupe", "Hatchback", "SUV", "Sedan", "Convertible", "Estate"];
const fuelTypes = ["All", "Petrol", "Diesel", "Electric", "Hybrid"];
const sortOptions = [
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "mileage-asc", label: "Mileage: Low to High" },
  { value: "year-desc", label: "Year: Newest First" },
];

const Cars = () => {
  const { t } = useLanguage();
  const [cars, setCars] = useState<Car[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState("price-asc");
  
  // Filter states
  const [priceRange, setPriceRange] = useState([0, 250000]);
  const [mileageRange, setMileageRange] = useState([0, 100000]);
  const [selectedBodyType, setSelectedBodyType] = useState("All");
  const [selectedFuelType, setSelectedFuelType] = useState("All");

  useEffect(() => {
    fetchCars();
  }, []);

  const fetchCars = async () => {
    try {
      // Use cars_public view which excludes sensitive PII (seller_phone, seller_name, registration_plate)
      const { data, error } = await supabase
        .from("cars_public")
        .select("*")
        .eq("is_sold", false)
        .order("is_featured", { ascending: false });

      if (error) throw error;
      setCars(data || []);
    } catch (error) {
      console.error("Error fetching cars:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCars = cars
    .filter((car) => {
      const matchesSearch = car.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (car.subtitle && car.subtitle.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesPrice = car.price >= priceRange[0] && car.price <= priceRange[1];
      const matchesMileage = !car.mileage || (car.mileage >= mileageRange[0] && car.mileage <= mileageRange[1]);
      const matchesBodyType = selectedBodyType === "All" || car.body_type === selectedBodyType;
      const matchesFuelType = selectedFuelType === "All" || car.fuel_type === selectedFuelType;
      
      return matchesSearch && matchesPrice && matchesMileage && matchesBodyType && matchesFuelType;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price-asc":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "mileage-asc":
          return (a.mileage || 0) - (b.mileage || 0);
        case "year-desc":
          return (b.registration_year || 0) - (a.registration_year || 0);
        default:
          return 0;
      }
    });

  const resetFilters = () => {
    setPriceRange([0, 250000]);
    setMileageRange([0, 100000]);
    setSelectedBodyType("All");
    setSelectedFuelType("All");
    setSearchQuery("");
  };

  const activeFilterCount = [
    priceRange[0] > 0 || priceRange[1] < 250000,
    mileageRange[0] > 0 || mileageRange[1] < 100000,
    selectedBodyType !== "All",
    selectedFuelType !== "All",
  ].filter(Boolean).length;

  return (
    <div className="min-h-screen bg-background">
      <SEO 
        title="Vehicles for Sale"
        description="Browse premium performance vehicles for sale at RST Motors. Find your perfect tuned car from our curated selection of high-performance automobiles."
        keywords="cars for sale, performance vehicles, tuned cars, luxury cars, RST Motors vehicles"
        url="/cars"
      />
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-[40vh] w-full overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=1920&q=80"
          alt="Vehicles for Sale"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        <div className="absolute bottom-8 left-8 md:left-16">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-foreground uppercase">
            Vehicles for Sale
          </h1>
          <p className="text-muted-foreground text-lg mt-2">
            {cars.length} premium performance vehicles available
          </p>
        </div>
      </section>

      {/* Search & Filters Bar */}
      <div className="sticky top-12 md:top-14 z-30 bg-card border-b border-border py-4">
        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search by make, model..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-secondary border-border"
              />
            </div>
            
            {/* Filter Toggle */}
            <Button
              variant={showFilters ? "default" : "outline"}
              onClick={() => setShowFilters(!showFilters)}
              className="gap-2"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Filters</span>
              {activeFilterCount > 0 && (
                <span className="bg-primary-foreground text-primary px-2 py-0.5 text-xs font-bold">
                  {activeFilterCount}
                </span>
              )}
            </Button>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-[200px] bg-secondary border-border">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Expanded Filters */}
          {showFilters && (
            <div className="mt-4 p-6 bg-secondary border border-border animate-in slide-in-from-top-2">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Price Range */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-foreground">
                    Price Range: £{priceRange[0].toLocaleString()} - £{priceRange[1].toLocaleString()}
                  </label>
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    min={0}
                    max={250000}
                    step={5000}
                    className="mt-2"
                  />
                </div>

                {/* Mileage Range */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-foreground">
                    Mileage: {mileageRange[0].toLocaleString()} - {mileageRange[1].toLocaleString()} miles
                  </label>
                  <Slider
                    value={mileageRange}
                    onValueChange={setMileageRange}
                    min={0}
                    max={100000}
                    step={5000}
                    className="mt-2"
                  />
                </div>

                {/* Body Type */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-foreground">Body Type</label>
                  <Select value={selectedBodyType} onValueChange={setSelectedBodyType}>
                    <SelectTrigger className="bg-card border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {bodyTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Fuel Type */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-foreground">Fuel Type</label>
                  <Select value={selectedFuelType} onValueChange={setSelectedFuelType}>
                    <SelectTrigger className="bg-card border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {fuelTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <Button variant="ghost" onClick={resetFilters} className="gap-2">
                  <X className="w-4 h-4" />
                  Reset Filters
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Cars Grid */}
      <section className="py-12 px-4 md:px-8 lg:px-16 max-w-7xl mx-auto">
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-card border border-border animate-pulse">
                <div className="h-48 bg-muted" />
                <div className="p-4 space-y-3">
                  <div className="h-6 bg-muted w-3/4" />
                  <div className="h-4 bg-muted w-1/2" />
                  <div className="h-8 bg-muted w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredCars.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-muted-foreground text-lg">No vehicles found matching your criteria.</p>
            <Button variant="outline" onClick={resetFilters} className="mt-4">
              Reset Filters
            </Button>
          </div>
        ) : (
          <>
            <p className="text-muted-foreground mb-6">{filteredCars.length} vehicles found</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCars.map((car) => (
                <Link
                  key={car.id}
                  to={`/cars/${car.id}`}
                  className="group bg-card border border-border hover:border-primary/50 transition-all duration-300 overflow-hidden"
                >
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={car.images?.[0] || "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&q=80"}
                      alt={car.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {car.is_featured && (
                      <div className="absolute top-2 left-2 bg-primary text-primary-foreground px-3 py-1 text-xs font-bold uppercase">
                        Featured
                      </div>
                    )}
                    <div className="absolute bottom-2 right-2 bg-background/80 px-2 py-1 text-xs">
                      {car.images?.length || 1} photos
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-4 space-y-3">
                    <div>
                      <h3 className="font-heading text-lg font-bold text-foreground group-hover:text-primary transition-colors">
                        {car.title}
                      </h3>
                      {car.subtitle && (
                        <p className="text-muted-foreground text-sm">{car.subtitle}</p>
                      )}
                    </div>

                    <p className="text-2xl font-bold text-primary">
                      £{car.price.toLocaleString()}
                    </p>

                    {/* Quick Specs */}
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Gauge className="w-4 h-4" />
                        <span>{car.mileage?.toLocaleString() || "N/A"} mi</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4" />
                        <span>{car.registration_year || "N/A"}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Fuel className="w-4 h-4" />
                        <span>{car.fuel_type || "N/A"}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        <span>{car.seller_location || "N/A"}</span>
                      </div>
                    </div>

                    {car.power && (
                      <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                        <span className="text-primary">{car.power}</span>
                        {car.gearbox && <span>• {car.gearbox}</span>}
                      </div>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          </>
        )}
      </section>

      <Footer />
    </div>
  );
};

export default Cars;
