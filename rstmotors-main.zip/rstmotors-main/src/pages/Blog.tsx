import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Calendar, ArrowRight } from "lucide-react";
import { useLanguage } from "@/i18n/LanguageContext";
import SEO from "@/components/SEO";

const Blog = () => {
  const scrollRef = useScrollAnimation();
  const { t, language } = useLanguage();

  const blogPosts = [
    {
      id: 1,
      title: language === 'it' ? "Il Futuro del Tuning per Veicoli Elettrici" : "The Future of Electric Performance Tuning",
      excerpt: language === 'it' 
        ? "Con la crescente diffusione dei veicoli elettrici, esploriamo le nuove ed entusiasmanti frontiere della modifica prestazionale degli EV."
        : "As electric vehicles become more prevalent, we explore the exciting new frontiers of EV performance modification and what it means for enthusiasts.",
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800&q=80",
      date: "2024-12-10",
      category: t.blog.categoryTechnology,
    },
    {
      id: 2,
      title: language === 'it' ? "5 Upgrade Essenziali per la Tua Audi RS" : "5 Essential Upgrades for Your Audi RS",
      excerpt: language === 'it'
        ? "Scopri le migliori modifiche che trasformeranno la tua Audi RS in una macchina ancora più formidabile su strada e in pista."
        : "Discover the top modifications that will transform your Audi RS into an even more formidable machine on both road and track.",
      image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80",
      date: "2024-12-05",
      category: t.blog.categoryGuides,
    },
    {
      id: 3,
      title: language === 'it' ? "Dietro le Quinte: Il Nostro Ultimo Build RS7" : "Behind the Scenes: Our Latest RS7 Build",
      excerpt: language === 'it'
        ? "Uno sguardo esclusivo al nostro recente progetto RS7, con carrozzeria personalizzata, upgrade prestazionali e rifiniture interne su misura."
        : "Take an exclusive look at our recent RS7 project, featuring custom bodywork, performance upgrades, and bespoke interior refinements.",
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80",
      date: "2024-11-28",
      category: t.blog.categoryBuilds,
    },
    {
      id: 4,
      title: language === 'it' ? "Fibra di Carbonio: Perché il Peso Conta" : "Carbon Fiber: Why Weight Matters",
      excerpt: language === 'it'
        ? "Un'analisi approfondita su come i componenti in fibra di carbonio possono migliorare prestazioni, maneggevolezza ed efficienza del veicolo."
        : "An in-depth look at how carbon fiber components can improve your vehicle's performance, handling, and efficiency.",
      image: "https://images.unsplash.com/photo-1547038577-da80abbc4f19?w=800&q=80",
      date: "2024-11-20",
      category: t.blog.categoryTechnology,
    },
    {
      id: 5,
      title: language === 'it' ? "Guida alla Preparazione per il Track Day" : "Track Day Preparation Guide",
      excerpt: language === 'it'
        ? "Tutto quello che devi sapere prima di portare il tuo veicolo elaborato in pista, dai controlli di sicurezza all'ottimizzazione delle prestazioni."
        : "Everything you need to know before taking your tuned vehicle to the track, from safety checks to performance optimization.",
      image: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800&q=80",
      date: "2024-11-15",
      category: t.blog.categoryGuides,
    },
    {
      id: 6,
      title: language === 'it' ? "L'Arte del Tuning dello Scarico" : "The Art of Exhaust Tuning",
      excerpt: language === 'it'
        ? "Come un sistema di scarico progettato correttamente può liberare potenza nascosta offrendo al contempo l'esperienza acustica perfetta."
        : "How a properly designed exhaust system can unlock hidden power while delivering the perfect acoustic experience.",
      image: "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800&q=80",
      date: "2024-11-08",
      category: t.blog.categoryTechnology,
    },
  ];

  const dateLocale = language === 'it' ? 'it-IT' : 'en-US';

  return (
    <div className="min-h-screen bg-background" ref={scrollRef}>
      <SEO 
        title="Blog"
        description="Read the latest news, guides, and insights about automotive tuning, performance upgrades, and car customization from RST Motors experts."
        keywords="car tuning blog, automotive news, performance guides, car customization tips, RST Motors blog"
        url="/blog"
      />
      <Header />
      
      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12 animate-fade-in">
            <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
              {t.blog.title}
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              {t.blog.subtitle}
            </p>
          </div>

          {/* Featured Post */}
          <Link 
            to={`/blog/${blogPosts[0].id}`}
            className="block group mb-12 animate-on-scroll"
          >
            <div className="relative aspect-[21/9] overflow-hidden rounded-lg">
              <img
                src={blogPosts[0].image}
                alt={blogPosts[0].title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <span className="text-primary text-sm font-medium mb-2 block">
                  {blogPosts[0].category}
                </span>
                <h2 className="font-heading text-2xl md:text-4xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                  {blogPosts[0].title}
                </h2>
                <p className="text-muted-foreground max-w-2xl mb-4 hidden md:block">
                  {blogPosts[0].excerpt}
                </p>
                <div className="flex items-center text-muted-foreground text-sm">
                  <Calendar className="w-4 h-4 mr-2" />
                  {new Date(blogPosts[0].date).toLocaleDateString(dateLocale, { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </div>
              </div>
            </div>
          </Link>

          {/* Post Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.slice(1).map((post, index) => (
              <Link
                key={post.id}
                to={`/blog/${post.id}`}
                className="group animate-on-scroll"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="aspect-[16/10] overflow-hidden rounded-lg mb-4">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <span className="text-primary text-sm font-medium mb-2 block">
                  {post.category}
                </span>
                <h3 className="font-heading text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {post.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    {new Date(post.date).toLocaleDateString(dateLocale, { 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </span>
                  <span className="text-primary flex items-center group-hover:gap-2 transition-all">
                    {t.blog.readMore} <ArrowRight className="w-4 h-4 ml-1" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Blog;