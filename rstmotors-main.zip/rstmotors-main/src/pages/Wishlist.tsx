import { Link } from "react-router-dom";
import { Heart, ShoppingCart, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useWishlistStore } from "@/stores/wishlistStore";
import { useCartStore } from "@/stores/cartStore";
import { useLanguage } from "@/i18n/LanguageContext";
import { toast } from "sonner";

const Wishlist = () => {
  const { t } = useLanguage();
  const { items, removeItem, clearWishlist } = useWishlistStore();
  const addToCart = useCartStore(state => state.addItem);

  const handleAddToCart = (product: typeof items[0]) => {
    const firstVariant = product.node.variants.edges[0]?.node;
    if (!firstVariant) return;

    addToCart({
      product,
      variantId: firstVariant.id,
      variantTitle: firstVariant.title,
      price: firstVariant.price,
      quantity: 1,
      selectedOptions: firstVariant.selectedOptions || []
    });

    toast.success(t.productDetail.addedToCart, {
      description: product.node.title,
      position: "top-center"
    });
  };

  const handleRemove = (productId: string, title: string) => {
    removeItem(productId);
    toast.success(t.productDetail.removedFromWishlist, {
      description: title,
      position: "top-center"
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
                {t.wishlist.title}
              </h1>
              <p className="text-muted-foreground mt-2">
                {items.length === 0 
                  ? t.wishlist.emptyMessage 
                  : `${items.length} ${items.length === 1 ? t.wishlist.item : t.wishlist.items}`
                }
              </p>
            </div>
            {items.length > 0 && (
              <Button 
                variant="outline" 
                onClick={() => {
                  clearWishlist();
                  toast.success(t.wishlist.cleared, { position: "top-center" });
                }}
              >
                {t.wishlist.clearAll}
              </Button>
            )}
          </div>

          {items.length === 0 ? (
            <div className="text-center py-20">
              <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-6" />
              <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
                {t.wishlist.emptyTitle}
              </h2>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                {t.wishlist.emptyDescription}
              </p>
              <Link to="/shop">
                <Button size="lg">
                  {t.wishlist.continueShopping}
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {items.map((product) => {
                const { node } = product;
                const firstImage = node.images.edges[0]?.node;
                const price = node.priceRange.minVariantPrice;
                const firstVariant = node.variants.edges[0]?.node;
                const compareAtPrice = firstVariant?.compareAtPrice;

                return (
                  <div 
                    key={node.id}
                    className="bg-card border border-border rounded-lg overflow-hidden group"
                  >
                    <Link to={`/product/${node.handle}`}>
                      <div className="aspect-square bg-muted/10 overflow-hidden relative">
                        {firstImage ? (
                          <img
                            src={firstImage.url}
                            alt={firstImage.altText || node.title}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                            <ShoppingCart className="w-12 h-12" />
                          </div>
                        )}
                      </div>
                    </Link>

                    <div className="p-4">
                      <Link to={`/product/${node.handle}`}>
                        <h3 className="font-heading text-lg font-bold text-foreground line-clamp-1 hover:text-primary transition-colors">
                          {node.title}
                        </h3>
                      </Link>
                      <p className="text-muted-foreground text-sm line-clamp-2 mt-1 h-10">
                        {node.description || "Premium RST Performance product"}
                      </p>
                      
                      <div className="mt-3 flex items-center gap-2">
                        <span className="text-primary font-bold text-lg">
                          {price.currencyCode} {parseFloat(price.amount).toFixed(2)}
                        </span>
                        {compareAtPrice && parseFloat(compareAtPrice.amount) > parseFloat(price.amount) && (
                          <span className="text-muted-foreground text-sm line-through">
                            {compareAtPrice.currencyCode} {parseFloat(compareAtPrice.amount).toFixed(2)}
                          </span>
                        )}
                      </div>

                      <div className="mt-4 flex gap-2">
                        <Button 
                          onClick={() => handleAddToCart(product)}
                          className="flex-1"
                          size="sm"
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          {t.common.addToCart}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRemove(node.id, node.title)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Wishlist;
