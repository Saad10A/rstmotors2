import { useState, useEffect, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { Filter, SortAsc, Grid3X3, LayoutGrid, X, ChevronDown, Loader2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { useLanguage } from "@/i18n/LanguageContext";
import { fetchProducts, ShopifyProduct } from "@/lib/shopify";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";

type SortOption = "featured" | "price-asc" | "price-desc" | "title-asc" | "title-desc" | "newest";
type GridSize = "small" | "large";

const Collections = () => {
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();
  
  const [products, setProducts] = useState<ShopifyProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [gridSize, setGridSize] = useState<GridSize>("large");
  const [sortBy, setSortBy] = useState<SortOption>("featured");
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Filter states
  const [selectedVendors, setSelectedVendors] = useState<string[]>([]);
  const [selectedPriceRanges, setSelectedPriceRanges] = useState<string[]>([]);
  const [inStockOnly, setInStockOnly] = useState(false);

  // Get collection from URL
  const collection = searchParams.get("collection") || "";

  // Price ranges for filtering
  const priceRanges = [
    { id: "0-100", label: "€0 - €100", min: 0, max: 100 },
    { id: "100-500", label: "€100 - €500", min: 100, max: 500 },
    { id: "500-1000", label: "€500 - €1,000", min: 500, max: 1000 },
    { id: "1000-5000", label: "€1,000 - €5,000", min: 1000, max: 5000 },
    { id: "5000+", label: "€5,000+", min: 5000, max: Infinity },
  ];

  // Fetch products
  useEffect(() => {
    const loadProducts = async () => {
      setIsLoading(true);
      try {
        const query = collection ? `title:${collection}* OR product_type:${collection}* OR tag:${collection}` : undefined;
        const data = await fetchProducts(100, query);
        setProducts(data);
      } catch (error) {
        console.error("Error fetching products:", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadProducts();
  }, [collection]);

  // Extract unique vendors from products
  const vendors = useMemo(() => {
    const vendorSet = new Set<string>();
    products.forEach((product) => {
      if (product.node.vendor) {
        vendorSet.add(product.node.vendor);
      }
    });
    return Array.from(vendorSet).sort();
  }, [products]);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let filtered = [...products];

    // Filter by vendor
    if (selectedVendors.length > 0) {
      filtered = filtered.filter((p) => selectedVendors.includes(p.node.vendor));
    }

    // Filter by price range
    if (selectedPriceRanges.length > 0) {
      filtered = filtered.filter((p) => {
        const price = parseFloat(p.node.priceRange.minVariantPrice.amount);
        return selectedPriceRanges.some((rangeId) => {
          const range = priceRanges.find((r) => r.id === rangeId);
          if (!range) return false;
          return price >= range.min && price < range.max;
        });
      });
    }

    // Filter by stock
    if (inStockOnly) {
      filtered = filtered.filter((p) =>
        p.node.variants.edges.some((v) => v.node.availableForSale)
      );
    }

    // Sort
    switch (sortBy) {
      case "price-asc":
        filtered.sort(
          (a, b) =>
            parseFloat(a.node.priceRange.minVariantPrice.amount) -
            parseFloat(b.node.priceRange.minVariantPrice.amount)
        );
        break;
      case "price-desc":
        filtered.sort(
          (a, b) =>
            parseFloat(b.node.priceRange.minVariantPrice.amount) -
            parseFloat(a.node.priceRange.minVariantPrice.amount)
        );
        break;
      case "title-asc":
        filtered.sort((a, b) => a.node.title.localeCompare(b.node.title));
        break;
      case "title-desc":
        filtered.sort((a, b) => b.node.title.localeCompare(a.node.title));
        break;
      default:
        // featured - keep original order
        break;
    }

    return filtered;
  }, [products, selectedVendors, selectedPriceRanges, inStockOnly, sortBy]);

  // Count active filters
  const activeFilterCount = selectedVendors.length + selectedPriceRanges.length + (inStockOnly ? 1 : 0);

  // Toggle vendor filter
  const toggleVendor = (vendor: string) => {
    setSelectedVendors((prev) =>
      prev.includes(vendor) ? prev.filter((v) => v !== vendor) : [...prev, vendor]
    );
  };

  // Toggle price range filter
  const togglePriceRange = (rangeId: string) => {
    setSelectedPriceRanges((prev) =>
      prev.includes(rangeId) ? prev.filter((r) => r !== rangeId) : [...prev, rangeId]
    );
  };

  // Clear all filters
  const clearFilters = () => {
    setSelectedVendors([]);
    setSelectedPriceRanges([]);
    setInStockOnly(false);
    setSearchParams({});
  };

  const FilterContent = () => (
    <div className="space-y-6">
      {/* In Stock Filter */}
      <div>
        <h4 className="font-semibold text-foreground mb-3">{t.collectionsPage.availability}</h4>
        <div className="flex items-center space-x-2">
          <Checkbox
            id="in-stock"
            checked={inStockOnly}
            onCheckedChange={(checked) => setInStockOnly(checked === true)}
          />
          <label htmlFor="in-stock" className="text-sm text-muted-foreground cursor-pointer">
            {t.collectionsPage.inStockOnly}
          </label>
        </div>
      </div>

      {/* Price Filter */}
      <div>
        <h4 className="font-semibold text-foreground mb-3">{t.collectionsPage.priceRange}</h4>
        <div className="space-y-2">
          {priceRanges.map((range) => (
            <div key={range.id} className="flex items-center space-x-2">
              <Checkbox
                id={range.id}
                checked={selectedPriceRanges.includes(range.id)}
                onCheckedChange={() => togglePriceRange(range.id)}
              />
              <label htmlFor={range.id} className="text-sm text-muted-foreground cursor-pointer">
                {range.label}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Vendor Filter */}
      {vendors.length > 0 && (
        <div>
          <h4 className="font-semibold text-foreground mb-3">{t.collectionsPage.brand}</h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {vendors.map((vendor) => (
              <div key={vendor} className="flex items-center space-x-2">
                <Checkbox
                  id={vendor}
                  checked={selectedVendors.includes(vendor)}
                  onCheckedChange={() => toggleVendor(vendor)}
                />
                <label htmlFor={vendor} className="text-sm text-muted-foreground cursor-pointer">
                  {vendor}
                </label>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Clear Filters */}
      {activeFilterCount > 0 && (
        <Button variant="outline" onClick={clearFilters} className="w-full">
          {t.collectionsPage.clearFilters}
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-20 pb-20">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-2">
              {collection ? collection.charAt(0).toUpperCase() + collection.slice(1) : t.collectionsPage.allProducts}
            </h1>
            <p className="text-muted-foreground">
              {filteredProducts.length} {filteredProducts.length === 1 ? t.collectionsPage.product : t.collectionsPage.products}
            </p>
          </div>

          {/* Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-border">
            {/* Left: Filter Button (Mobile) + Active Filters */}
            <div className="flex items-center gap-3">
              {/* Mobile Filter Button */}
              <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="lg:hidden">
                    <Filter className="w-4 h-4 mr-2" />
                    {t.collectionsPage.filters}
                    {activeFilterCount > 0 && (
                      <Badge variant="secondary" className="ml-2">
                        {activeFilterCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80">
                  <SheetHeader>
                    <SheetTitle>{t.collectionsPage.filters}</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    <FilterContent />
                  </div>
                </SheetContent>
              </Sheet>

              {/* Active Filter Tags */}
              {activeFilterCount > 0 && (
                <div className="hidden md:flex flex-wrap items-center gap-2">
                  {selectedVendors.map((vendor) => (
                    <Badge
                      key={vendor}
                      variant="secondary"
                      className="cursor-pointer hover:bg-destructive/20"
                      onClick={() => toggleVendor(vendor)}
                    >
                      {vendor}
                      <X className="w-3 h-3 ml-1" />
                    </Badge>
                  ))}
                  {selectedPriceRanges.map((rangeId) => (
                    <Badge
                      key={rangeId}
                      variant="secondary"
                      className="cursor-pointer hover:bg-destructive/20"
                      onClick={() => togglePriceRange(rangeId)}
                    >
                      {priceRanges.find((r) => r.id === rangeId)?.label}
                      <X className="w-3 h-3 ml-1" />
                    </Badge>
                  ))}
                  {inStockOnly && (
                    <Badge
                      variant="secondary"
                      className="cursor-pointer hover:bg-destructive/20"
                      onClick={() => setInStockOnly(false)}
                    >
                      {t.collectionsPage.inStockOnly}
                      <X className="w-3 h-3 ml-1" />
                    </Badge>
                  )}
                  <button
                    onClick={clearFilters}
                    className="text-sm text-muted-foreground hover:text-foreground"
                  >
                    {t.collectionsPage.clearAll}
                  </button>
                </div>
              )}
            </div>

            {/* Right: Sort + Grid Toggle */}
            <div className="flex items-center gap-3">
              {/* Sort Dropdown */}
              <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
                <SelectTrigger className="w-[180px]">
                  <SortAsc className="w-4 h-4 mr-2" />
                  <SelectValue placeholder={t.collectionsPage.sortBy} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">{t.collectionsPage.sortFeatured}</SelectItem>
                  <SelectItem value="price-asc">{t.collectionsPage.sortPriceLow}</SelectItem>
                  <SelectItem value="price-desc">{t.collectionsPage.sortPriceHigh}</SelectItem>
                  <SelectItem value="title-asc">{t.collectionsPage.sortAZ}</SelectItem>
                  <SelectItem value="title-desc">{t.collectionsPage.sortZA}</SelectItem>
                  <SelectItem value="newest">{t.collectionsPage.sortNewest}</SelectItem>
                </SelectContent>
              </Select>

              {/* Grid Size Toggle */}
              <div className="hidden md:flex items-center border border-border rounded-md">
                <button
                  onClick={() => setGridSize("large")}
                  className={`p-2 transition-colors ${gridSize === "large" ? "bg-muted" : "hover:bg-muted/50"}`}
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setGridSize("small")}
                  className={`p-2 transition-colors ${gridSize === "small" ? "bg-muted" : "hover:bg-muted/50"}`}
                >
                  <Grid3X3 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex gap-8">
            {/* Desktop Sidebar Filters */}
            <aside className="hidden lg:block w-64 flex-shrink-0">
              <div className="sticky top-24">
                <h3 className="font-heading text-lg font-semibold text-foreground mb-4">
                  {t.collectionsPage.filters}
                </h3>
                <FilterContent />
              </div>
            </aside>

            {/* Product Grid */}
            <div className="flex-1">
              {isLoading ? (
                <div className="flex items-center justify-center py-20">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : filteredProducts.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-muted-foreground text-lg mb-4">{t.collectionsPage.noProducts}</p>
                  {activeFilterCount > 0 && (
                    <Button variant="outline" onClick={clearFilters}>
                      {t.collectionsPage.clearFilters}
                    </Button>
                  )}
                </div>
              ) : (
                <div
                  className={`grid gap-4 md:gap-6 ${
                    gridSize === "large"
                      ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
                      : "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4"
                  }`}
                >
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.node.id} product={product} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Collections;
