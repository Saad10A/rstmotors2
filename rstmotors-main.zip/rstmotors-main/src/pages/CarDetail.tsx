import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Share2, Heart, Phone, MapPin, Grid, ChevronRight, ChevronLeft, User, Key, FileText, Check, Car, Fuel, Calendar, Settings, DoorOpen, Users, Palette, Gauge, Shield, X, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
// Public car data (from cars_public view - excludes sensitive PII)
interface CarPublicData {
  id: string;
  title: string;
  subtitle: string | null;
  price: number;
  mileage: number | null;
  registration_year: number | null;
  fuel_type: string | null;
  body_type: string | null;
  engine: string | null;
  gearbox: string | null;
  doors: number | null;
  seats: number | null;
  emission_class: string | null;
  body_colour: string | null;
  power: string | null;
  acceleration: string | null;
  description: string | null;
  images: string[];
  seller_location: string | null;
  owners: number | null;
  keys: number | null;
  service_history: string | null;
  mot_valid_until: string | null;
}

// Sensitive seller data (only available to authenticated users)
interface SellerData {
  seller_name: string | null;
  seller_phone: string | null;
  registration_plate: string | null;
}

const historyChecks = [
  { label: "Not recorded as stolen", passed: true },
  { label: "Not recorded as scrapped", passed: true },
  { label: "Not imported from another country", passed: true },
  { label: "Not exported out of the UK", passed: true },
  { label: "Never been written off", passed: true },
];

const CarDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [car, setCar] = useState<CarPublicData | null>(null);
  const [sellerData, setSellerData] = useState<SellerData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [isLiked, setIsLiked] = useState(false);

  useEffect(() => {
    if (id) fetchCar();
  }, [id]);

  // Fetch sensitive seller data when user is authenticated
  useEffect(() => {
    if (id && user) {
      fetchSellerData();
    } else {
      setSellerData(null);
    }
  }, [id, user]);

  const fetchCar = async () => {
    try {
      // Use public view that excludes sensitive PII
      const { data, error } = await supabase
        .from("cars_public")
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (error) throw error;
      setCar(data);
    } catch (error) {
      console.error("Error fetching car:", error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch sensitive seller info only for authenticated users
  const fetchSellerData = async () => {
    try {
      const { data, error } = await supabase
        .from("cars")
        .select("seller_name, seller_phone, registration_plate")
        .eq("id", id)
        .maybeSingle();

      if (error) throw error;
      setSellerData(data);
    } catch (error) {
      console.error("Error fetching seller data:", error);
    }
  };

  const nextImage = () => {
    if (!car) return;
    setSelectedImage((prev) => (prev + 1) % car.images.length);
  };

  const prevImage = () => {
    if (!car) return;
    setSelectedImage((prev) => (prev - 1 + car.images.length) % car.images.length);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-24 px-4 md:px-8 lg:px-16 max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted w-32" />
            <div className="h-[400px] bg-muted" />
            <div className="h-32 bg-muted" />
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!car) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-24 px-4 md:px-8 lg:px-16 max-w-7xl mx-auto text-center py-20">
          <h1 className="font-heading text-3xl font-bold text-foreground mb-4">Vehicle Not Found</h1>
          <p className="text-muted-foreground mb-6">The vehicle you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link to="/cars">Browse All Vehicles</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const images = car.images?.length > 0 ? car.images : ["https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&q=80"];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Back Navigation */}
      <div className="pt-20 px-4 md:px-8 lg:px-16 max-w-7xl mx-auto">
        <div className="flex items-center justify-between py-4">
          <Link to="/cars" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors font-medium">
            <ArrowLeft className="w-4 h-4" />
            <span>Back to results</span>
          </Link>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsLiked(!isLiked)}
              className="hover:bg-primary/10"
            >
              <Heart className={`w-5 h-5 ${isLiked ? "fill-primary text-primary" : ""}`} />
            </Button>
            <Button variant="ghost" size="icon" className="hover:bg-primary/10">
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 md:px-8 lg:px-16 max-w-7xl mx-auto pb-20">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Gallery & Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <div className="grid grid-cols-4 gap-2">
              {/* Main Image */}
              <div 
                className="col-span-4 md:col-span-2 row-span-2 relative cursor-pointer group"
                onClick={() => setIsGalleryOpen(true)}
              >
                <img
                  src={images[selectedImage]}
                  alt={car.title}
                  className="w-full h-[300px] md:h-[400px] object-cover"
                />
                <div className="absolute bottom-4 left-4">
                  <Button variant="secondary" className="gap-2 bg-background/90 hover:bg-background">
                    <Grid className="w-4 h-4" />
                    <span>Gallery</span>
                  </Button>
                </div>
                <div className="absolute inset-0 bg-background/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              
              {/* Thumbnail Grid */}
              {images.slice(1, 5).map((img, idx) => (
                <div 
                  key={idx}
                  className={`relative cursor-pointer ${idx >= 2 ? 'hidden md:block' : ''}`}
                  onClick={() => setSelectedImage(idx + 1)}
                >
                  <img
                    src={img}
                    alt={`${car.title} view ${idx + 2}`}
                    className={`w-full h-[96px] md:h-[196px] object-cover transition-opacity ${selectedImage === idx + 1 ? 'ring-2 ring-primary' : 'hover:opacity-80'}`}
                  />
                  {idx === 3 && images.length > 5 && (
                    <div className="absolute inset-0 bg-background/60 flex items-center justify-center">
                      <div className="flex items-center gap-1 text-foreground">
                        <Grid className="w-4 h-4" />
                        <span className="font-bold">{images.length}</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Seller Info */}
            <div className="bg-card border border-border p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">From {sellerData?.seller_name || "Seller"}</p>
                  <p className="text-muted-foreground text-sm">{car.seller_location || "Manchester"}</p>
                </div>
                <Button variant="ghost" className="gap-2 text-muted-foreground hover:text-foreground">
                  <Grid className="w-4 h-4" />
                  <span>More seller information</span>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Title & Price */}
            <div className="bg-card border border-border p-6">
              <h1 className="font-heading text-2xl md:text-3xl font-bold text-foreground">{car.title}</h1>
              {car.subtitle && <p className="text-muted-foreground">{car.subtitle}</p>}
              <p className="text-3xl font-bold text-primary mt-4">£{car.price.toLocaleString()}</p>
            </div>

            {/* Overview Section */}
            <div className="bg-card border border-border p-6 space-y-6">
              <h2 className="font-heading text-xl font-bold text-foreground">Overview</h2>
              
              {/* Highlight */}
              {car.power && (
                <div className="flex items-center justify-between p-4 bg-secondary/50 border border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary/20 flex items-center justify-center">
                      <Gauge className="w-4 h-4 text-primary" />
                    </div>
                    <span className="font-medium text-foreground">High Performance: {car.power}</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </div>
              )}
              
              {/* Specs Grid */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                <div className="flex items-start gap-3">
                  <Gauge className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Mileage</p>
                    <p className="font-medium text-foreground">{car.mileage?.toLocaleString() || "N/A"} miles</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Registration</p>
                    <p className="font-medium text-foreground">
                      {car.registration_year}
                      {sellerData?.registration_plate ? ` (${sellerData.registration_plate})` : ""}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Fuel className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Fuel type</p>
                    <p className="font-medium text-foreground">{car.fuel_type || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Car className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Body type</p>
                    <p className="font-medium text-foreground">{car.body_type || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Settings className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Engine</p>
                    <p className="font-medium text-foreground">{car.engine || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Settings className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Gearbox</p>
                    <p className="font-medium text-foreground">{car.gearbox || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <DoorOpen className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Doors</p>
                    <p className="font-medium text-foreground">{car.doors || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Users className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Seats</p>
                    <p className="font-medium text-foreground">{car.seats || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Palette className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Body colour</p>
                    <p className="font-medium text-foreground">{car.body_colour || "N/A"}</p>
                  </div>
                </div>
              </div>

              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors w-full pt-4 border-t border-border">
                <FileText className="w-4 h-4" />
                <span>View all spec and features</span>
                <ChevronRight className="w-4 h-4 ml-auto" />
              </button>
            </div>

            {/* Description Section */}
            {car.description && (
              <div className="bg-card border border-border p-6 space-y-4">
                <h2 className="font-heading text-xl font-bold text-foreground">Description</h2>
                <p className="text-muted-foreground whitespace-pre-line leading-relaxed">
                  {car.description}
                </p>
                <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors w-full pt-4 border-t border-border">
                  <FileText className="w-4 h-4" />
                  <span>Read full description</span>
                  <ChevronRight className="w-4 h-4 ml-auto" />
                </button>
              </div>
            )}

            {/* Running Costs Section */}
            <div className="bg-card border border-border p-6 space-y-4">
              <h2 className="font-heading text-xl font-bold text-foreground">Running costs</h2>
              
              <div className="flex items-center justify-between p-4 bg-secondary/50 border border-border">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary/20 flex items-center justify-center">
                    <Shield className="w-4 h-4 text-primary" />
                  </div>
                  <span className="font-medium text-foreground">Premium insurance bracket</span>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>

              <div className="grid grid-cols-3 gap-6 pt-4">
                <div>
                  <p className="text-sm text-muted-foreground">Emission class</p>
                  <p className="font-medium text-foreground">{car.emission_class || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Insurance group</p>
                  <p className="font-medium text-foreground">50</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tax per year</p>
                  <p className="font-medium text-foreground">£580</p>
                </div>
              </div>
            </div>

            {/* Vehicle History Section */}
            <div className="bg-card border border-border p-6 space-y-6">
              <h2 className="font-heading text-xl font-bold text-foreground">This vehicle's history</h2>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-6">
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Owners</p>
                    <p className="font-medium text-foreground">{car.owners || 1}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Key className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Keys</p>
                    <p className="font-medium text-foreground">{car.keys || 2}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <FileText className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Service history</p>
                    <p className="font-medium text-foreground">Full History</p>
                  </div>
                </div>
              </div>

              {/* History Info */}
              <div className="space-y-2 pt-4 border-t border-border">
                <div>
                  <p className="text-sm text-muted-foreground">Basic history check</p>
                  <p className="text-primary font-medium">5 checks passed</p>
                </div>
                {car.mot_valid_until && (
                  <div>
                    <p className="text-sm text-muted-foreground">MOT Information</p>
                    <p className="text-primary font-medium">Current MOT valid until {car.mot_valid_until}</p>
                  </div>
                )}
              </div>

              {/* History Checks */}
              <div className="space-y-3 pt-4 border-t border-border">
                {historyChecks.map((check, idx) => (
                  <div key={idx} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                    <div className="flex items-center gap-3">
                      <Check className="w-5 h-5 text-green-500" />
                      <span className="text-foreground">{check.label}</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </div>
                ))}
              </div>

              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors w-full pt-4 border-t border-border">
                <FileText className="w-4 h-4" />
                <span>View all checks and history</span>
                <ChevronRight className="w-4 h-4 ml-auto" />
              </button>
            </div>

            {/* Meet the Seller Section */}
            <div className="bg-card border border-border p-6 space-y-4">
              <h2 className="font-heading text-xl font-bold text-foreground">Meet the seller</h2>
              <div>
                <p className="font-bold text-foreground text-lg">{sellerData?.seller_name || "Seller"}</p>
                <p className="text-muted-foreground">{car.seller_location || "Manchester"}</p>
              </div>
            </div>
          </div>

          {/* Right Column - Contact */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-card border border-border p-6 space-y-4">
              <h3 className="font-heading text-xl font-bold text-foreground">Contact seller</h3>
              <p className="text-muted-foreground flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                {car.seller_location || "Manchester"}
              </p>
              
              {/* Show phone number only to authenticated users */}
              {user && sellerData?.seller_phone ? (
                <Button className="w-full gap-2" size="lg">
                  <Phone className="w-4 h-4" />
                  <span>{sellerData.seller_phone}</span>
                </Button>
              ) : (
                <Button className="w-full gap-2" size="lg" asChild>
                  <Link to="/auth">
                    <Lock className="w-4 h-4" />
                    <span>Sign in to see phone</span>
                  </Link>
                </Button>
              )}
              
              <Button variant="outline" className="w-full" size="lg">
                Request a callback
              </Button>
              <Button variant="outline" className="w-full" size="lg">
                Send a message
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Fullscreen Gallery Modal */}
      {isGalleryOpen && (
        <div className="fixed inset-0 z-50 bg-background/95 flex items-center justify-center">
          <button
            onClick={() => setIsGalleryOpen(false)}
            className="absolute top-4 right-4 p-2 hover:bg-secondary rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          
          <button
            onClick={prevImage}
            className="absolute left-4 p-2 hover:bg-secondary rounded-full transition-colors"
          >
            <ChevronLeft className="w-8 h-8" />
          </button>
          
          <img
            src={images[selectedImage]}
            alt={car.title}
            className="max-w-full max-h-[80vh] object-contain"
          />
          
          <button
            onClick={nextImage}
            className="absolute right-4 p-2 hover:bg-secondary rounded-full transition-colors"
          >
            <ChevronRight className="w-8 h-8" />
          </button>
          
          <div className="absolute bottom-8 flex gap-2">
            {images.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedImage(idx)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  selectedImage === idx ? "bg-primary" : "bg-muted-foreground"
                }`}
              />
            ))}
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};

export default CarDetail;
