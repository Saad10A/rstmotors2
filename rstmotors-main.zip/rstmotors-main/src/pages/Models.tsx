import { Link } from "react-router-dom";
import { ArrowRight, Settings2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useLanguage } from "@/i18n/LanguageContext";
import rs7Image from "@/assets/rs7.png";
import urusImage from "@/assets/urus-front.jpg";
import m8Image from "@/assets/m8-rst.jpg";

const Models = () => {
  const { t } = useLanguage();

  const models = [
    {
      id: "rs7-edition",
      name: "RS7 Edition",
      subtitle: t.modelsPage.rst7Subtitle,
      image: rs7Image,
      specs: {
        power: "720 HP",
        acceleration: "3.2s",
        topSpeed: "305 km/h",
      },
      startingPrice: "€89,900",
      configuratorLink: "/configurator",
    },
    {
      id: "urus-rst",
      name: "URUS RST",
      subtitle: t.modelsPage.rsq8Subtitle,
      image: urusImage,
      specs: {
        power: "740 HP",
        acceleration: "3.1s",
        topSpeed: "310 km/h",
      },
      startingPrice: "€129,900",
      configuratorLink: "/configurator/urus",
    },
    {
      id: "m8-rst",
      name: "M8 RST",
      subtitle: t.modelsPage.rs6Subtitle,
      image: m8Image,
      specs: {
        power: "680 HP",
        acceleration: "3.0s",
        topSpeed: "320 km/h",
      },
      startingPrice: "€109,900",
      configuratorLink: "/configurator/m8",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-[50vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={urusImage}
            alt="Models Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/50 to-background" />
        </div>
        <div className="relative z-10 text-center px-4">
          <h1 className="font-heading text-4xl md:text-6xl font-bold italic uppercase text-foreground mb-4">
            {t.modelsPage.title}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            {t.modelsPage.subtitle}
          </p>
        </div>
      </section>

      {/* Models Grid */}
      <section className="py-16 md:py-24 px-4 md:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {models.map((model, index) => (
              <div
                key={model.id}
                className="group relative bg-card border border-border overflow-hidden hover:border-primary transition-all duration-500"
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
              >
                {/* Image */}
                <div className="relative h-64 md:h-72 overflow-hidden">
                  <img
                    src={model.image}
                    alt={model.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="mb-4">
                    <h3 className="font-heading text-2xl md:text-3xl font-bold italic uppercase text-foreground mb-1">
                      {model.name}
                    </h3>
                    <p className="text-muted-foreground text-sm">{model.subtitle}</p>
                  </div>

                  {/* Specs */}
                  <div className="grid grid-cols-3 gap-2 mb-4 py-4 border-y border-border">
                    <div className="text-center">
                      <p className="text-xl font-bold text-foreground">{model.specs.power}</p>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">{t.modelsPage.power}</p>
                    </div>
                    <div className="text-center border-x border-border">
                      <p className="text-xl font-bold text-foreground">{model.specs.acceleration}</p>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">0-100</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xl font-bold text-foreground">{model.specs.topSpeed}</p>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">{t.modelsPage.topSpeed}</p>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="mb-4">
                    <span className="text-primary font-bold text-lg">
                      {t.modelsPage.from} {model.startingPrice}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <Link
                      to={model.configuratorLink}
                      className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground py-3 px-4 font-semibold text-sm uppercase tracking-wider hover:bg-primary/90 transition-colors"
                    >
                      <Settings2 size={16} />
                      {t.modelsPage.configure}
                    </Link>
                    <Link
                      to={model.configuratorLink}
                      className="flex items-center justify-center gap-2 border border-foreground text-foreground py-3 px-4 font-semibold text-sm uppercase tracking-wider hover:bg-foreground hover:text-background transition-colors"
                    >
                      <ArrowRight size={16} />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="font-heading text-3xl md:text-4xl font-bold italic uppercase text-foreground mb-4">
            {t.modelsPage.ctaTitle}
          </h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            {t.modelsPage.ctaSubtitle}
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 bg-primary text-primary-foreground py-4 px-8 font-semibold text-sm uppercase tracking-wider hover:bg-primary/90 transition-colors"
          >
            {t.modelsPage.ctaButton}
            <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Models;
