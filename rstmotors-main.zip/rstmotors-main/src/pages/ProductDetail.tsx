import { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Loader2, Minus, Plus, ShoppingCart, Shield, Truck, Award, Tag, Package, Barcode, CheckCircle, Heart, Wrench, Car, Box, Ruler, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { fetchProductByHandle, fetchProducts, ShopifyProduct, storefrontApiRequest, CART_CREATE_MUTATION } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";
import { useWishlistStore } from "@/stores/wishlistStore";
import { toast } from "sonner";
import { useLanguage } from "@/i18n/LanguageContext";
import ProductCard from "@/components/ProductCard";
import klarnaLogo from "@/assets/klarna-logo.png";
import useEmblaCarousel from "embla-carousel-react";

const ProductDetail = () => {
  const { handle } = useParams<{ handle: string }>();
  const { t } = useLanguage();
  const [product, setProduct] = useState<ShopifyProduct['node'] | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<ShopifyProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState<ShopifyProduct['node']['variants']['edges'][0]['node'] | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});
  const [quantity, setQuantity] = useState(1);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  
  // Embla carousel for image gallery
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
  
  const addItem = useCartStore(state => state.addItem);
  const { addItem: addToWishlist, removeItem: removeFromWishlist, isInWishlist } = useWishlistStore();

  useEffect(() => {
    const loadProduct = async () => {
      if (!handle) return;
      
      setIsLoading(true);
      try {
        const data = await fetchProductByHandle(handle);
        setProduct(data);
        
        if (data?.variants.edges[0]) {
          const firstVariant = data.variants.edges[0].node;
          setSelectedVariant(firstVariant);
          
          const options: Record<string, string> = {};
          firstVariant.selectedOptions.forEach(opt => {
            options[opt.name] = opt.value;
          });
          setSelectedOptions(options);
        }

        // Fetch related products
        const allProducts = await fetchProducts(8);
        const related = allProducts.filter(p => p.node.handle !== handle).slice(0, 4);
        setRelatedProducts(related);
      } catch (err) {
        console.error("Failed to fetch product:", err);
      } finally {
        setIsLoading(false);
      }
    };

    loadProduct();
  }, [handle]);

  // Sync embla carousel with selected image index
  useEffect(() => {
    if (emblaApi) {
      emblaApi.scrollTo(selectedImageIndex);
    }
  }, [emblaApi, selectedImageIndex]);

  // Update selected index when carousel scrolls
  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedImageIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    emblaApi.on('select', onSelect);
    return () => {
      emblaApi.off('select', onSelect);
    };
  }, [emblaApi, onSelect]);

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  const handleOptionChange = (optionName: string, value: string) => {
    const newOptions = { ...selectedOptions, [optionName]: value };
    setSelectedOptions(newOptions);

    // Find matching variant
    const matchingVariant = product?.variants.edges.find(({ node }) => {
      return node.selectedOptions.every(
        opt => newOptions[opt.name] === opt.value
      );
    });

    if (matchingVariant) {
      setSelectedVariant(matchingVariant.node);
    }
  };

  const handleAddToCart = () => {
    if (!product || !selectedVariant) return;

    const productWrapper: ShopifyProduct = {
      node: product
    };

    addItem({
      product: productWrapper,
      variantId: selectedVariant.id,
      variantTitle: selectedVariant.title,
      price: selectedVariant.price,
      quantity,
      selectedOptions: selectedVariant.selectedOptions
    });

    toast.success(t.productDetail.addedToCart, {
      description: `${product.title}${selectedVariant.title !== "Default Title" ? ` - ${selectedVariant.title}` : ""}`,
      position: "top-center"
    });
  };

  const handleExpressCheckout = async () => {
    if (!product || !selectedVariant) return;

    try {
      const lines = [{
        quantity,
        merchandiseId: selectedVariant.id,
      }];

      const cartData = await storefrontApiRequest<{
        data: {
          cartCreate: {
            cart: {
              id: string;
              checkoutUrl: string;
            } | null;
            userErrors: Array<{ field: string; message: string }>;
          };
        };
      }>(CART_CREATE_MUTATION, {
        input: { lines },
      });

      if (cartData.data.cartCreate.userErrors.length > 0) {
        throw new Error(`Checkout failed: ${cartData.data.cartCreate.userErrors.map(e => e.message).join(', ')}`);
      }

      const cart = cartData.data.cartCreate.cart;
      
      if (!cart?.checkoutUrl) {
        throw new Error('No checkout URL returned');
      }

      const url = new URL(cart.checkoutUrl);
      url.searchParams.set('channel', 'online_store');
      window.open(url.toString(), '_blank');
    } catch (error) {
      console.error('Express checkout failed:', error);
      toast.error('Checkout failed', {
        description: 'Please try again or use the regular checkout.',
        position: 'top-center'
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="flex items-center justify-center py-40">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
        </div>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-6 py-20 text-center">
          <h1 className="font-heading text-4xl font-bold text-foreground mb-4">{t.productDetail.productNotFound}</h1>
          <p className="text-muted-foreground mb-8">{t.productDetail.productNotFoundDesc}</p>
          <Link to="/shop">
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              {t.productDetail.backToShop}
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const images = product.images.edges;
  

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-6">
          {/* Breadcrumb */}
          <Link 
            to="/shop" 
            className="inline-flex items-center text-muted-foreground hover:text-primary transition-colors mb-8"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t.productDetail.backToShop}
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Images */}
            <div className="space-y-4">
              {/* Main Image Carousel */}
              <div className="relative aspect-square bg-card border border-border rounded-lg overflow-hidden">
                <div className="overflow-hidden h-full" ref={emblaRef}>
                  <div className="flex h-full">
                    {images.length > 0 ? (
                      images.map((img, index) => (
                        <div key={index} className="flex-[0_0_100%] min-w-0 h-full">
                          <img
                            src={img.node.url}
                            alt={img.node.altText || `${product.title} ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))
                    ) : (
                      <div className="flex-[0_0_100%] min-w-0 h-full flex items-center justify-center text-muted-foreground">
                        <ShoppingCart className="w-20 h-20" />
                      </div>
                    )}
                  </div>
                </div>

                {/* Navigation Arrows */}
                {images.length > 1 && (
                  <>
                    <Button
                      onClick={scrollPrev}
                      size="icon"
                      variant="ghost"
                      className="absolute left-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background shadow-lg"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </Button>
                    <Button
                      onClick={scrollNext}
                      size="icon"
                      variant="ghost"
                      className="absolute right-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background shadow-lg"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </Button>
                  </>
                )}

                {/* Image Counter */}
                {images.length > 1 && (
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-background/80 backdrop-blur-sm px-3 py-1 rounded-full text-sm text-foreground">
                    {selectedImageIndex + 1} / {images.length}
                  </div>
                )}
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex gap-3 overflow-x-auto pb-2">
                  {images.map((img, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImageIndex(index)}
                      className={`w-20 h-20 flex-shrink-0 rounded-md overflow-hidden border-2 transition-colors ${
                        selectedImageIndex === index 
                          ? "border-primary" 
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <img
                        src={img.node.url}
                        alt={img.node.altText || `${product.title} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-2">
                  {product.title}
                </h1>
                <div className="flex items-center gap-3">
                  <p className="text-3xl font-bold text-primary">
                    {selectedVariant?.price.currencyCode || 'EUR'} {parseFloat(selectedVariant?.price.amount || '0').toFixed(2)}
                  </p>
                  {selectedVariant?.compareAtPrice && parseFloat(selectedVariant.compareAtPrice.amount) > parseFloat(selectedVariant.price.amount) && (
                    <p className="text-xl text-muted-foreground line-through">
                      {selectedVariant.compareAtPrice.currencyCode} {parseFloat(selectedVariant.compareAtPrice.amount).toFixed(2)}
                    </p>
                  )}
                </div>
              </div>

              {/* Klarna Messaging */}
              <div className="bg-[#FFB3C7]/20 border border-[#FFB3C7] p-4 rounded-lg">
                <div className="flex items-center gap-3">
                  <img src={klarnaLogo} alt="Klarna" className="h-8 w-auto rounded" />
                  <div className="flex-1">
                    <p className="text-sm text-foreground">
                      3 interest-free payments of <span className="font-bold">{selectedVariant?.price.currencyCode || 'EUR'} {(parseFloat(selectedVariant?.price.amount || '0') / 3).toFixed(2)}</span>
                    </p>
                    <p className="text-xs text-muted-foreground">18+, T&C apply, Credit subject to status. <a href="https://www.klarna.com" target="_blank" rel="noopener noreferrer" className="underline hover:text-primary">Learn more</a></p>
                  </div>
                </div>
              </div>


              {/* Options */}
              {product.options.filter(opt => opt.name !== "Title" || opt.values[0] !== "Default Title").map((option) => (
                <div key={option.name}>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {option.name}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {option.values.map((value) => (
                      <button
                        key={value}
                        onClick={() => handleOptionChange(option.name, value)}
                        className={`px-4 py-2 border rounded-md text-sm transition-colors ${
                          selectedOptions[option.name] === value
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border text-foreground hover:border-primary"
                        }`}
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {t.productDetail.quantity}
                </label>
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="w-12 text-center text-lg font-medium text-foreground">{quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={handleAddToCart}
                  size="lg"
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                  disabled={!selectedVariant?.availableForSale}
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  {selectedVariant?.availableForSale ? t.productDetail.addToCart : t.productDetail.outOfStock}
                </Button>
                <Button
                  onClick={() => {
                    if (!product) return;
                    const productWrapper: ShopifyProduct = { node: product };
                    const wishlisted = isInWishlist(product.id);
                    if (wishlisted) {
                      removeFromWishlist(product.id);
                      toast.success(t.productDetail.removedFromWishlist, {
                        description: product.title,
                        position: "top-center"
                      });
                    } else {
                      addToWishlist(productWrapper);
                      toast.success(t.productDetail.addedToWishlist, {
                        description: product.title,
                        position: "top-center"
                      });
                    }
                  }}
                  size="lg"
                  variant="outline"
                  className={`px-4 ${product && isInWishlist(product.id) ? "text-destructive border-destructive" : ""}`}
                >
                  <Heart className={`w-5 h-5 ${product && isInWishlist(product.id) ? "fill-current" : ""}`} />
                </Button>
              </div>

              {/* Product Info Section */}
              <div className="grid grid-cols-2 gap-4 py-4 border-t border-border">
                <div className="flex items-center gap-3">
                  <Tag className="w-5 h-5 text-primary" />
                  <div>
                    <span className="text-xs text-muted-foreground">{t.productDetail.brand}</span>
                    <p className="text-sm font-medium text-foreground">{product.vendor || "RST Performance"}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Package className="w-5 h-5 text-primary" />
                  <div>
                    <span className="text-xs text-muted-foreground">{t.productDetail.sku}</span>
                    <p className="text-sm font-medium text-foreground">{selectedVariant?.sku || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Barcode className="w-5 h-5 text-primary" />
                  <div>
                    <span className="text-xs text-muted-foreground">{t.productDetail.ean}</span>
                    <p className="text-sm font-medium text-foreground">{selectedVariant?.barcode || "N/A"}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className={`w-5 h-5 ${selectedVariant?.availableForSale ? "text-green-500" : "text-destructive"}`} />
                  <div>
                    <span className="text-xs text-muted-foreground">{t.productDetail.availability}</span>
                    <p className={`text-sm font-medium ${selectedVariant?.availableForSale ? "text-green-500" : "text-destructive"}`}>
                      {selectedVariant?.availableForSale ? t.productDetail.inStock : t.productDetail.notAvailable}
                    </p>
                  </div>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-border">
                <div className="flex flex-col items-center text-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{t.productDetail.securePayment}</span>
                </div>
                <div className="flex flex-col items-center text-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Truck className="w-6 h-6 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{t.productDetail.fastShipping}</span>
                </div>
                <div className="flex flex-col items-center text-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Award className="w-6 h-6 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{t.productDetail.warranty}</span>
                </div>
              </div>
            </div>
          </div>

          {product.description && (
            <div className="mt-16 pt-12 border-t border-border">
              <h2 className="font-heading text-2xl font-bold text-foreground mb-6">
                {t.productDetail.productDescription}
              </h2>
              <p className="text-muted-foreground leading-relaxed max-w-4xl">
                {product.description}
              </p>
            </div>
          )}

          {/* Specifications Accordion */}
          <div className="mt-12 pt-8 border-t border-border">
            <h2 className="font-heading text-2xl font-bold text-foreground mb-6">
              {t.productDetail.specifications}
            </h2>
            <Accordion type="single" collapsible className="w-full max-w-4xl">
              {product.compatibility?.value && (
                <AccordionItem value="compatibility">
                  <AccordionTrigger className="text-foreground">
                    <div className="flex items-center gap-3">
                      <Car className="w-5 h-5 text-primary" />
                      {t.productDetail.specCompatibility}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {product.compatibility.value}
                  </AccordionContent>
                </AccordionItem>
              )}
              {product.installation?.value && (
                <AccordionItem value="installation">
                  <AccordionTrigger className="text-foreground">
                    <div className="flex items-center gap-3">
                      <Wrench className="w-5 h-5 text-primary" />
                      {t.productDetail.specInstallation}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {product.installation.value}
                  </AccordionContent>
                </AccordionItem>
              )}
              {product.materials?.value && (
                <AccordionItem value="materials">
                  <AccordionTrigger className="text-foreground">
                    <div className="flex items-center gap-3">
                      <Box className="w-5 h-5 text-primary" />
                      {t.productDetail.specMaterials}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {product.materials.value}
                  </AccordionContent>
                </AccordionItem>
              )}
              {product.dimensions?.value && (
                <AccordionItem value="dimensions">
                  <AccordionTrigger className="text-foreground">
                    <div className="flex items-center gap-3">
                      <Ruler className="w-5 h-5 text-primary" />
                      {t.productDetail.specDimensions}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {product.dimensions.value}
                  </AccordionContent>
                </AccordionItem>
              )}
            </Accordion>
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-16 pt-12 border-t border-border">
              <h2 className="font-heading text-2xl font-bold text-foreground mb-8">
                {t.productDetail.relatedProducts}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedProducts.map((relatedProduct) => (
                  <ProductCard key={relatedProduct.node.id} product={relatedProduct} />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default ProductDetail;
