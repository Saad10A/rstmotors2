import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ArrowLeft, Loader2, Plus, Trash2, MapPin, Home, Building } from 'lucide-react';
import logo from '@/assets/logo.png';

interface Address {
  id: string;
  type: 'home' | 'work' | 'other';
  firstName: string;
  lastName: string;
  address1: string;
  address2: string;
  city: string;
  province: string;
  zip: string;
  country: string;
  phone: string;
  isDefault: boolean;
}

const AccountAddresses = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [newAddress, setNewAddress] = useState<Partial<Address>>({
    type: 'home',
    firstName: '',
    lastName: '',
    address1: '',
    address2: '',
    city: '',
    province: '',
    zip: '',
    country: '',
    phone: '',
    isDefault: false,
  });

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      const savedAddresses = user.user_metadata?.addresses || [];
      setAddresses(savedAddresses);
    }
  }, [user]);

  const handleAddAddress = async () => {
    if (!newAddress.address1 || !newAddress.city || !newAddress.country) {
      toast.error(t.addresses?.requiredFields || 'Please fill in required fields');
      return;
    }

    setIsSaving(true);
    const addressWithId: Address = {
      ...newAddress as Address,
      id: crypto.randomUUID(),
    };

    const updatedAddresses = [...addresses, addressWithId];
    
    try {
      const { error } = await supabase.auth.updateUser({
        data: { addresses: updatedAddresses }
      });

      if (error) {
        toast.error(error.message);
      } else {
        setAddresses(updatedAddresses);
        setIsAdding(false);
        setNewAddress({
          type: 'home',
          firstName: '',
          lastName: '',
          address1: '',
          address2: '',
          city: '',
          province: '',
          zip: '',
          country: '',
          phone: '',
          isDefault: false,
        });
        toast.success(t.addresses?.addSuccess || 'Address added successfully');
      }
    } catch (err) {
      toast.error(t.addresses?.addError || 'Failed to add address');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAddress = async (id: string) => {
    const updatedAddresses = addresses.filter(addr => addr.id !== id);
    
    try {
      const { error } = await supabase.auth.updateUser({
        data: { addresses: updatedAddresses }
      });

      if (error) {
        toast.error(error.message);
      } else {
        setAddresses(updatedAddresses);
        toast.success(t.addresses?.deleteSuccess || 'Address removed');
      }
    } catch (err) {
      toast.error(t.addresses?.deleteError || 'Failed to remove address');
    }
  };

  const handleSetDefault = async (id: string) => {
    const updatedAddresses = addresses.map(addr => ({
      ...addr,
      isDefault: addr.id === id,
    }));
    
    try {
      const { error } = await supabase.auth.updateUser({
        data: { addresses: updatedAddresses }
      });

      if (error) {
        toast.error(error.message);
      } else {
        setAddresses(updatedAddresses);
        toast.success(t.addresses?.defaultSuccess || 'Default address updated');
      }
    } catch (err) {
      toast.error(t.addresses?.defaultError || 'Failed to update default address');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'home': return <Home className="w-4 h-4" />;
      case 'work': return <Building className="w-4 h-4" />;
      default: return <MapPin className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/account" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>{t.addresses?.backToAccount || 'Back to Account'}</span>
          </Link>
          <Link to="/">
            <img src={logo} alt="RST" className="h-8" />
          </Link>
          <div className="w-24" />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-heading font-bold">{t.addresses?.title || 'Shipping Addresses'}</h1>
            {!isAdding && (
              <Button onClick={() => setIsAdding(true)}>
                <Plus className="w-4 h-4 mr-2" />
                {t.addresses?.addNew || 'Add Address'}
              </Button>
            )}
          </div>

          {/* Add New Address Form */}
          {isAdding && (
            <div className="bg-card border border-border p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">{t.addresses?.newAddress || 'New Address'}</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t.addresses?.firstName || 'First Name'}</Label>
                    <Input
                      value={newAddress.firstName || ''}
                      onChange={(e) => setNewAddress({ ...newAddress, firstName: e.target.value })}
                      className="bg-secondary border-border"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t.addresses?.lastName || 'Last Name'}</Label>
                    <Input
                      value={newAddress.lastName || ''}
                      onChange={(e) => setNewAddress({ ...newAddress, lastName: e.target.value })}
                      className="bg-secondary border-border"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>{t.addresses?.address1 || 'Address Line 1'} *</Label>
                  <Input
                    value={newAddress.address1 || ''}
                    onChange={(e) => setNewAddress({ ...newAddress, address1: e.target.value })}
                    className="bg-secondary border-border"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t.addresses?.address2 || 'Address Line 2'}</Label>
                  <Input
                    value={newAddress.address2 || ''}
                    onChange={(e) => setNewAddress({ ...newAddress, address2: e.target.value })}
                    className="bg-secondary border-border"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t.addresses?.city || 'City'} *</Label>
                    <Input
                      value={newAddress.city || ''}
                      onChange={(e) => setNewAddress({ ...newAddress, city: e.target.value })}
                      className="bg-secondary border-border"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t.addresses?.province || 'State/Province'}</Label>
                    <Input
                      value={newAddress.province || ''}
                      onChange={(e) => setNewAddress({ ...newAddress, province: e.target.value })}
                      className="bg-secondary border-border"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t.addresses?.zip || 'ZIP/Postal Code'}</Label>
                    <Input
                      value={newAddress.zip || ''}
                      onChange={(e) => setNewAddress({ ...newAddress, zip: e.target.value })}
                      className="bg-secondary border-border"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t.addresses?.country || 'Country'} *</Label>
                    <Input
                      value={newAddress.country || ''}
                      onChange={(e) => setNewAddress({ ...newAddress, country: e.target.value })}
                      className="bg-secondary border-border"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>{t.addresses?.phone || 'Phone'}</Label>
                  <Input
                    value={newAddress.phone || ''}
                    onChange={(e) => setNewAddress({ ...newAddress, phone: e.target.value })}
                    className="bg-secondary border-border"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button onClick={handleAddAddress} disabled={isSaving}>
                    {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                    {t.addresses?.save || 'Save Address'}
                  </Button>
                  <Button variant="outline" onClick={() => setIsAdding(false)}>
                    {t.addresses?.cancel || 'Cancel'}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Address List */}
          {addresses.length === 0 && !isAdding ? (
            <div className="bg-card border border-border p-12 text-center">
              <MapPin className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">{t.addresses?.noAddresses || 'No addresses yet'}</h3>
              <p className="text-muted-foreground mb-4">{t.addresses?.noAddressesDesc || 'Add a shipping address for faster checkout'}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {addresses.map((address) => (
                <div key={address.id} className="bg-card border border-border p-4 relative">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-secondary flex items-center justify-center mt-1">
                        {getTypeIcon(address.type)}
                      </div>
                      <div>
                        <p className="font-medium">
                          {address.firstName} {address.lastName}
                          {address.isDefault && (
                            <span className="ml-2 text-xs bg-primary text-primary-foreground px-2 py-0.5">
                              {t.addresses?.default || 'Default'}
                            </span>
                          )}
                        </p>
                        <p className="text-sm text-muted-foreground">{address.address1}</p>
                        {address.address2 && <p className="text-sm text-muted-foreground">{address.address2}</p>}
                        <p className="text-sm text-muted-foreground">
                          {address.city}{address.province ? `, ${address.province}` : ''} {address.zip}
                        </p>
                        <p className="text-sm text-muted-foreground">{address.country}</p>
                        {address.phone && <p className="text-sm text-muted-foreground">{address.phone}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {!address.isDefault && (
                        <Button variant="ghost" size="sm" onClick={() => handleSetDefault(address.id)}>
                          {t.addresses?.setDefault || 'Set Default'}
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteAddress(address.id)}>
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <p className="text-sm text-muted-foreground mt-8">
            {t.addresses?.shopifyNote || 'Your addresses are synced with your Shopify account for seamless checkout.'}
          </p>
        </div>
      </main>
    </div>
  );
};

export default AccountAddresses;
