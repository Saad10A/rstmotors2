import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import SpecialEditionsSection from "@/components/SpecialEditionsSection";
import ConfigureSection from "@/components/ConfigureSection";
import FeaturedCarsSection from "@/components/FeaturedCarsSection";
import ProductsSection from "@/components/ProductsSection";
import NewsSection from "@/components/NewsSection";
import Footer from "@/components/Footer";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import SEO from "@/components/SEO";

const Index = () => {
  const scrollRef = useScrollAnimation();

  return (
    <div className="min-h-screen bg-background" ref={scrollRef}>
      <SEO 
        title="Home"
        description="RST Motors - Installazione Autoradio Carplay, Tuning e Fanali Custom Professionali. Performance upgrades, sports suspension, interior, rims and more."
        keywords="car tuning, carplay installation, custom headlights, exhaust systems, performance upgrade, RST Motors, automotive tuning Italy"
        url="/"
      />
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <SpecialEditionsSection />
        <ConfigureSection />
        <FeaturedCarsSection />
        <ProductsSection />
        <NewsSection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
