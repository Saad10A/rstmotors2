import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { ArrowLeft, Loader2, Bell, Mail, Globe, Trash2 } from 'lucide-react';
import logo from '@/assets/logo.png';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const AccountSettings = () => {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const { t, language, setLanguage } = useLanguage();
  
  const [isSaving, setIsSaving] = useState(false);
  const [settings, setSettings] = useState({
    emailMarketing: true,
    orderUpdates: true,
    promotionalEmails: false,
    smsNotifications: false,
  });

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      const savedSettings = user.user_metadata?.notification_settings || settings;
      setSettings(savedSettings);
    }
  }, [user]);

  const handleSettingChange = async (key: keyof typeof settings, value: boolean) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    setIsSaving(true);

    try {
      const { error } = await supabase.auth.updateUser({
        data: { notification_settings: newSettings }
      });

      if (error) {
        toast.error(error.message);
        setSettings(settings); // Revert on error
      } else {
        toast.success(t.settings?.saved || 'Settings saved');
      }
    } catch (err) {
      toast.error(t.settings?.saveError || 'Failed to save settings');
      setSettings(settings);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAccount = async () => {
    // Note: Full account deletion requires Supabase admin access
    // This will sign out the user and they would need to contact support for full deletion
    toast.info(t.settings?.deleteInfo || 'Please contact support to delete your account');
    await signOut();
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/account" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>{t.settings?.backToAccount || 'Back to Account'}</span>
          </Link>
          <Link to="/">
            <img src={logo} alt="RST" className="h-8" />
          </Link>
          <div className="w-24" />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-heading font-bold mb-8">{t.settings?.title || 'Account Settings'}</h1>

          {/* Language Settings */}
          <div className="bg-card border border-border p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <Globe className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">{t.settings?.language || 'Language'}</h2>
            </div>
            <div className="flex gap-3">
              <Button
                variant={language === 'en' ? 'default' : 'outline'}
                onClick={() => setLanguage('en')}
              >
                English
              </Button>
              <Button
                variant={language === 'it' ? 'default' : 'outline'}
                onClick={() => setLanguage('it')}
              >
                Italiano
              </Button>
            </div>
          </div>

          {/* Notification Settings */}
          <div className="bg-card border border-border p-6 mb-6">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">{t.settings?.notifications || 'Notifications'}</h2>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="orderUpdates">{t.settings?.orderUpdates || 'Order Updates'}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings?.orderUpdatesDesc || 'Receive notifications about your order status'}</p>
                </div>
                <Switch
                  id="orderUpdates"
                  checked={settings.orderUpdates}
                  onCheckedChange={(checked) => handleSettingChange('orderUpdates', checked)}
                  disabled={isSaving}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailMarketing">{t.settings?.emailMarketing || 'Marketing Emails'}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings?.emailMarketingDesc || 'Receive news about new products and offers'}</p>
                </div>
                <Switch
                  id="emailMarketing"
                  checked={settings.emailMarketing}
                  onCheckedChange={(checked) => handleSettingChange('emailMarketing', checked)}
                  disabled={isSaving}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="promotionalEmails">{t.settings?.promotionalEmails || 'Promotional Offers'}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings?.promotionalEmailsDesc || 'Receive exclusive discounts and promotions'}</p>
                </div>
                <Switch
                  id="promotionalEmails"
                  checked={settings.promotionalEmails}
                  onCheckedChange={(checked) => handleSettingChange('promotionalEmails', checked)}
                  disabled={isSaving}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="smsNotifications">{t.settings?.smsNotifications || 'SMS Notifications'}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings?.smsNotificationsDesc || 'Receive order updates via SMS'}</p>
                </div>
                <Switch
                  id="smsNotifications"
                  checked={settings.smsNotifications}
                  onCheckedChange={(checked) => handleSettingChange('smsNotifications', checked)}
                  disabled={isSaving}
                />
              </div>
            </div>
          </div>

          {/* Email Preferences */}
          <div className="bg-card border border-border p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <Mail className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">{t.settings?.emailPreferences || 'Email Preferences'}</h2>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              {t.settings?.emailPreferencesDesc || 'Your email notifications are managed through Shopify. You can unsubscribe from marketing emails at any time using the link in our emails.'}
            </p>
            <p className="text-sm">
              <span className="text-muted-foreground">{t.settings?.currentEmail || 'Current email:'}</span> <span className="font-medium">{user.email}</span>
            </p>
          </div>

          {/* Danger Zone */}
          <div className="bg-card border border-destructive/50 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Trash2 className="w-5 h-5 text-destructive" />
              <h2 className="text-lg font-semibold text-destructive">{t.settings?.dangerZone || 'Danger Zone'}</h2>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              {t.settings?.deleteAccountDesc || 'Once you delete your account, there is no going back. Please be certain.'}
            </p>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  {t.settings?.deleteAccount || 'Delete Account'}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>{t.settings?.deleteConfirmTitle || 'Are you absolutely sure?'}</AlertDialogTitle>
                  <AlertDialogDescription>
                    {t.settings?.deleteConfirmDesc || 'This action cannot be undone. This will permanently delete your account and remove your data from our servers.'}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>{t.settings?.cancel || 'Cancel'}</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDeleteAccount} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    {t.settings?.confirmDelete || 'Delete Account'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AccountSettings;
