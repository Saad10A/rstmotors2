import { useState, useEffect, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { 
  ArrowLeft, 
  Loader2, 
  Package, 
  RefreshCw, 
  ExternalLink,
  Truck,
  CheckCircle2,
  Clock,
  MapPin,
  PackageCheck,
  PackageX,
  CircleDot
} from 'lucide-react';
import logo from '@/assets/logo.png';

interface TrackingInfo {
  company: string | null;
  number: string | null;
  url: string | null;
}

interface FulfillmentInfo {
  status: string;
  tracking_company: string | null;
  tracking_number: string | null;
  tracking_url: string | null;
  shipment_status: string | null;
  estimated_delivery_at: string | null;
  delivered_at: string | null;
  created_at: string;
  updated_at: string;
}

interface ShopifyOrder {
  id: string;
  name: string;
  created_at: string;
  processed_at: string;
  closed_at: string | null;
  cancelled_at: string | null;
  financial_status: string;
  fulfillment_status: string | null;
  total_price: string;
  currency: string;
  order_status_url?: string;
  order_status: string;
  tracking: TrackingInfo;
  fulfillments: FulfillmentInfo[];
  estimated_delivery_at: string | null;
  delivered_at: string | null;
  shipping_address: {
    city: string;
    province: string;
    country: string;
  } | null;
  line_items: Array<{
    id: string;
    title: string;
    quantity: number;
    price: string;
    variant_title: string | null;
    sku: string | null;
    fulfillment_status: string | null;
  }>;
}

const ORDER_STATUSES = [
  { key: 'confirmed', label: 'Confirmed', icon: CheckCircle2 },
  { key: 'processing', label: 'Processing', icon: Clock },
  { key: 'shipped', label: 'Shipped', icon: Package },
  { key: 'in_transit', label: 'In Transit', icon: Truck },
  { key: 'out_for_delivery', label: 'Out for Delivery', icon: MapPin },
  { key: 'delivered', label: 'Delivered', icon: PackageCheck },
];

const AccountOrders = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  const [orders, setOrders] = useState<ShopifyOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const fetchOrders = useCallback(async (showRefreshToast = false) => {
    if (!user) return;
    
    if (showRefreshToast) {
      setIsRefreshing(true);
    }

    try {
      // Edge function now uses the authenticated user's email from the JWT
      // No need to pass email in the body - this prevents unauthorized access to other users' orders
      const { data, error } = await supabase.functions.invoke('get-shopify-orders');

      if (error) {
        console.error('Error fetching orders:', error);
        toast.error(t.orders.fetchError);
      } else if (data?.orders) {
        setOrders(data.orders);
        if (showRefreshToast) {
          toast.success(t.orders.refreshed);
        }
      }
    } catch (err) {
      console.error('Error:', err);
      toast.error(t.orders.fetchError);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [user, t.orders.fetchError, t.orders.refreshed]);

  useEffect(() => {
    if (user) {
      fetchOrders();
    }
  }, [user, fetchOrders]);

  // Auto-refresh every 30 seconds for real-time tracking
  useEffect(() => {
    if (!autoRefresh || !user) return;

    const interval = setInterval(() => {
      fetchOrders(false);
    }, 30000);

    return () => clearInterval(interval);
  }, [autoRefresh, user, fetchOrders]);

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'refunded':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getOrderStatusIndex = (status: string) => {
    const index = ORDER_STATUSES.findIndex(s => s.key === status);
    return index === -1 ? 0 : index;
  };

  const getOrderStatusProgress = (status: string) => {
    if (status === 'cancelled') return 0;
    if (status === 'completed' || status === 'delivered') return 100;
    const index = getOrderStatusIndex(status);
    return ((index + 1) / ORDER_STATUSES.length) * 100;
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'delivered':
      case 'completed':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'in_transit':
      case 'out_for_delivery':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'shipped':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'confirmed':
      case 'processing':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'cancelled':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return null;
    return new Date(dateString).toLocaleDateString(undefined, {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/account" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>{t.orders.backToAccount}</span>
          </Link>
          <Link to="/">
            <img src={logo} alt="RST" className="h-8" />
          </Link>
          <div className="w-24" />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-heading font-bold">{t.orders.title}</h1>
              {autoRefresh && orders.length > 0 && (
                <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
                  <CircleDot className="w-3 h-3 text-green-500 animate-pulse" />
                  {t.orders?.liveUpdates || 'Live tracking updates enabled'}
                </p>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => fetchOrders(true)}
              disabled={isRefreshing}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              {t.orders.refresh}
            </Button>
          </div>

          {orders.length === 0 ? (
            <div className="text-center py-16 bg-card border border-border">
              <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-heading font-bold mb-2">{t.orders.noOrders}</h2>
              <p className="text-muted-foreground mb-6">{t.orders.noOrdersDesc}</p>
              <Button asChild>
                <Link to="/shop">{t.orders.startShopping}</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map((order) => (
                <div key={order.id} className="bg-card border border-border overflow-hidden">
                  {/* Order Header */}
                  <div 
                    className="p-6 cursor-pointer hover:bg-secondary/30 transition-colors"
                    onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                  >
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                      <div>
                        <h3 className="font-heading font-bold text-lg">{t.orders.order} {order.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          {formatDate(order.created_at)}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline" className={getStatusColor(order.financial_status)}>
                          {order.financial_status}
                        </Badge>
                        <Badge variant="outline" className={getStatusBadgeColor(order.order_status)}>
                          {order.order_status === 'cancelled' && <PackageX className="w-3 h-3 mr-1" />}
                          {order.order_status === 'delivered' && <PackageCheck className="w-3 h-3 mr-1" />}
                          {order.order_status === 'in_transit' && <Truck className="w-3 h-3 mr-1" />}
                          {order.order_status.replace(/_/g, ' ')}
                        </Badge>
                      </div>
                    </div>

                    {/* Tracking Progress Bar */}
                    {order.order_status !== 'cancelled' && (
                      <div className="space-y-3">
                        <Progress 
                          value={getOrderStatusProgress(order.order_status)} 
                          className="h-2"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          {ORDER_STATUSES.map((status, idx) => {
                            const isActive = getOrderStatusIndex(order.order_status) >= idx;
                            const isCurrent = ORDER_STATUSES[getOrderStatusIndex(order.order_status)]?.key === status.key;
                            return (
                              <div 
                                key={status.key} 
                                className={`flex flex-col items-center gap-1 ${
                                  isActive ? 'text-primary' : 'text-muted-foreground'
                                } ${isCurrent ? 'font-medium' : ''}`}
                              >
                                <status.icon className={`w-4 h-4 ${isCurrent ? 'text-primary animate-pulse' : ''}`} />
                                <span className="hidden md:block">{status.label}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Tracking Info */}
                    {order.tracking.number && (
                      <div className="mt-4 p-3 bg-secondary/50 rounded flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Truck className="w-4 h-4 text-primary" />
                          <span className="text-sm">
                            <span className="text-muted-foreground">{order.tracking.company || 'Carrier'}:</span>{' '}
                            <span className="font-mono">{order.tracking.number}</span>
                          </span>
                        </div>
                        {order.tracking.url && (
                          <Button variant="ghost" size="sm" asChild>
                            <a href={order.tracking.url} target="_blank" rel="noopener noreferrer">
                              {t.orders?.trackPackage || 'Track'}
                              <ExternalLink className="w-3 h-3 ml-1" />
                            </a>
                          </Button>
                        )}
                      </div>
                    )}

                    {/* Estimated Delivery */}
                    {order.estimated_delivery_at && !order.delivered_at && (
                      <div className="mt-3 text-sm flex items-center gap-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-muted-foreground">{t.orders?.estimatedDelivery || 'Estimated delivery'}:</span>
                        <span className="font-medium">{formatDate(order.estimated_delivery_at)}</span>
                      </div>
                    )}

                    {/* Delivered Date */}
                    {order.delivered_at && (
                      <div className="mt-3 text-sm flex items-center gap-2 text-green-500">
                        <PackageCheck className="w-4 h-4" />
                        <span>{t.orders?.deliveredOn || 'Delivered on'} {formatDate(order.delivered_at)}</span>
                      </div>
                    )}
                  </div>

                  {/* Expanded Order Details */}
                  {expandedOrder === order.id && (
                    <div className="border-t border-border p-6 bg-secondary/20">
                      <h4 className="font-semibold mb-3">{t.orders?.orderItems || 'Order Items'}</h4>
                      <div className="space-y-3">
                        {order.line_items.map((item) => (
                          <div key={item.id} className="flex justify-between items-center text-sm p-3 bg-background/50 rounded">
                            <div>
                              <span className="font-medium">{item.title}</span>
                              {item.variant_title && (
                                <span className="text-muted-foreground ml-2">({item.variant_title})</span>
                              )}
                              <span className="text-muted-foreground"> × {item.quantity}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              {item.fulfillment_status && (
                                <Badge variant="outline" className="text-xs">
                                  {item.fulfillment_status}
                                </Badge>
                              )}
                              <span className="font-medium">{order.currency} {item.price}</span>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Shipping Address */}
                      {order.shipping_address && (
                        <div className="mt-4 pt-4 border-t border-border">
                          <h4 className="font-semibold mb-2 flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            {t.orders?.shippingTo || 'Shipping to'}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {order.shipping_address.city}, {order.shipping_address.province}, {order.shipping_address.country}
                          </p>
                        </div>
                      )}

                      {/* Order Total & Actions */}
                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                        <span className="font-bold text-lg">
                          {order.currency} {order.total_price}
                        </span>
                        {order.order_status_url && (
                          <Button variant="outline" size="sm" asChild>
                            <a href={order.order_status_url} target="_blank" rel="noopener noreferrer">
                              {t.orders.viewDetails}
                              <ExternalLink className="w-4 h-4 ml-2" />
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AccountOrders;
