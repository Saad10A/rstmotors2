import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Loader2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductGrid from "@/components/ProductGrid";
import { useLanguage } from "@/i18n/LanguageContext";
import SEO from "@/components/SEO";
import { supabase } from "@/integrations/supabase/client";
import urusHeroImage from "@/assets/urus-back.jpg";

interface Car {
  id: string;
  title: string;
  subtitle: string | null;
  price: number;
  images: string[] | null;
  mileage: number | null;
  registration_year: number | null;
  fuel_type: string | null;
}

const Shop = () => {
  const { t } = useLanguage();
  const [cars, setCars] = useState<Car[]>([]);
  const [isLoadingCars, setIsLoadingCars] = useState(true);

  const categories = [
    { key: "carplay", title: "CarPlay", query: "title:carplay OR tag:carplay" },
    { key: "alloy-wheels", title: "Cerchi in Lega", query: "title:cerchi OR title:wheels OR tag:wheels" },
    { key: "led-lights", title: "Luci LED", query: "title:LED OR tag:LED OR tag:lights" },
  ];

  useEffect(() => {
    const fetchCars = async () => {
      setIsLoadingCars(true);
      // Use cars_public view which excludes sensitive PII for public display
      const { data, error } = await supabase
        .from("cars_public")
        .select("id, title, subtitle, price, images, mileage, registration_year, fuel_type")
        .eq("is_sold", false)
        .limit(4);
      
      if (!error && data) {
        setCars(data);
      }
      setIsLoadingCars(false);
    };

    fetchCars();
  }, []);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("it-IT", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-background">
      <SEO 
        title="Shop"
        description="Shop premium performance parts, wheels, exhaust systems, and tuning accessories at RST Motors. Quality automotive upgrades for your vehicle."
        keywords="car parts shop, performance wheels, exhaust systems, tuning parts, automotive accessories, RST Motors shop"
        url="/shop"
      />
      <Header />

      {/* Hero Section */}
      <section className="relative min-h-[40vh] md:min-h-[50vh]">
        <div className="absolute inset-0">
          <img
            src={urusHeroImage}
            alt="RST Performance Vehicle"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        </div>

        <div className="relative z-10 min-h-[40vh] md:min-h-[50vh] flex items-center">
          <div className="max-w-7xl mx-auto px-8 md:px-16 w-full">
            <div className="max-w-2xl">
              <p className="text-primary text-sm tracking-widest mb-2 uppercase">RST Performance®</p>
              <p className="text-muted-foreground text-base mb-2">
                {t.shop.heroSubtitle}
              </p>
              <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold italic uppercase text-foreground leading-[0.9] mb-4">
                {t.shop.heroTitle1}
                <br />
                <span className="text-primary">{t.shop.heroTitle2}</span>
              </h1>
              <div className="mt-6">
                <div className="w-24 h-px bg-primary" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products by Category */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          {categories.map((category, index) => (
            <div key={category.key} className={index > 0 ? "mt-16" : ""}>
              <div className="flex justify-between items-center mb-8">
                <h2 className="font-heading text-2xl md:text-3xl font-bold italic text-foreground">
                  {category.title}
                </h2>
                <Link 
                  to={`/collections/${category.key}`}
                  className="text-primary text-sm tracking-wider hover:underline inline-flex items-center gap-2"
                >
                  {t.common.viewAll} <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
              <ProductGrid query={category.query} limit={4} columns={4} />
            </div>
          ))}
        </div>
      </section>

      {/* Cars for Sale Section */}
      <section className="py-20 bg-card">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-center mb-8">
            <h2 className="font-heading text-2xl md:text-3xl font-bold italic text-foreground">
              Auto in Vendita
            </h2>
            <Link 
              to="/cars"
              className="text-primary text-sm tracking-wider hover:underline inline-flex items-center gap-2"
            >
              {t.common.viewAll} <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {isLoadingCars ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
            </div>
          ) : cars.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Nessuna auto disponibile al momento.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {cars.map((car) => (
                <Link 
                  key={car.id} 
                  to={`/cars/${car.id}`}
                  className="group bg-background rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={car.images?.[0] || "/placeholder.svg"}
                      alt={car.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-heading text-lg font-bold text-foreground line-clamp-1">
                      {car.title}
                    </h3>
                    {car.subtitle && (
                      <p className="text-muted-foreground text-sm line-clamp-1">{car.subtitle}</p>
                    )}
                    <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                      {car.registration_year && <span>{car.registration_year}</span>}
                      {car.mileage && <span>• {car.mileage.toLocaleString()} km</span>}
                      {car.fuel_type && <span>• {car.fuel_type}</span>}
                    </div>
                    <p className="mt-3 text-primary font-bold text-lg">
                      {formatPrice(car.price)}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Shop;