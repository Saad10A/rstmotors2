import { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/i18n/LanguageContext';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Loader2, CreditCard, Shield, ExternalLink } from 'lucide-react';
import logo from '@/assets/logo.png';

const AccountPayment = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const paymentMethods = [
    {
      icon: (
        <svg viewBox="0 0 24 24" className="w-8 h-8" fill="none">
          <rect x="2" y="5" width="20" height="14" rx="2" className="stroke-current" strokeWidth="2" />
          <path d="M2 10h20" className="stroke-current" strokeWidth="2" />
        </svg>
      ),
      title: t.payment?.creditCard || 'Credit/Debit Cards',
      description: t.payment?.creditCardDesc || 'Visa, Mastercard, American Express',
    },
    {
      icon: (
        <svg viewBox="0 0 24 24" className="w-8 h-8 text-[#00457C]">
          <path fill="currentColor" d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 3.384a.77.77 0 0 1 .757-.644h5.582c2.658 0 4.526.545 5.548 1.618.982 1.033 1.38 2.544 1.18 4.488-.206 1.992-.867 3.65-1.959 4.928-1.157 1.357-2.784 2.097-4.838 2.195l-.155.005H8.59l-.793 4.848a.63.63 0 0 1-.623.515h.098Z"/>
        </svg>
      ),
      title: 'PayPal',
      description: t.payment?.paypalDesc || 'Fast and secure payments with PayPal',
    },
    {
      icon: (
        <svg viewBox="0 0 24 24" className="w-8 h-8">
          <path fill="currentColor" d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
        </svg>
      ),
      title: 'Apple Pay',
      description: t.payment?.applePayDesc || 'Express checkout with Apple Pay',
    },
    {
      icon: (
        <svg viewBox="0 0 40 16" className="w-10 h-8" fill="none">
          <path d="M13.1 7.1C13.1 6.7 13.1 6.3 13 5.9H6.7V8.2H10.3C10.1 9.1 9.6 9.8 8.9 10.3V12H11.1C12.4 10.8 13.1 9.1 13.1 7.1Z" fill="#4285F4"/>
          <path d="M6.7 13.9C8.4 13.9 9.8 13.4 10.8 12.5L8.6 10.8C8 11.2 7.4 11.4 6.7 11.4C5 11.4 3.6 10.2 3.1 8.6H0.9V10.4C2 12.5 4.2 13.9 6.7 13.9Z" fill="#34A853"/>
          <path d="M3.1 8.6C2.9 8 2.8 7.5 2.8 7C2.8 6.5 2.9 6 3.1 5.4V3.6H0.9C0.3 4.8 0 6.1 0 7.5C0 8.9 0.3 10.2 0.9 11.4L3.1 9.6V8.6Z" fill="#FBBC05"/>
          <path d="M6.7 2.6C7.6 2.6 8.4 2.9 9 3.5L10.8 1.7C9.7 0.6 8.3 0 6.7 0C4.2 0 2 1.4 0.9 3.5L3.1 5.3C3.6 3.8 5 2.6 6.7 2.6Z" fill="#EA4335"/>
        </svg>
      ),
      title: 'Google Pay',
      description: t.payment?.googlePayDesc || 'Express checkout with Google Pay',
    },
    {
      icon: (
        <svg viewBox="0 0 24 24" className="w-8 h-8 text-[#FFB3C7]">
          <rect x="2" y="6" width="20" height="12" rx="2" fill="currentColor"/>
          <text x="12" y="14" textAnchor="middle" fontSize="6" fill="#000" fontWeight="bold">Klarna</text>
        </svg>
      ),
      title: 'Klarna',
      description: t.payment?.klarnaDesc || 'Pay in 3 interest-free installments',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/account" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>{t.payment?.backToAccount || 'Back to Account'}</span>
          </Link>
          <Link to="/">
            <img src={logo} alt="RST" className="h-8" />
          </Link>
          <div className="w-24" />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-heading font-bold mb-2">{t.payment?.title || 'Payment Methods'}</h1>
          <p className="text-muted-foreground mb-8">{t.payment?.subtitle || 'Manage your payment options for faster checkout'}</p>

          {/* Secure Payment Notice */}
          <div className="bg-secondary/50 border border-border p-4 mb-8 flex items-start gap-3">
            <Shield className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <p className="font-medium">{t.payment?.secureTitle || 'Secure Payment Processing'}</p>
              <p className="text-sm text-muted-foreground">
                {t.payment?.secureDesc || 'Your payment information is securely processed by Shopify Payments. We never store your full card details.'}
              </p>
            </div>
          </div>

          {/* Available Payment Methods */}
          <div className="space-y-4 mb-8">
            <h2 className="text-lg font-semibold">{t.payment?.availableMethods || 'Available Payment Methods'}</h2>
            <div className="bg-card border border-border divide-y divide-border">
              {paymentMethods.map((method, index) => (
                <div key={index} className="flex items-center gap-4 p-4">
                  <div className="w-12 h-12 bg-secondary flex items-center justify-center">
                    {method.icon}
                  </div>
                  <div>
                    <p className="font-medium">{method.title}</p>
                    <p className="text-sm text-muted-foreground">{method.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Shopify Info */}
          <div className="bg-card border border-border p-6">
            <div className="flex items-start gap-4">
              <CreditCard className="w-8 h-8 text-primary" />
              <div className="flex-1">
                <h3 className="font-semibold mb-2">{t.payment?.shopifyTitle || 'Powered by Shopify Payments'}</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {t.payment?.shopifyDesc || 'Payment methods are managed securely during checkout. You can save your preferred payment method when completing a purchase.'}
                </p>
                <Button variant="outline" asChild>
                  <Link to="/shop">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    {t.payment?.shopNow || 'Shop Now'}
                  </Link>
                </Button>
              </div>
            </div>
          </div>

          <p className="text-sm text-muted-foreground mt-8 text-center">
            {t.payment?.note || 'Payment methods will be saved to your account after your first purchase for faster checkout.'}
          </p>
        </div>
      </main>
    </div>
  );
};

export default AccountPayment;
