import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { AuthProvider } from "@/hooks/useAuth";
import { ScrollToTop } from "@/components/ScrollToTop";
import { CookieBanner } from "@/components/CookieBanner";
import Index from "./pages/Index";
import Configurator from "./pages/Configurator";
import ConfiguratorUrus from "./pages/ConfiguratorUrus";
import ConfiguratorM8 from "./pages/ConfiguratorM8";
import Models from "./pages/Models";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import About from "./pages/About";
import Collections from "./pages/Collections";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import Contact from "./pages/Contact";
import Wishlist from "./pages/Wishlist";
import Auth from "./pages/Auth";
import Account from "./pages/Account";
import AccountProfile from "./pages/AccountProfile";
import AccountOrders from "./pages/AccountOrders";
import AccountAddresses from "./pages/AccountAddresses";
import AccountPayment from "./pages/AccountPayment";
import AccountSettings from "./pages/AccountSettings";
import Cars from "./pages/Cars";
import CarDetail from "./pages/CarDetail";
import Admin from "./pages/Admin";
import AdminCarForm from "./pages/AdminCarForm";
import NotFound from "./pages/NotFound";
import PrivacyPolicy from "./pages/PrivacyPolicy";

const queryClient = new QueryClient();

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/configurator" element={<Configurator />} />
            <Route path="/configurator/urus" element={<ConfiguratorUrus />} />
            <Route path="/configurator/m8" element={<ConfiguratorM8 />} />
            <Route path="/models" element={<Models />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/product/:handle" element={<ProductDetail />} />
            <Route path="/about" element={<About />} />
            <Route path="/collections" element={<Collections />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:id" element={<BlogPost />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/wishlist" element={<Wishlist />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/account" element={<Account />} />
            <Route path="/account/profile" element={<AccountProfile />} />
            <Route path="/account/orders" element={<AccountOrders />} />
            <Route path="/account/addresses" element={<AccountAddresses />} />
            <Route path="/account/payment" element={<AccountPayment />} />
            <Route path="/account/settings" element={<AccountSettings />} />
            <Route path="/cars" element={<Cars />} />
            <Route path="/cars/:id" element={<CarDetail />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/admin/cars/new" element={<AdminCarForm />} />
            <Route path="/admin/cars/:id/edit" element={<AdminCarForm />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
          <CookieBanner />
          </BrowserRouter>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;
