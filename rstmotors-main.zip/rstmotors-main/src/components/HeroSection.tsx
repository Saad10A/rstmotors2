import { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "@/i18n/LanguageContext";
import rs7HeroImage from "@/assets/rs7-hero.jpg";
import carplayInteriorImage from "@/assets/carplay-interior.png";
import customHeadlightsImage from "@/assets/custom-headlights.jpg";

const HeroSection = () => {
  const { t } = useLanguage();
  const [currentSlide, setCurrentSlide] = useState(0);
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  const slides = [
    {
      id: 1,
      title: t.hero.slide1Title,
      subtitle: t.hero.slide1Subtitle,
      image: rs7HeroImage,
      buttonText: t.hero.slide1Button,
      buttonLink: "/configurator",
    },
    {
      id: 2,
      title: t.hero.slide2Title,
      subtitle: t.hero.slide2Subtitle,
      image: carplayInteriorImage,
      buttonText: t.hero.slide2Button,
      buttonLink: "/shop",
    },
    {
      id: 3,
      title: t.hero.slide3Title,
      subtitle: t.hero.slide3Subtitle,
      image: customHeadlightsImage,
      buttonText: t.hero.slide3Button,
      buttonLink: "/shop",
    },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const goToPrevious = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToNext = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    
    const diff = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 50;

    if (Math.abs(diff) > minSwipeDistance) {
      if (diff > 0) {
        goToNext();
      } else {
        goToPrevious();
      }
    }

    touchStartX.current = null;
    touchEndX.current = null;
  };

  return (
    <section 
      className="relative h-[45vh] md:h-screen w-full overflow-hidden"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Background images with fade and scale transitions */}
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-all duration-1000 ease-out ${
            index === currentSlide 
              ? "opacity-100 scale-100" 
              : "opacity-0 scale-105"
          }`}
        >
          <img
            src={slide.image}
            alt={slide.title}
            className={`w-full h-full object-cover transition-transform duration-[6000ms] ease-out ${
              index === currentSlide ? "scale-110" : "scale-100"
            }`}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        </div>
      ))}

      {/* Navigation Arrows - Hidden on mobile, visible on desktop */}
      <button
        onClick={goToPrevious}
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-10 w-12 h-12 hidden md:flex items-center justify-center bg-background/20 backdrop-blur-sm border border-foreground/20 hover:bg-primary hover:border-primary transition-all duration-300 group -skew-x-12"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-6 h-6 text-foreground group-hover:text-primary-foreground transition-colors skew-x-12" />
      </button>
      <button
        onClick={goToNext}
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-10 w-12 h-12 hidden md:flex items-center justify-center bg-background/20 backdrop-blur-sm border border-foreground/20 hover:bg-primary hover:border-primary transition-all duration-300 group -skew-x-12"
        aria-label="Next slide"
      >
        <ChevronRight className="w-6 h-6 text-foreground group-hover:text-primary-foreground transition-colors skew-x-12" />
      </button>

      {/* Content - Mobile: overlaid on image, Desktop: bottom positioned */}
      <div className="absolute bottom-16 md:bottom-24 left-0 right-0 text-center px-4">
        <h2 
          key={`title-${currentSlide}`}
          className="font-heading text-3xl md:text-5xl lg:text-6xl font-bold italic text-foreground mb-1 md:mb-2 animate-fade-in drop-shadow-lg"
        >
          {slides[currentSlide].title}
        </h2>
        <p 
          key={`subtitle-${currentSlide}`}
          className="text-muted-foreground text-sm md:text-lg mb-4 md:mb-6 animate-fade-in drop-shadow-md"
          style={{ animationDelay: '0.1s' }}
        >
          {slides[currentSlide].subtitle}
        </p>
        
        {/* Slide indicators - Simple lines on mobile */}
        <div className="flex justify-center gap-2 md:hidden mb-4">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-0.5 transition-all duration-300 ${
                index === currentSlide
                  ? "w-8 bg-primary"
                  : "w-6 bg-muted-foreground/50"
              }`}
            />
          ))}
        </div>

        {/* CTA Button - Hidden on mobile, visible on desktop */}
        <Link
          to={slides[currentSlide].buttonLink}
          className="hidden md:inline-block -skew-x-12 bg-primary hover:bg-primary/90 transition-all duration-300 hover:scale-105"
        >
          <span className="inline-block skew-x-12 px-10 py-3 text-primary-foreground font-semibold tracking-wider">
            {slides[currentSlide].buttonText}
          </span>
        </Link>
      </div>

      {/* Slide indicators - Desktop only, Rhombus style */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 hidden md:flex gap-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`h-2 -skew-x-12 transition-all duration-300 ${
              index === currentSlide
                ? "w-8 bg-primary"
                : "w-4 bg-muted-foreground/50 hover:bg-muted-foreground"
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroSection;
