import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'product';
  article?: {
    publishedTime?: string;
    modifiedTime?: string;
    author?: string;
    section?: string;
  };
  product?: {
    price?: string;
    currency?: string;
    availability?: string;
  };
  noindex?: boolean;
}

const SITE_NAME = 'RST Motors';
const DEFAULT_DESCRIPTION = 'RST Motors - Installazione Autoradio Carplay, Tuning e Fanali Custom Professionali. Upgrade performance, sospensioni sportive, interni, cerchi e altro per la tua auto.';
const DEFAULT_IMAGE = 'https://nhpqirkpxvsgzufakvds.supabase.co/storage/v1/object/public/assets/og-image.jpg';
const SITE_URL = 'https://rstmotors.it';

export const SEO = ({
  title,
  description = DEFAULT_DESCRIPTION,
  keywords = 'tuning auto, upgrade performance, personalizzazione veicoli, cerchi sportivi, aerodinamica, installazione carplay, fanali custom, impianti scarico, RST Motors, tuning Italia',
  image = DEFAULT_IMAGE,
  url,
  type = 'website',
  article,
  product,
  noindex = false,
}: SEOProps) => {
  const pageTitle = title ? `${title} | ${SITE_NAME}` : `${SITE_NAME} | Installazione Autoradio Carplay, Tuning e Fanali Custom`;
  const pageUrl = url ? `${SITE_URL}${url}` : SITE_URL;
  const imageUrl = image.startsWith('http') ? image : `${SITE_URL}${image}`;

  return (
    <Helmet>
      {/* Primary Meta Tags */}
      <title>{pageTitle}</title>
      <meta name="title" content={pageTitle} />
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      {noindex && <meta name="robots" content="noindex, nofollow" />}
      
      {/* Canonical URL */}
      <link rel="canonical" href={pageUrl} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={type} />
      <meta property="og:url" content={pageUrl} />
      <meta property="og:title" content={pageTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={imageUrl} />
      <meta property="og:site_name" content={SITE_NAME} />
      <meta property="og:locale" content="it_IT" />
      <meta property="og:locale:alternate" content="en_GB" />
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:url" content={pageUrl} />
      <meta name="twitter:title" content={pageTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={imageUrl} />
      
      {/* Article specific */}
      {type === 'article' && article && (
        <>
          {article.publishedTime && <meta property="article:published_time" content={article.publishedTime} />}
          {article.modifiedTime && <meta property="article:modified_time" content={article.modifiedTime} />}
          {article.author && <meta property="article:author" content={article.author} />}
          {article.section && <meta property="article:section" content={article.section} />}
        </>
      )}
      
      {/* Product specific */}
      {type === 'product' && product && (
        <>
          {product.price && <meta property="product:price:amount" content={product.price} />}
          {product.currency && <meta property="product:price:currency" content={product.currency} />}
          {product.availability && <meta property="product:availability" content={product.availability} />}
        </>
      )}
      
      {/* Structured Data - Organization */}
      <script type="application/ld+json">
        {JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'AutoDealer',
          name: SITE_NAME,
          description: DEFAULT_DESCRIPTION,
          url: SITE_URL,
          logo: `${SITE_URL}/logo.png`,
          sameAs: [
            'https://instagram.com/rstmotors',
            'https://facebook.com/rstmotors',
            'https://youtube.com/rstmotors'
          ],
          address: {
            '@type': 'PostalAddress',
            addressCountry: 'IT'
          },
          contactPoint: {
            '@type': 'ContactPoint',
            contactType: 'customer service',
            availableLanguage: ['Italian', 'English']
          }
        })}
      </script>
    </Helmet>
  );
};

export default SEO;
