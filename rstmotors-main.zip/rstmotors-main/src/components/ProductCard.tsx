import { useState } from "react";
import { Link } from "react-router-dom";
import { ShoppingCart, Plus, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShopifyProduct } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";
import { useWishlistStore } from "@/stores/wishlistStore";
import { toast } from "sonner";
import { useLanguage } from "@/i18n/LanguageContext";

interface ProductCardProps {
  product: ShopifyProduct;
}

export const ProductCard = ({ product }: ProductCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const addItem = useCartStore(state => state.addItem);
  const { addItem: addToWishlist, removeItem: removeFromWishlist, isInWishlist } = useWishlistStore();
  const { t } = useLanguage();
  const { node } = product;
  
  const firstImage = node.images.edges[0]?.node;
  const secondImage = node.images.edges[1]?.node;
  const firstVariant = node.variants.edges[0]?.node;
  const price = node.priceRange.minVariantPrice;
  const compareAtPrice = firstVariant?.compareAtPrice;
  const isOnSale = compareAtPrice && parseFloat(compareAtPrice.amount) > parseFloat(price.amount);
  const isWishlisted = isInWishlist(node.id);

  // Show second image on hover if available, otherwise show first
  const displayImage = isHovered && secondImage ? secondImage : firstImage;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!firstVariant) {
      toast.error("Product variant not available");
      return;
    }

    addItem({
      product,
      variantId: firstVariant.id,
      variantTitle: firstVariant.title,
      price: firstVariant.price,
      quantity: 1,
      selectedOptions: firstVariant.selectedOptions || []
    });

    toast.success(t.productDetail.addedToCart, {
      description: node.title,
      position: "top-center"
    });
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isWishlisted) {
      removeFromWishlist(node.id);
      toast.success(t.productDetail.removedFromWishlist, {
        description: node.title,
        position: "top-center"
      });
    } else {
      addToWishlist(product);
      toast.success(t.productDetail.addedToWishlist, {
        description: node.title,
        position: "top-center"
      });
    }
  };

  return (
    <Link 
      to={`/product/${node.handle}`}
      className="group block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="bg-card border border-border rounded-lg overflow-hidden transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10">
        {/* Image */}
        <div className="aspect-square bg-muted/10 overflow-hidden relative">
          {displayImage ? (
            <img
              src={displayImage.url}
              alt={displayImage.altText || node.title}
              className="w-full h-full object-cover transition-opacity duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              <ShoppingCart className="w-12 h-12" />
            </div>
          )}
          
          {/* Sale Badge */}
          {isOnSale && (
            <Badge className="absolute top-3 left-3 bg-destructive text-destructive-foreground">
              {t.productDetail.sale}
            </Badge>
          )}

          {/* Wishlist Button */}
          <Button
            onClick={handleWishlistToggle}
            size="icon"
            variant="ghost"
            className={`absolute top-3 right-3 h-9 w-9 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background ${
              isWishlisted ? "text-destructive" : "text-muted-foreground hover:text-destructive"
            }`}
          >
            <Heart className={`w-5 h-5 ${isWishlisted ? "fill-current" : ""}`} />
          </Button>
          
          {/* Quick Add Button */}
          <Button
            onClick={handleAddToCart}
            size="sm"
            className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-primary hover:bg-primary/90"
          >
            <Plus className="w-4 h-4 mr-1" />
            {t.common.addToCart}
          </Button>
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="font-heading text-lg font-bold text-foreground line-clamp-1 group-hover:text-primary transition-colors">
            {node.title}
          </h3>
          <p className="text-muted-foreground text-sm line-clamp-2 mt-1 h-10">
            {node.description || "Premium RST Performance product"}
          </p>
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-primary font-bold text-lg">
                {price.currencyCode} {parseFloat(price.amount).toFixed(2)}
              </span>
              {compareAtPrice && parseFloat(compareAtPrice.amount) > parseFloat(price.amount) && (
                <span className="text-muted-foreground text-sm line-through">
                  {compareAtPrice.currencyCode} {parseFloat(compareAtPrice.amount).toFixed(2)}
                </span>
              )}
            </div>
            {firstVariant?.availableForSale === false && (
              <span className="text-xs text-destructive uppercase tracking-wider">{t.productDetail.outOfStock}</span>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
