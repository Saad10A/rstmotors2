import { Facebook, Instagram, Youtube, Twitter, Phone } from "lucide-react";
import logo from "@/assets/logo.png";
import footerCta from "@/assets/footer-cta.jpg";
import { useLanguage } from "@/i18n/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { toast } from "sonner";

const Footer = () => {
  const { t } = useLanguage();
  const [email, setEmail] = useState("");

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success("Successfully subscribed to newsletter!");
      setEmail("");
    }
  };

  return (
    <footer className="bg-black text-white">
      {/* Newsletter Hero Section with Full Width Background */}
      <div 
        className="relative w-full min-h-[300px] md:min-h-[400px] bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${footerCta})` }}
      >
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/40" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 py-16 md:py-24 flex flex-col justify-center h-full">
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold italic leading-tight mb-8 max-w-xl">
            {t.footerSection.newsletterTitle || "What will you discover?"}
          </h2>
          <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md">
            <Input
              type="email"
              placeholder={t.footer.emailPlaceholder}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-black/50 border-white/30 text-white placeholder:text-white/50 focus:border-primary backdrop-blur-sm"
              required
            />
            <Button type="submit" variant="outline" className="border-white text-white hover:bg-white hover:text-black whitespace-nowrap">
              {t.footer.subscribe}
            </Button>
          </form>
        </div>
      </div>

      {/* Links Section */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 mb-12">
            {/* Logo & Contact */}
            <div className="col-span-2 md:col-span-1">
              <img src={logo} alt="RST Performance" className="h-8 mb-6 brightness-0 invert" />
              <div className="space-y-3 text-sm">
                <p className="text-xs border border-green-500 text-green-500 px-3 py-1.5 rounded-full inline-block">
                  ● {t.footerSection.openNow || "Open Now"}
                </p>
                <p className="flex items-center gap-2 mt-4 text-xs border border-white/30 text-white/60 px-3 py-1.5 rounded-full">
                  <Phone size={12} />
                  {t.contact.phone}
                </p>
              </div>
            </div>

            {/* Cars */}
            <div>
              <h4 className="text-sm font-bold uppercase text-white mb-4">
                {t.footerSection.cars}
              </h4>
              <ul className="space-y-2">
                <li><a href="/models" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.specialEditions}</a></li>
                <li><a href="/models" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.models}</a></li>
                <li><a href="/collections" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.products}</a></li>
              </ul>
            </div>

            {/* Products */}
            <div>
              <h4 className="text-sm font-bold uppercase text-white mb-4">
                {t.footerSection.products}
              </h4>
              <ul className="space-y-2">
                <li><a href="/collections" className="text-white/60 text-sm hover:text-white transition-colors">{t.menu.wheels}</a></li>
                <li><a href="/collections" className="text-white/60 text-sm hover:text-white transition-colors">{t.menu.carplay}</a></li>
                <li><a href="/collections" className="text-white/60 text-sm hover:text-white transition-colors">{t.menu.headlights}</a></li>
                <li><a href="/collections" className="text-white/60 text-sm hover:text-white transition-colors">{t.menu.exhaust}</a></li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-sm font-bold uppercase text-white mb-4">
                {t.footerSection.company}
              </h4>
              <ul className="space-y-2">
                <li><a href="/about" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.aboutUs}</a></li>
                <li><a href="/blog" className="text-white/60 text-sm hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.careers}</a></li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="text-sm font-bold uppercase text-white mb-4">
                {t.footerSection.support}
              </h4>
              <ul className="space-y-2">
                <li><a href="/contact" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.contact}</a></li>
                <li><a href="#" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.faq}</a></li>
                <li><a href="#" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.dealers}</a></li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-sm font-bold uppercase text-white mb-4">
                {t.footerSection.legal}
              </h4>
              <ul className="space-y-2">
                <li><a href="/privacy-policy" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.privacyPolicy}</a></li>
                <li><a href="#" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.termsOfService}</a></li>
                <li><a href="#" className="text-white/60 text-sm hover:text-white transition-colors">{t.footerSection.imprint}</a></li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-white/10">
            <p className="text-white/40 text-xs mb-4 md:mb-0">
              {t.footerSection.copyright}
            </p>
            
            {/* Social icons */}
            <div className="flex gap-4">
              <a href="#" className="text-white/40 hover:text-white transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-white/40 hover:text-white transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-white/40 hover:text-white transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="text-white/40 hover:text-white transition-colors">
                <Youtube size={18} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
