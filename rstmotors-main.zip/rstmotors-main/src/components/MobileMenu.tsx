import { useState, useEffect } from "react";
import { X, Search, Loader2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useLanguage } from "@/i18n/LanguageContext";
import { fetchProducts, ShopifyProduct } from "@/lib/shopify";
import rs7Image from "@/assets/rs7.png";
import wheelsImage from "@/assets/wheels.png";
import carplayImage from "@/assets/carplay.png";
import headlightsImage from "@/assets/headlights.png";
import exhaustImage from "@/assets/exhaust.png";
import steeringwheelImage from "@/assets/steeringwheel.png";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu = ({ isOpen, onClose }: MobileMenuProps) => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [hoveredItem, setHoveredItem] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAnimating, setIsAnimating] = useState(false);
  const [searchResults, setSearchResults] = useState<ShopifyProduct[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const menuItems = [
    { title: t.menu.collections, image: rs7Image, link: "/collections" },
    { title: t.menu.vehiclesForSale, image: rs7Image, link: "/collections" },
    { title: t.menu.wheels, image: wheelsImage, link: "/collections?collection=wheels" },
    { title: t.menu.carplay, image: carplayImage, link: "/collections?collection=carplay" },
    { title: t.menu.headlights, image: headlightsImage, link: "/collections?collection=headlights" },
    { title: t.menu.exhaust, image: exhaustImage, link: "/collections?collection=exhaust" },
    { title: t.menu.steeringWheel, image: steeringwheelImage, link: "/collections?collection=steering" },
    { title: t.homepage.tabModels, image: rs7Image, link: "/models" },
    { title: t.menu.aboutUs, image: rs7Image, link: "/" },
  ];

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => setIsAnimating(true), 50);
      // Prevent body scroll when menu is open
      document.body.style.overflow = 'hidden';
      return () => {
        clearTimeout(timer);
        document.body.style.overflow = '';
      };
    } else {
      setIsAnimating(false);
      setSearchQuery("");
      setSearchResults([]);
      document.body.style.overflow = '';
    }
  }, [isOpen]);

  // Search products with debounce
  useEffect(() => {
    if (searchQuery.length < 2) {
      setSearchResults([]);
      return;
    }

    const debounceTimer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const products = await fetchProducts(10, `title:${searchQuery}*`);
        setSearchResults(products);
      } catch (error) {
        console.error('Search error:', error);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  const handleProductClick = (handle: string) => {
    navigate(`/product/${handle}`);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Dark overlay - only visible on desktop */}
      <div 
        className="hidden md:block fixed inset-0 bg-black/70 z-40 transition-opacity duration-300"
        onClick={onClose}
        style={{ opacity: isAnimating ? 1 : 0 }}
      />
      
      {/* Menu panel - Full screen on mobile, sidebar on desktop */}
      <div 
        className={`fixed inset-0 md:inset-y-0 md:left-0 md:right-auto md:w-[420px] z-50 bg-background flex flex-col transition-transform duration-300 ease-out overflow-hidden ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Header with close and search */}
        <div className="pt-16 pb-6 px-6">
          <div className="relative">
            <input
              type="text"
              placeholder={t.menu.searchProducts}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-muted/50 text-foreground placeholder-muted-foreground py-3 px-4 pr-10 text-sm border border-border/50 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
            />
            {isSearching ? (
              <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground animate-spin" />
            ) : (
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            )}
          </div>

          {/* Search Results */}
          {searchQuery.length >= 2 && (
            <div className="mt-2 max-h-60 overflow-y-auto bg-card border border-border rounded-md">
              {isSearching ? (
                <div className="p-4 text-center text-muted-foreground text-sm">
                  {t.menu.searching}
                </div>
              ) : searchResults.length === 0 ? (
                <div className="p-4 text-center text-muted-foreground text-sm">
                  {t.menu.noResults}
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {searchResults.map((product) => (
                    <button
                      key={product.node.id}
                      onClick={() => handleProductClick(product.node.handle)}
                      className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors text-left"
                    >
                      {product.node.images?.edges?.[0]?.node && (
                        <img
                          src={product.node.images.edges[0].node.url}
                          alt={product.node.title}
                          className="w-12 h-12 object-cover rounded"
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          {product.node.title}
                        </p>
                        <p className="text-xs text-primary">
                          {product.node.priceRange?.minVariantPrice?.currencyCode}{" "}
                          {parseFloat(product.node.priceRange?.minVariantPrice?.amount || "0").toFixed(2)}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Menu items */}
        <nav className="flex-1 overflow-y-auto px-4 py-2">
          <ul className="space-y-1">
            {menuItems.map((item, index) => (
              <li 
                key={index} 
                className="overflow-hidden"
                style={{
                  opacity: isAnimating ? 1 : 0,
                  transform: isAnimating ? 'translateX(0)' : 'translateX(-20px)',
                  transition: `all 0.4s cubic-bezier(0.4, 0, 0.2, 1) ${index * 0.05}s`
                }}
              >
                <Link
                  to={item.link}
                  onClick={onClose}
                  onMouseEnter={() => setHoveredItem(index)}
                  onMouseLeave={() => setHoveredItem(null)}
                  className={`group flex items-center justify-between border-l-2 bg-muted/30 transition-all duration-300 ease-out ${
                    hoveredItem === index
                      ? "border-primary bg-muted/60 translate-x-2"
                      : "border-muted-foreground/30 hover:border-primary hover:bg-muted/60 hover:translate-x-2"
                  }`}
                >
                  {/* Text */}
                  <span className={`py-4 px-5 font-semibold text-sm tracking-widest transition-all duration-300 ${
                    hoveredItem === index
                      ? "text-primary"
                      : "text-foreground group-hover:text-primary"
                  }`}>
                    {item.title}
                  </span>
                  
                  {/* Preview Image */}
                  <div className="w-28 h-20 flex-shrink-0 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className={`w-full h-full object-cover transition-all duration-500 ease-out ${
                        hoveredItem === index
                          ? "scale-110 brightness-125"
                          : "scale-100 brightness-90 group-hover:scale-110 group-hover:brightness-125"
                      }`}
                    />
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Bottom bar */}
        <div 
          className="border-t border-border/50 p-4"
          style={{
            opacity: isAnimating ? 1 : 0,
            transform: isAnimating ? 'translateY(0)' : 'translateY(10px)',
            transition: `all 0.4s cubic-bezier(0.4, 0, 0.2, 1) ${menuItems.length * 0.05 + 0.1}s`
          }}
        >
          <Link
            to="/collections"
            onClick={onClose}
            className="block w-full py-4 px-4 text-sm font-bold text-primary-foreground bg-primary hover:bg-primary/90 transition-colors text-center tracking-widest"
          >
            {t.menu.viewAll}
          </Link>
        </div>

        {/* Close button in header area */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 w-10 h-10 flex items-center justify-center z-50 text-foreground hover:text-primary transition-colors"
        >
          <X size={24} />
        </button>
      </div>
    </>
  );
};

export default MobileMenu;