import { useLanguage } from "@/i18n/LanguageContext";

const NewsSection = () => {
  const { t } = useLanguage();

  const newsItems = [
    {
      id: 1,
      title: t.homepage.news1Title,
      excerpt: t.homepage.news1Excerpt,
      image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80",
    },
    {
      id: 2,
      title: t.homepage.news2Title,
      excerpt: t.homepage.news2Excerpt,
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80",
    },
    {
      id: 3,
      title: t.homepage.news3Title,
      excerpt: t.homepage.news3Excerpt,
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800&q=80",
    },
  ];

  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <h2 className="animate-on-scroll font-heading text-3xl md:text-4xl font-bold italic uppercase text-foreground text-center mb-16">
          {t.homepage.newsTitle}
        </h2>

        {/* News grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {newsItems.map((item, index) => (
            <article 
              key={item.id} 
              className="animate-on-scroll group cursor-pointer"
              style={{ transitionDelay: `${index * 0.15}s` }}
            >
              <div className="overflow-hidden mb-6">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <h3 className="font-heading text-base font-bold uppercase text-foreground mb-3 leading-tight">
                {item.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                {item.excerpt}
              </p>
              <button className="text-foreground text-sm font-semibold hover:text-primary transition-colors">
                {t.homepage.continueReading}
              </button>
            </article>
          ))}
        </div>

        {/* CTA button */}
        <div className="text-center mt-16">
          <button className="animate-on-scroll bg-primary text-primary-foreground px-8 py-3 font-heading text-sm font-semibold tracking-wider hover:bg-primary/90 transition-colors">
            {t.homepage.viewAllNews}
          </button>
        </div>
      </div>
    </section>
  );
};

export default NewsSection;
