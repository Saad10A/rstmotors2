import { useLanguage } from "@/i18n/LanguageContext";

const SpecialEditionsSection = () => {
  const { t } = useLanguage();

  return (
    <section className="relative h-[80vh] w-full overflow-hidden">
      <img
        src="https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=1920&q=80"
        alt="Special Edition"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-background/60 via-transparent to-transparent" />
      
      {/* Label */}
      <div className="absolute bottom-1/4 left-8 md:left-16">
        <div className="animate-slide-left bg-background/90 px-6 py-4">
          <h3 className="font-heading text-xl md:text-2xl font-bold italic text-foreground">
            {t.homepage.specialEditionsTitle}
          </h3>
          <p className="text-primary text-sm uppercase tracking-wider mt-1">
            {t.homepage.specialEditionsSubtitle}
          </p>
        </div>
      </div>
    </section>
  );
};

export default SpecialEditionsSection;
