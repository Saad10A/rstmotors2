import { useLanguage } from "@/i18n/LanguageContext";

const ConfigureSection = () => {
  const { t } = useLanguage();

  return (
    <section className="relative min-h-[80vh] flex flex-col lg:flex-row">
      {/* Car image */}
      <div className="lg:w-2/3 h-[50vh] lg:h-auto relative">
        <img
          src="https://images.unsplash.com/photo-1555215695-3004980ad54e?w=1920&q=80"
          alt="Configure Vehicle"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-background/80 lg:block hidden" />
      </div>

      {/* Content */}
      <div className="lg:w-1/3 bg-background flex items-center justify-center p-8 lg:p-16">
        <div className="max-w-md">
          <h2 className="animate-slide-right font-heading text-3xl md:text-4xl font-bold italic uppercase text-foreground mb-6">
            {t.homepage.configureTitle}
          </h2>
          <p className="animate-slide-right text-muted-foreground mb-8 leading-relaxed">
            {t.homepage.configureDesc}
          </p>
          <a href="/models" className="animate-slide-right border border-foreground px-8 py-3 font-heading text-sm font-semibold tracking-wider text-foreground hover:bg-foreground hover:text-background transition-colors">
            {t.homepage.configureButton}
          </a>
        </div>
      </div>
    </section>
  );
};

export default ConfigureSection;
