import { useLanguage } from "@/i18n/LanguageContext";

const FeaturedCarsSection = () => {
  const { t } = useLanguage();

  const featuredCars = [
    {
      id: 1,
      title: t.homepage.featuredCar1Title,
      subtitle: t.homepage.featuredCar1Subtitle,
      image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?w=1200&q=80",
    },
    {
      id: 2,
      title: t.homepage.featuredCar2Title,
      subtitle: t.homepage.featuredCar2Subtitle,
      image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=1200&q=80",
    },
  ];

  return (
    <section className="grid grid-cols-1 lg:grid-cols-2">
      {featuredCars.map((car, index) => (
        <div key={car.id} className="relative h-[60vh] group overflow-hidden">
          <img
            src={car.image}
            alt={car.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
          
          {/* Label */}
          <div className="absolute bottom-8 left-8">
            <div 
              className={`animate-on-scroll bg-background/90 px-5 py-3`}
              style={{ transitionDelay: `${index * 0.15}s` }}
            >
              <h3 className="font-heading text-lg font-bold italic text-foreground">
                {car.title}
              </h3>
              <p className="text-muted-foreground text-sm uppercase tracking-wider">
                {car.subtitle}
              </p>
            </div>
          </div>
        </div>
      ))}
    </section>
  );
};

export default FeaturedCarsSection;
