import { useEffect, useState } from "react";
import { Loader2, Package } from "lucide-react";
import { fetchProducts, ShopifyProduct } from "@/lib/shopify";
import ProductCard from "./ProductCard";

interface ProductGridProps {
  query?: string;
  limit?: number;
  columns?: 3 | 4;
}

export const ProductGrid = ({ query, limit = 20, columns = 4 }: ProductGridProps) => {
  const [products, setProducts] = useState<ShopifyProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadProducts = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const data = await fetchProducts(limit, query);
        setProducts(data);
      } catch (err) {
        console.error("Failed to fetch products:", err);
        setError("Failed to load products. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    };

    loadProducts();
  }, [query, limit]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-destructive">{error}</p>
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="font-heading text-xl font-bold text-foreground mb-2">Nessun prodotto</h3>
        <p className="text-muted-foreground max-w-md mx-auto text-sm">
          Stiamo aggiungendo nuovi prodotti. Torna presto!
        </p>
      </div>
    );
  }

  const gridCols = columns === 3 
    ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" 
    : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4";

  return (
    <div className={`grid ${gridCols} gap-6`}>
      {products.map((product) => (
        <ProductCard key={product.node.id} product={product} />
      ))}
    </div>
  );
};

export default ProductGrid;
