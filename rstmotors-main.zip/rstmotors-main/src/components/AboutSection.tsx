import { useLanguage } from "@/i18n/LanguageContext";
import rstAbout1 from "@/assets/rst-about-1.jpg";
import rstAbout2 from "@/assets/rst-about-2.jpg";

const AboutSection = () => {
  const { t } = useLanguage();

  const tabs = [
    t.homepage.tabSpecialEditions,
    t.homepage.tabModels,
    t.homepage.tabProducts,
  ];

  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Text Content */}
          <div className="text-center lg:text-left">
            <h2 className="animate-on-scroll font-heading text-3xl md:text-5xl font-bold italic uppercase text-foreground mb-8">
              {t.homepage.aboutTitle}
            </h2>
            <p className="animate-on-scroll text-muted-foreground text-base md:text-lg leading-relaxed">
              {t.homepage.aboutDesc}
            </p>
          </div>
          
          {/* Images */}
          <div className="grid grid-cols-2 gap-4">
            <div className="animate-on-scroll overflow-hidden">
              <img 
                src={rstAbout1} 
                alt="RST Tuning RS4" 
                className="w-full h-48 md:h-64 object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="animate-on-scroll overflow-hidden mt-8">
              <img 
                src={rstAbout2} 
                alt="RST Tuning Mercedes" 
                className="w-full h-48 md:h-64 object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
          </div>
        </div>

        {/* Navigation tabs */}
        <div className="flex justify-center gap-8">
          {tabs.map((tab, index) => (
            <button
              key={tab}
              className="animate-on-scroll font-heading text-sm font-semibold tracking-wider text-muted-foreground hover:text-foreground transition-colors border-b-2 border-transparent hover:border-primary pb-2"
              style={{ transitionDelay: `${index * 0.1}s` }}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
