import { useLanguage } from "@/i18n/LanguageContext";
import exhaustImage from "@/assets/exhaust-system.jpg";
import interiorImage from "@/assets/interior-tuning.jpg";
import wheelsImage from "@/assets/wheels.png";
import headlightsImage from "@/assets/headlights.png";

const ProductsSection = () => {
  const { t } = useLanguage();

  const products = [
    {
      id: 1,
      title: t.homepage.productsPower,
      image: exhaustImage,
    },
    {
      id: 2,
      title: t.homepage.productsWheels,
      image: wheelsImage,
    },
    {
      id: 3,
      title: t.homepage.productsInterior,
      image: interiorImage,
    },
    {
      id: 4,
      title: t.homepage.productsAero,
      image: headlightsImage,
    },
  ];

  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="animate-on-scroll font-heading text-3xl md:text-4xl font-bold italic uppercase text-foreground mb-4">
            {t.homepage.productsTitle}
          </h2>
          <p className="animate-on-scroll text-muted-foreground text-sm uppercase tracking-widest">
            {t.homepage.productsSubtitle}
          </p>
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {products.map((product, index) => (
            <div
              key={product.id}
              className="animate-scale relative h-72 group overflow-hidden cursor-pointer"
              style={{ transitionDelay: `${index * 0.1}s` }}
            >
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-background/40 group-hover:bg-background/20 transition-colors" />
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <h3 className="font-heading text-lg md:text-xl font-bold italic text-foreground text-center uppercase">
                  {product.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;
