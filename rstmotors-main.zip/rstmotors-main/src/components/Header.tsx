import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Menu, X, Heart, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import MobileMenu from "./MobileMenu";
import CartDrawer from "./CartDrawer";
import LanguageSwitcher from "./LanguageSwitcher";
import { useWishlistStore } from "@/stores/wishlistStore";
import { useAuth } from "@/hooks/useAuth";
import logo from "@/assets/logo.png";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const wishlistItems = useWishlistStore(state => state.items);
  const { user } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-50 transition-colors duration-300 ${isScrolled ? "bg-background" : ""}`}>
        <div className="flex items-center justify-between h-12 md:h-14">
          {/* Left side - Menu button with diagonal accent */}
          <div className="relative">
            <div className="diagonal-accent bg-primary w-16 md:w-24 h-12 md:h-14 flex items-center justify-start pl-3 md:pl-4">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-primary-foreground hover:opacity-80 transition-opacity"
                aria-label="Toggle menu"
              >
                {isMenuOpen ? <X size={20} className="md:w-6 md:h-6" /> : <Menu size={20} className="md:w-6 md:h-6" />}
              </button>
            </div>
          </div>

          {/* Center - Logo */}
          <div className="absolute left-1/2 -translate-x-1/2">
            <img src={logo} alt="RST Performance" className="h-5 md:h-7" />
          </div>

          {/* Right side - Icons */}
          <div className="flex items-center gap-2 md:gap-4 pr-3 md:pr-6">
            <LanguageSwitcher />
            <Link 
              to={user ? "/account" : "/auth"} 
              className="relative text-foreground hover:text-primary transition-colors"
            >
              <User size={16} className="md:w-5 md:h-5" />
            </Link>
            <Link 
              to="/wishlist" 
              className="relative text-foreground hover:text-primary transition-colors"
            >
              <Heart size={16} className="md:w-5 md:h-5" />
              {wishlistItems.length > 0 && (
                <Badge className="absolute -top-2 -right-2 h-4 w-4 md:h-5 md:w-5 rounded-full p-0 flex items-center justify-center text-[10px] md:text-xs bg-destructive text-destructive-foreground">
                  {wishlistItems.length}
                </Badge>
              )}
            </Link>
            <CartDrawer />
          </div>
        </div>
      </header>

      <MobileMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />
    </>
  );
};

export default Header;
