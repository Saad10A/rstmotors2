import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from "react";
import { translations, Language } from "./translations";

// Create a mutable type from the const translations
type TranslationType = {
  [K in keyof typeof translations["en"]]: {
    [J in keyof typeof translations["en"][K]]: string;
  };
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: TranslationType;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const detectLanguageFromBrowser = (): Language => {
  const browserLang = navigator.language || (navigator as any).userLanguage || "it";
  if (browserLang.toLowerCase().startsWith("en")) {
    return "en";
  }
  return "it"; // Default to Italian
};

// Deep merge function to merge translations with fallback to English
const deepMerge = (target: any, source: any): any => {
  const output = { ...target };
  for (const key in target) {
    if (target[key] && typeof target[key] === "object" && !Array.isArray(target[key])) {
      output[key] = deepMerge(target[key], source?.[key] || {});
    } else {
      // Use source value if it exists and is not empty, otherwise keep target (English)
      output[key] = source?.[key] !== undefined && source?.[key] !== "" ? source[key] : target[key];
    }
  }
  return output;
};

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem("language");
    if (saved && (saved === "en" || saved === "it")) {
      return saved as Language;
    }
    return detectLanguageFromBrowser();
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("language", lang);
  };

  // Map app language to Shopify locale codes
  const getShopifyLocale = (lang: Language): string => {
    const localeMap: Record<Language, string> = {
      en: 'en',
      it: 'it'
    };
    return localeMap[lang] || 'en';
  };

  useEffect(() => {
    document.documentElement.lang = language;
    
    // Update Shopify Chat widget locale if it exists
    const shopifyLocale = getShopifyLocale(language);
    if (typeof window !== 'undefined' && (window as any).ShopifyChat) {
      (window as any).ShopifyChat.updateLocale(shopifyLocale);
    }
  }, [language]);

  // Create translations with fallback to English for any missing keys
  const t = useMemo<TranslationType>(() => {
    if (language === "en") {
      return translations.en as unknown as TranslationType;
    }
    // Merge current language translations over English defaults
    return deepMerge(translations.en, translations[language]) as TranslationType;
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);

  // In rare cases (e.g. hot-reload/module duplication), the context can be undefined.
  // Instead of hard-crashing the whole app, fall back to Italian and log an error.
  if (!context) {
    console.error("useLanguage called without LanguageProvider", {
      href: typeof window !== "undefined" ? window.location.href : "unknown",
    });

    return {
      language: "it" as Language,
      setLanguage: () => {},
      t: translations.it as unknown as TranslationType,
    };
  }

  return context;
};
