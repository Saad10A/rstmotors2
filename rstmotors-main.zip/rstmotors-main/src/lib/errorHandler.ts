/**
 * Error sanitization utility to prevent information disclosure.
 * Maps database error codes to user-friendly messages while logging full details for debugging.
 */

interface DatabaseError {
  code?: string;
  status?: number;
  message?: string;
  details?: string;
  hint?: string;
}

// Map of PostgreSQL/Supabase error codes to user-friendly messages
const errorCodeMap: Record<string, string> = {
  // PostgreSQL constraint violations
  '23505': 'This record already exists.',
  '23503': 'Cannot complete this action - the record is referenced elsewhere.',
  '23502': 'A required field is missing.',
  '23514': 'The data provided does not meet the requirements.',
  '23000': 'Data integrity error occurred.',
  
  // PostgreSQL permission/RLS errors
  '42501': 'You do not have permission to perform this action.',
  '42000': 'You do not have permission to perform this action.',
  
  // Supabase/PostgREST errors
  'PGRST301': 'You do not have permission to perform this action.',
  'PGRST116': 'The requested record was not found.',
  'PGRST204': 'The requested record was not found.',
  
  // Authentication errors
  '401': 'Please sign in to continue.',
  '403': 'You do not have permission to perform this action.',
  '404': 'The requested item was not found.',
  '409': 'This action conflicts with existing data.',
  '422': 'The data provided is invalid.',
  '429': 'Too many requests. Please try again later.',
  '500': 'An unexpected error occurred. Please try again.',
  '502': 'Service temporarily unavailable. Please try again.',
  '503': 'Service temporarily unavailable. Please try again.',
};

// Patterns to detect sensitive information in error messages
const sensitivePatterns = [
  /column\s+["']?\w+["']?/i,
  /table\s+["']?\w+["']?/i,
  /constraint\s+["']?\w+["']?/i,
  /relation\s+["']?\w+["']?/i,
  /schema\s+["']?\w+["']?/i,
  /policy\s+["']?\w+["']?/i,
  /function\s+["']?\w+["']?/i,
];

/**
 * Sanitizes database errors to prevent information disclosure.
 * Logs the full error for debugging but returns a user-friendly message.
 * 
 * @param error - The error object from Supabase or other sources
 * @param fallbackMessage - Optional fallback message if no specific mapping exists
 * @returns A user-friendly error message
 */
export function sanitizeError(error: DatabaseError | any, fallbackMessage?: string): string {
  // Log the full error for debugging (only visible in console)
  console.error('Database operation error:', {
    code: error?.code,
    status: error?.status,
    message: error?.message,
    details: error?.details,
    hint: error?.hint,
  });
  
  // Try to match by error code
  const errorCode = error?.code?.toString() || error?.status?.toString();
  if (errorCode && errorCodeMap[errorCode]) {
    return errorCodeMap[errorCode];
  }
  
  // Check for RLS policy violation
  if (error?.message?.toLowerCase().includes('row-level security')) {
    return 'You do not have permission to perform this action.';
  }
  
  // Check for authentication issues
  if (error?.message?.toLowerCase().includes('jwt') || 
      error?.message?.toLowerCase().includes('token') ||
      error?.message?.toLowerCase().includes('unauthorized')) {
    return 'Your session has expired. Please sign in again.';
  }
  
  // Check for network/connection issues
  if (error?.message?.toLowerCase().includes('network') ||
      error?.message?.toLowerCase().includes('fetch') ||
      error?.message?.toLowerCase().includes('connection')) {
    return 'Network error. Please check your connection and try again.';
  }
  
  // If the error message contains sensitive patterns, use generic message
  const errorMessage = error?.message || '';
  for (const pattern of sensitivePatterns) {
    if (pattern.test(errorMessage)) {
      return fallbackMessage || 'An error occurred. Please try again or contact support.';
    }
  }
  
  // Return the fallback or a generic message
  return fallbackMessage || 'An error occurred. Please try again or contact support.';
}

/**
 * Sanitizes errors specifically for car operations
 */
export function sanitizeCarError(error: any, operation: 'create' | 'update' | 'delete'): string {
  const operationMessages = {
    create: 'Failed to add car listing.',
    update: 'Failed to update car listing.',
    delete: 'Failed to delete car listing.',
  };
  
  return sanitizeError(error, operationMessages[operation]);
}