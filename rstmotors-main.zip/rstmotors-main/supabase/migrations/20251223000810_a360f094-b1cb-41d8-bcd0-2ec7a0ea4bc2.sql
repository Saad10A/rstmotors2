-- Create cars table for vehicle listings
CREATE TABLE public.cars (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT,
  price DECIMAL(10,2) NOT NULL,
  mileage INTEGER,
  registration_year INTEGER,
  registration_plate TEXT,
  fuel_type TEXT,
  body_type TEXT,
  engine TEXT,
  gearbox TEXT,
  doors INTEGER,
  seats INTEGER,
  emission_class TEXT,
  body_colour TEXT,
  power TEXT,
  acceleration TEXT,
  description TEXT,
  images TEXT[] DEFAULT '{}',
  seller_name TEXT,
  seller_location TEXT,
  seller_phone TEXT,
  owners INTEGER DEFAULT 1,
  keys INTEGER DEFAULT 2,
  service_history TEXT,
  mot_valid_until TEXT,
  is_featured BOOLEAN DEFAULT false,
  is_sold BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.cars ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access (cars are publicly viewable)
CREATE POLICY "Cars are publicly viewable"
ON public.cars
FOR SELECT
USING (true);

-- Create policy for authenticated users to manage cars (admin functionality)
CREATE POLICY "Authenticated users can insert cars"
ON public.cars
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update cars"
ON public.cars
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete cars"
ON public.cars
FOR DELETE
TO authenticated
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_cars_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_cars_updated_at
BEFORE UPDATE ON public.cars
FOR EACH ROW
EXECUTE FUNCTION public.update_cars_updated_at();

-- Insert sample car data
INSERT INTO public.cars (title, subtitle, price, mileage, registration_year, registration_plate, fuel_type, body_type, engine, gearbox, doors, seats, emission_class, body_colour, power, acceleration, description, images, seller_name, seller_location, seller_phone, owners, service_history, mot_valid_until, is_featured) VALUES
('BMW M8 Competition', '4.4 V8 Twin-Turbo 2dr', 89999, 15420, 2022, '72 reg', 'Petrol', 'Coupe', '4.4L V8', 'Automatic', 2, 4, 'Euro 6', 'Black Sapphire', '625 bhp', '3.2s 0-62mph', 'Stunning BMW M8 Competition in pristine condition. Full BMW service history, M Carbon Exterior Package, Laser Headlights, M Carbon Ceramic Brakes, Head-Up Display.', ARRAY['https://images.unsplash.com/photo-1617531653332-bd46c24f2068?w=800&q=80', 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80', 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?w=800&q=80'], 'RST Performance', 'Manchester', '+44 161 555 0123', 2, 'Full BMW Service History', '12/2025', true),
('Audi RS7 Sportback', '4.0 TFSI V8 Quattro', 94500, 22150, 2021, '71 reg', 'Petrol', 'Hatchback', '4.0L V8', 'Automatic', 5, 5, 'Euro 6', 'Nardo Grey', '600 bhp', '3.6s 0-62mph', 'Incredible Audi RS7 in the sought-after Nardo Grey. RS Sport Exhaust, Carbon Optic Package, Matrix LED headlights, Bang & Olufsen sound system.', ARRAY['https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80', 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?w=800&q=80'], 'RST Performance', 'Manchester', '+44 161 555 0123', 1, 'Full Audi Service History', '09/2025', true),
('Mercedes-AMG GT63 S', '4.0 V8 BiTurbo 4MATIC+', 112000, 8500, 2023, '23 reg', 'Petrol', 'Coupe', '4.0L V8', 'Automatic', 4, 4, 'Euro 6', 'Selenite Grey', '639 bhp', '3.2s 0-62mph', 'As-new Mercedes-AMG GT63 S with delivery mileage. AMG Performance Package, AMG Night Package, Burmester 3D surround sound.', ARRAY['https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80', 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80'], 'RST Performance', 'Manchester', '+44 161 555 0123', 1, 'Full Mercedes Service History', '03/2026', true),
('Lamborghini Urus', '4.0 V8 Twin-Turbo SUV', 185000, 12300, 2022, '72 reg', 'Petrol', 'SUV', '4.0L V8', 'Automatic', 5, 5, 'Euro 6', 'Blu Eleos', '650 bhp', '3.6s 0-62mph', 'Stunning Lamborghini Urus in rare Blu Eleos. Akrapovic exhaust, carbon ceramic brakes, full leather interior with Q-citura stitching.', ARRAY['https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80', 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80'], 'RST Performance', 'Manchester', '+44 161 555 0123', 1, 'Full Lamborghini Service History', '06/2025', true),
('Porsche 911 GT3', '4.0 Flat-6 PDK', 165000, 5200, 2022, '72 reg', 'Petrol', 'Coupe', '4.0L Flat-6', 'PDK', 2, 2, 'Euro 6', 'GT Silver', '510 bhp', '3.4s 0-62mph', 'Exceptional Porsche 911 GT3 with low mileage. Front axle lift, LED Matrix headlights, Sport Chrono Package, carbon bucket seats.', ARRAY['https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800&q=80', 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80'], 'RST Performance', 'Manchester', '+44 161 555 0123', 1, 'Full Porsche Service History', '08/2025', false),
('BMW M4 Competition', '3.0 Bi-Turbo xDrive', 72500, 18900, 2021, '71 reg', 'Petrol', 'Coupe', '3.0L I6', 'Automatic', 2, 4, 'Euro 6', 'Isle of Man Green', '510 bhp', '3.5s 0-62mph', 'Eye-catching M4 Competition in rare Isle of Man Green. M Carbon exterior package, M carbon bucket seats, M Performance exhaust.', ARRAY['https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80', 'https://images.unsplash.com/photo-1617531653332-bd46c24f2068?w=800&q=80'], 'RST Performance', 'Manchester', '+44 161 555 0123', 2, 'Full BMW Service History', '11/2025', false);
