-- Create a public view for car listings that excludes sensitive PII fields
-- This view should be used for public/unauthenticated access

CREATE VIEW public.cars_public
WITH (security_invoker = on) AS
SELECT 
  id,
  title,
  subtitle,
  price,
  mileage,
  registration_year,
  fuel_type,
  body_type,
  engine,
  gearbox,
  doors,
  seats,
  emission_class,
  body_colour,
  power,
  acceleration,
  description,
  images,
  seller_location,
  owners,
  keys,
  service_history,
  mot_valid_until,
  is_featured,
  is_sold,
  created_at,
  updated_at
FROM public.cars;
-- Note: Excludes seller_phone, seller_name, and registration_plate

-- Drop the existing public SELECT policy
DROP POLICY IF EXISTS "Cars are publicly viewable" ON public.cars;

-- Create new policy: Only authenticated users can view full car details (including PII)
CREATE POLICY "Authenticated users can view all car details"
ON public.cars
FOR SELECT
TO authenticated
USING (true);

-- Create policy: Public can view cars through the view (which excludes sensitive data)
-- The view has security_invoker = on, so this policy allows public access to non-sensitive data
CREATE POLICY "Public can view non-sensitive car data"
ON public.cars
FOR SELECT
TO anon
USING (true);