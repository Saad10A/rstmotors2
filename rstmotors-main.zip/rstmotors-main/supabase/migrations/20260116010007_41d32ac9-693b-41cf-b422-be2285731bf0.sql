-- Add explicit null validation to the has_role function to reduce attack surface
-- This function is used by RLS policies and uses SECURITY DEFINER

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Validate _user_id is not null to prevent edge cases
  IF _user_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Validate _role is not null
  IF _role IS NULL THEN
    RETURN false;
  END IF;
  
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  );
END;
$$;