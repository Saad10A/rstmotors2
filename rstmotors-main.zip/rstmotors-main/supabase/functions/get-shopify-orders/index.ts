import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const SHOPIFY_STORE_DOMAIN = 'rstmotors-s5wwz.myshopify.com';
const SHOPIFY_ACCESS_TOKEN = Deno.env.get('SHOPIFY_ACCESS_TOKEN');

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TrackingInfo {
  company: string | null;
  number: string | null;
  url: string | null;
}

interface FulfillmentInfo {
  status: string;
  tracking_company: string | null;
  tracking_number: string | null;
  tracking_url: string | null;
  shipment_status: string | null;
  estimated_delivery_at: string | null;
  delivered_at: string | null;
  created_at: string;
  updated_at: string;
}

serve(async (req: Request): Promise<Response> => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // ============================================
    // AUTHENTICATION CHECK - REQUIRED
    // ============================================
    const authHeader = req.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.error("Missing or invalid authorization header");
      return new Response(
        JSON.stringify({ error: "Unauthorized: Missing authentication" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Create Supabase client with auth header
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the JWT and get user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    
    if (authError || !user) {
      console.error("Authentication failed:", authError?.message);
      return new Response(
        JSON.stringify({ error: "Unauthorized: Invalid token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get the authenticated user's email
    const userEmail = user.email;
    if (!userEmail) {
      console.error("No email in user profile");
      return new Response(
        JSON.stringify({ error: "Unauthorized: No email associated with account" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Authenticated user requesting orders for: ${userEmail}`);
    // ============================================
    // END AUTHENTICATION CHECK
    // ============================================

    // Use the authenticated user's email - don't accept email from request body
    // This ensures users can ONLY query their own orders
    const email = userEmail;

    if (!SHOPIFY_ACCESS_TOKEN) {
      console.error("SHOPIFY_ACCESS_TOKEN not configured");
      return new Response(
        JSON.stringify({ error: "Shopify not configured" }),
        { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // First, find the customer by email using REST Admin API
    const customerSearchUrl = `https://${SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/customers/search.json?query=email:${encodeURIComponent(email)}`;
    
    console.log(`Searching for customer with email: ${email}`);
    const customerResponse = await fetch(customerSearchUrl, {
      method: 'GET',
      headers: {
        'X-Shopify-Access-Token': SHOPIFY_ACCESS_TOKEN,
        'Content-Type': 'application/json',
      },
    });

    if (!customerResponse.ok) {
      const errorText = await customerResponse.text();
      console.error("Customer search failed:", errorText);
      return new Response(
        JSON.stringify({ orders: [] }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const customerData = await customerResponse.json();
    const customers = customerData.customers || [];
    console.log(`Found ${customers.length} customers`);

    if (customers.length === 0) {
      // No customer found with this email
      return new Response(
        JSON.stringify({ orders: [] }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const customerId = customers[0].id;
    console.log(`Customer ID: ${customerId}`);

    // Fetch orders for this customer with fulfillments
    const ordersUrl = `https://${SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/customers/${customerId}/orders.json?status=any`;
    
    const ordersResponse = await fetch(ordersUrl, {
      method: 'GET',
      headers: {
        'X-Shopify-Access-Token': SHOPIFY_ACCESS_TOKEN,
        'Content-Type': 'application/json',
      },
    });

    if (!ordersResponse.ok) {
      const errorText = await ordersResponse.text();
      console.error("Orders fetch failed:", errorText);
      return new Response(
        JSON.stringify({ orders: [] }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const ordersData = await ordersResponse.json();
    const shopifyOrders = ordersData.orders || [];
    console.log(`Found ${shopifyOrders.length} orders`);

    // Transform orders with enhanced tracking information
    const orders = shopifyOrders.map((order: any) => {
      // Extract fulfillment and tracking info
      const fulfillments: FulfillmentInfo[] = (order.fulfillments || []).map((f: any) => ({
        status: f.status || 'pending',
        tracking_company: f.tracking_company || null,
        tracking_number: f.tracking_number || null,
        tracking_url: f.tracking_url || null,
        shipment_status: f.shipment_status || null,
        estimated_delivery_at: f.estimated_delivery_at || null,
        delivered_at: f.delivered_at || null,
        created_at: f.created_at,
        updated_at: f.updated_at,
      }));

      // Get primary tracking info from first fulfillment
      const primaryFulfillment = fulfillments[0] || null;
      const tracking: TrackingInfo = {
        company: primaryFulfillment?.tracking_company || null,
        number: primaryFulfillment?.tracking_number || null,
        url: primaryFulfillment?.tracking_url || null,
      };

      // Calculate order status based on fulfillments
      let orderStatus = 'processing';
      if (order.cancelled_at) {
        orderStatus = 'cancelled';
      } else if (order.closed_at) {
        orderStatus = 'completed';
      } else if (fulfillments.some((f: FulfillmentInfo) => f.shipment_status === 'delivered' || f.status === 'success')) {
        orderStatus = 'delivered';
      } else if (fulfillments.some((f: FulfillmentInfo) => f.shipment_status === 'out_for_delivery')) {
        orderStatus = 'out_for_delivery';
      } else if (fulfillments.some((f: FulfillmentInfo) => f.shipment_status === 'in_transit' || f.status === 'in_transit')) {
        orderStatus = 'in_transit';
      } else if (fulfillments.length > 0) {
        orderStatus = 'shipped';
      } else if (order.financial_status === 'paid') {
        orderStatus = 'confirmed';
      }

      // Get estimated delivery
      const estimatedDelivery = fulfillments.find((f: FulfillmentInfo) => f.estimated_delivery_at)?.estimated_delivery_at || null;
      const deliveredAt = fulfillments.find((f: FulfillmentInfo) => f.delivered_at)?.delivered_at || null;

      return {
        id: order.id.toString(),
        name: order.name,
        created_at: order.created_at,
        processed_at: order.processed_at,
        closed_at: order.closed_at,
        cancelled_at: order.cancelled_at,
        financial_status: order.financial_status,
        fulfillment_status: order.fulfillment_status,
        total_price: order.total_price,
        currency: order.currency,
        order_status_url: order.order_status_url,
        order_status: orderStatus,
        tracking,
        fulfillments,
        estimated_delivery_at: estimatedDelivery,
        delivered_at: deliveredAt,
        shipping_address: order.shipping_address ? {
          city: order.shipping_address.city,
          province: order.shipping_address.province,
          country: order.shipping_address.country,
        } : null,
        line_items: order.line_items.map((item: any) => ({
          id: item.id.toString(),
          title: item.title,
          quantity: item.quantity,
          price: item.price,
          variant_title: item.variant_title,
          sku: item.sku,
          fulfillment_status: item.fulfillment_status,
        })),
      };
    });

    console.log(`Returning ${orders.length} orders with tracking info`);
    return new Response(
      JSON.stringify({ orders }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in get-shopify-orders:", error);
    // Return sanitized error message
    return new Response(
      JSON.stringify({ error: "An error occurred while fetching orders. Please try again." }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
});